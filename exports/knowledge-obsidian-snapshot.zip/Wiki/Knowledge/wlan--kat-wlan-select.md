---
type: "knowledge"
title: "WLAN"
id: "KAT-WLAN-SELECT"
source: "internal-category"
source_uri: "kb://internal-kb/glpi-kategorien/netzwerk-und-verbindungen/wlan"
language: "de-DE"
communication_style: "formal"
created: "2026-08-05"
updated: "2026-08-05"
auto_reply: false
min_score: 0.7
tags:
  - "Access Point"
  - "Funknetz"
  - "Netzwerk und Verbindungen"
  - "SSID"
  - "WLAN"
  - "WLAN-Abdeckung"
  - "Wi-Fi"
  - "keine Verbindung"
  - "schlechter Empfang"
categories:
  - "Netzwerk und Verbindungen \u003e WLAN"
related:
  - "[[Wiki/Categories/netzwerk-und-verbindungen-wlan|Netzwerk und Verbindungen \u003e WLAN]]"
---

# WLAN

## Kontext / Problem

Auswahlziel: Netzwerk und Verbindungen > WLAN. Primär zuständiges Team: Infrastruktur und Backend. Diese Kategorie ist auszuwählen, wenn eine drahtlose Netzwerkverbindung nicht hergestellt wird, häufig abbricht, zu schwach ist, ein WLAN-Bereich nicht versorgt wird oder ein SSID-/Authentifizierungsproblem besteht. Typische Ticketformulierungen sind: „WLAN verbindet nicht“; „Schlechter Empfang im Raum“; „SSID fehlt“; „WLAN bricht ständig ab“. Nicht auswählen, wenn Mobilfunkempfang, kabelgebundenes LAN oder ein allgemeines Internetproblem ohne WLAN-Bezug gemeint ist. Für die Klassifizierung sind der konkret betroffene Dienst oder Gegenstand, die Fehlermeldung, die Anzahl betroffener Personen, der Standort sowie die Unterscheidung zwischen Störung, Berechtigung, Bestellung und Änderungswunsch besonders wichtig. Einzelne unspezifische Wörter wie „geht nicht“, „Problem“ oder „dringend“ reichen ohne Sachbezug nicht für diese Zuordnung aus. Abgrenzungsregel: Bei einem einzelnen Gerät kann der Support vorprüfen; flächige Abdeckung und Access Points liegen bei Infrastruktur.

## Lösung / Antwort

Interne Klassifizierung: Das Ticket ist der Kategorie „Netzwerk und Verbindungen > WLAN“ zuzuordnen. Primär zuständig ist „Infrastruktur und Backend“. Vor der endgültigen Zuweisung sind die genannten Ausschlusskriterien und Schnittstellen zu prüfen.

## Verknüpfungen

- [[Wiki/Categories/netzwerk-und-verbindungen-wlan|Netzwerk und Verbindungen > WLAN]] — Kategorie
- Quelle: `kb://internal-kb/glpi-kategorien/netzwerk-und-verbindungen/wlan`
