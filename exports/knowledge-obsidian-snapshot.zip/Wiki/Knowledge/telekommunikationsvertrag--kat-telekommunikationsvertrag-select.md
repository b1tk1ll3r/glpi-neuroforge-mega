---
type: "knowledge"
title: "Telekommunikationsvertrag"
id: "KAT-TELEKOMMUNIKATIONSVERTRAG-SELECT"
source: "internal-category"
source_uri: "kb://internal-kb/glpi-kategorien/beschaffung-vertrage-und-lizenzen/telekommunikationsvertrag"
language: "de-DE"
communication_style: "formal"
created: "2026-08-05"
updated: "2026-08-05"
auto_reply: false
min_score: 0.7
tags:
  - "Beschaffung, Verträge und Lizenzen"
  - "Festnetzvertrag"
  - "Kündigung"
  - "Mobilfunkvertrag"
  - "Providervertrag"
  - "Tarif"
  - "Telekommunikationsvertrag"
  - "Vertragsverlängerung"
categories:
  - "Beschaffung, Verträge und Lizenzen \u003e Telekommunikationsvertrag"
related:
  - "[[Wiki/Categories/beschaffung-vertraege-und-lizenzen-telekommunikationsvertrag|Beschaffung, Verträge und Lizenzen \u003e Telekommunikationsvertrag]]"
---

# Telekommunikationsvertrag

## Kontext / Problem

Auswahlziel: Beschaffung, Verträge und Lizenzen > Telekommunikationsvertrag. Primär zuständiges Team: Leitung und Finanzen / Beschaffung. Diese Kategorie ist auszuwählen, wenn Mobilfunk-, Festnetz-, Datenleitungs- oder sonstige Telekommunikationsverträge neu abgeschlossen, verlängert, angepasst oder gekündigt werden sollen. Typische Ticketformulierungen sind: „Mobilfunkvertrag verlängern“; „Festnetzvertrag kündigen“; „Datentarif anpassen“; „Providerangebot prüfen“. Nicht auswählen, wenn eine technische Telefonstörung, SIM-Sperre oder Rufumleitung betroffen ist. Für die Klassifizierung sind der konkret betroffene Dienst oder Gegenstand, die Fehlermeldung, die Anzahl betroffener Personen, der Standort sowie die Unterscheidung zwischen Störung, Berechtigung, Bestellung und Änderungswunsch besonders wichtig. Einzelne unspezifische Wörter wie „geht nicht“, „Problem“ oder „dringend“ reichen ohne Sachbezug nicht für diese Zuordnung aus. Abgrenzungsregel: Technische Bedarfe werden mit Support und Infrastruktur abgestimmt.

## Lösung / Antwort

Interne Klassifizierung: Das Ticket ist der Kategorie „Beschaffung, Verträge und Lizenzen > Telekommunikationsvertrag“ zuzuordnen. Primär zuständig ist „Leitung und Finanzen / Beschaffung“. Vor der endgültigen Zuweisung sind die genannten Ausschlusskriterien und Schnittstellen zu prüfen.

## Verknüpfungen

- [[Wiki/Categories/beschaffung-vertraege-und-lizenzen-telekommunikationsvertrag|Beschaffung, Verträge und Lizenzen > Telekommunikationsvertrag]] — Kategorie
- Quelle: `kb://internal-kb/glpi-kategorien/beschaffung-vertrage-und-lizenzen/telekommunikationsvertrag`
