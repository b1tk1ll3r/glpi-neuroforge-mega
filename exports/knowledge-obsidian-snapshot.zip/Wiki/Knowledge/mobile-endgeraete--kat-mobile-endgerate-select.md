---
type: "knowledge"
title: "Mobile Endgeräte"
id: "KAT-MOBILE-ENDGERATE-SELECT"
source: "internal-category"
source_uri: "kb://internal-kb/glpi-kategorien/arbeitsplatz-und-endgerate/mobile-endgerate"
language: "de-DE"
communication_style: "formal"
created: "2026-08-05"
updated: "2026-08-05"
auto_reply: false
min_score: 0.7
tags:
  - "Android"
  - "Arbeitsplatz und Endgeräte"
  - "Diensthandy"
  - "Geräteeinrichtung"
  - "Mobile Endgeräte"
  - "Mobilgerät"
  - "Smartphone"
  - "Synchronisation"
  - "Tablet"
  - "Zurücksetzen"
  - "iPad"
  - "iPhone"
categories:
  - "Arbeitsplatz und Endgeräte \u003e Mobile Endgeräte"
related:
  - "[[Wiki/Categories/arbeitsplatz-und-endgeraete-mobile-endgeraete|Arbeitsplatz und Endgeräte \u003e Mobile Endgeräte]]"
---

# Mobile Endgeräte

## Kontext / Problem

Auswahlziel: Arbeitsplatz und Endgeräte > Mobile Endgeräte. Primär zuständiges Team: Support und Telekommunikation. Diese Kategorie ist auszuwählen, wenn ein dienstliches Smartphone oder Tablet eingerichtet, zurückgesetzt, ausgetauscht oder bei einem Geräte-, App-, Synchronisations- oder lokalen Bedienproblem unterstützt werden muss. Typische Ticketformulierungen sind: „Diensthandy lässt sich nicht entsperren“; „Tablet synchronisiert nicht“; „Smartphone einrichten“; „Mobiles Gerät zurücksetzen“. Nicht auswählen, wenn es um Mobilfunktarif, SIM-Karte oder Rufnummer geht; wenn MFA lediglich auf ein neues Gerät übertragen werden muss; wenn das Gerät neu beschafft werden soll. Für die Klassifizierung sind der konkret betroffene Dienst oder Gegenstand, die Fehlermeldung, die Anzahl betroffener Personen, der Standort sowie die Unterscheidung zwischen Störung, Berechtigung, Bestellung und Änderungswunsch besonders wichtig. Einzelne unspezifische Wörter wie „geht nicht“, „Problem“ oder „dringend“ reichen ohne Sachbezug nicht für diese Zuordnung aus. Abgrenzungsregel: SIM- und Vertragsfragen gehören zu Telefonie und Kommunikation > Mobilfunk. Sicherheitsrelevanter Verlust ist zusätzlich als Sicherheitsvorfall zu behandeln.

## Lösung / Antwort

Interne Klassifizierung: Das Ticket ist der Kategorie „Arbeitsplatz und Endgeräte > Mobile Endgeräte“ zuzuordnen. Primär zuständig ist „Support und Telekommunikation“. Vor der endgültigen Zuweisung sind die genannten Ausschlusskriterien und Schnittstellen zu prüfen.

## Verknüpfungen

- [[Wiki/Categories/arbeitsplatz-und-endgeraete-mobile-endgeraete|Arbeitsplatz und Endgeräte > Mobile Endgeräte]] — Kategorie
- Quelle: `kb://internal-kb/glpi-kategorien/arbeitsplatz-und-endgerate/mobile-endgerate`
