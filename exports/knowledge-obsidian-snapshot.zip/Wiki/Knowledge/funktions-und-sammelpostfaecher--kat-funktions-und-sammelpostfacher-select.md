---
type: "knowledge"
title: "Funktions- und Sammelpostfächer"
id: "KAT-FUNKTIONS-UND-SAMMELPOSTFACHER-SELECT"
source: "internal-category"
source_uri: "kb://internal-kb/glpi-kategorien/benutzerkonten-und-berechtigungen/funktions-und-sammelpostfacher"
language: "de-DE"
communication_style: "formal"
created: "2026-08-05"
updated: "2026-08-05"
auto_reply: false
min_score: 0.7
tags:
  - "Benutzerkonten und Berechtigungen"
  - "Funktions- und Sammelpostfächer"
  - "Funktionspostfach"
  - "Postfach anlegen"
  - "Postfachberechtigung"
  - "Sammelpostfach"
  - "Senden als"
  - "Shared Mailbox"
  - "Team-Postfach"
  - "gemeinsames Postfach"
categories:
  - "Benutzerkonten und Berechtigungen \u003e Funktions- und Sammelpostfächer"
related:
  - "[[Wiki/Categories/benutzerkonten-und-berechtigungen-funktions-und-sammelpostfaecher|Benutzerkonten und Berechtigungen \u003e Funktions- und Sammelpostfächer]]"
---

# Funktions- und Sammelpostfächer

## Kontext / Problem

Auswahlziel: Benutzerkonten und Berechtigungen > Funktions- und Sammelpostfächer. Primär zuständiges Team: Infrastruktur und Backend. Diese Kategorie ist auszuwählen, wenn ein Funktionspostfach, Sammelpostfach, Team-Postfach oder gemeinsam genutztes Postfach neu angelegt, geändert, umbenannt, berechtigt oder außer Betrieb genommen werden soll. Typische Ticketformulierungen sind: „Postfach info@ anlegen“; „Zugriff auf gemeinsames Postfach“; „Funktionspostfach umbenennen“; „Sammelpostfach schließen“. Nicht auswählen, wenn der Outlook-Client lokal nicht startet, eine einzelne E-Mail nicht zugestellt wird oder eine Verteilerliste ohne Postfachbezug gemeint ist. Für die Klassifizierung sind der konkret betroffene Dienst oder Gegenstand, die Fehlermeldung, die Anzahl betroffener Personen, der Standort sowie die Unterscheidung zwischen Störung, Berechtigung, Bestellung und Änderungswunsch besonders wichtig. Einzelne unspezifische Wörter wie „geht nicht“, „Problem“ oder „dringend“ reichen ohne Sachbezug nicht für diese Zuordnung aus. Abgrenzungsregel: Lokale Outlook-Probleme gehören zu Microsoft Office > Outlook-Client; serverseitige Mailstörungen zu Infrastruktur und Backend.

## Lösung / Antwort

Interne Klassifizierung: Das Ticket ist der Kategorie „Benutzerkonten und Berechtigungen > Funktions- und Sammelpostfächer“ zuzuordnen. Primär zuständig ist „Infrastruktur und Backend“. Vor der endgültigen Zuweisung sind die genannten Ausschlusskriterien und Schnittstellen zu prüfen.

## Verknüpfungen

- [[Wiki/Categories/benutzerkonten-und-berechtigungen-funktions-und-sammelpostfaecher|Benutzerkonten und Berechtigungen > Funktions- und Sammelpostfächer]] — Kategorie
- Quelle: `kb://internal-kb/glpi-kategorien/benutzerkonten-und-berechtigungen/funktions-und-sammelpostfacher`
