---
type: "knowledge"
title: "Mobilfunk"
id: "KAT-MOBILFUNK-SELECT"
source: "internal-category"
source_uri: "kb://internal-kb/glpi-kategorien/telefonie-und-kommunikation/mobilfunk"
language: "de-DE"
communication_style: "formal"
created: "2026-08-05"
updated: "2026-08-05"
auto_reply: false
min_score: 0.7
tags:
  - "Empfang"
  - "Handynummer"
  - "Mobilfunk"
  - "Mobilfunkvertrag"
  - "PIN"
  - "PUK"
  - "Roaming"
  - "SIM-Karte"
  - "Telefonie und Kommunikation"
  - "eSIM"
  - "mobile Daten"
categories:
  - "Telefonie und Kommunikation \u003e Mobilfunk"
related:
  - "[[Wiki/Categories/telefonie-und-kommunikation-mobilfunk|Telefonie und Kommunikation \u003e Mobilfunk]]"
---

# Mobilfunk

## Kontext / Problem

Auswahlziel: Telefonie und Kommunikation > Mobilfunk. Primär zuständiges Team: Support und Telekommunikation. Diese Kategorie ist auszuwählen, wenn SIM-Karte, Mobilfunktarif, Mobilfunkvertrag, Empfang, Roaming, mobile Daten oder eine dienstliche Mobilfunkrufnummer betroffen sind. Typische Ticketformulierungen sind: „SIM-Karte gesperrt“; „Kein Mobilfunkempfang“; „Roaming freischalten“; „Mobilfunktarif ändern“; „Neue eSIM“. Nicht auswählen, wenn das Smartphone selbst defekt ist, MFA übertragen werden soll oder eine reine App-/Geräteeinrichtung ohne Mobilfunkbezug vorliegt. Für die Klassifizierung sind der konkret betroffene Dienst oder Gegenstand, die Fehlermeldung, die Anzahl betroffener Personen, der Standort sowie die Unterscheidung zwischen Störung, Berechtigung, Bestellung und Änderungswunsch besonders wichtig. Einzelne unspezifische Wörter wie „geht nicht“, „Problem“ oder „dringend“ reichen ohne Sachbezug nicht für diese Zuordnung aus. Abgrenzungsregel: Kaufmännische Vertragsänderungen erfolgen in Abstimmung mit Beschaffung.

## Lösung / Antwort

Interne Klassifizierung: Das Ticket ist der Kategorie „Telefonie und Kommunikation > Mobilfunk“ zuzuordnen. Primär zuständig ist „Support und Telekommunikation“. Vor der endgültigen Zuweisung sind die genannten Ausschlusskriterien und Schnittstellen zu prüfen.

## Verknüpfungen

- [[Wiki/Categories/telefonie-und-kommunikation-mobilfunk|Telefonie und Kommunikation > Mobilfunk]] — Kategorie
- Quelle: `kb://internal-kb/glpi-kategorien/telefonie-und-kommunikation/mobilfunk`
