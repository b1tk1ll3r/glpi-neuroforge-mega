---
type: "knowledge"
title: "Fachanwendung – Einführung einer Anwendung"
id: "KAT-FACHANWENDUNG-EINFUHRUNG-EINER-ANWENDUNG-SELECT"
source: "internal-category"
source_uri: "kb://internal-kb/glpi-kategorien/fachanwendungen-und-microsoft-office/fachanwendung-einfuhrung-einer-anwendung"
language: "de-DE"
communication_style: "formal"
created: "2026-08-05"
updated: "2026-08-05"
auto_reply: false
min_score: 0.7
tags:
  - "Ablösung"
  - "Einführung"
  - "Fachanwendung – Einführung einer Anwendung"
  - "Fachanwendungen und Microsoft Office"
  - "Implementierung"
  - "Migration"
  - "Pilot"
  - "Projekt Fachsoftware"
  - "Rollout"
  - "neue Anwendung"
  - "neues Fachverfahren"
categories:
  - "Fachanwendungen und Microsoft Office \u003e Fachanwendung – Einführung einer Anwendung"
related:
  - "[[Wiki/Categories/fachanwendungen-und-microsoft-office-fachanwendung-einfuehrung-einer-anwendung|Fachanwendungen und Microsoft Office \u003e Fachanwendung – Einführung einer Anwendung]]"
---

# Fachanwendung – Einführung einer Anwendung

## Kontext / Problem

Auswahlziel: Fachanwendungen und Microsoft Office > Fachanwendung – Einführung einer Anwendung. Primär zuständiges Team: Fachanwendungen. Diese Kategorie ist auszuwählen, wenn ein neues Fachverfahren oder eine neue fachliche Software ausgewählt, beschafft, konfiguriert, migriert, getestet, geschult und produktiv eingeführt werden soll. Typische Ticketformulierungen sind: „Neues Fachverfahren einführen“; „Migration auf neue Anwendung“; „Pilotbetrieb einer Fachsoftware“; „Ablösung des Altsystems“. Nicht auswählen, wenn eine bestehende Anwendung nur aktualisiert oder erweitert wird oder lediglich Standardsoftware an einem Arbeitsplatz installiert werden soll. Für die Klassifizierung sind der konkret betroffene Dienst oder Gegenstand, die Fehlermeldung, die Anzahl betroffener Personen, der Standort sowie die Unterscheidung zwischen Störung, Berechtigung, Bestellung und Änderungswunsch besonders wichtig. Einzelne unspezifische Wörter wie „geht nicht“, „Problem“ oder „dringend“ reichen ohne Sachbezug nicht für diese Zuordnung aus. Abgrenzungsregel: Beschaffung, Datenschutz, Informationssicherheit und Infrastruktur sind je nach Umfang als Schnittstellen einzubeziehen.

## Lösung / Antwort

Interne Klassifizierung: Das Ticket ist der Kategorie „Fachanwendungen und Microsoft Office > Fachanwendung – Einführung einer Anwendung“ zuzuordnen. Primär zuständig ist „Fachanwendungen“. Vor der endgültigen Zuweisung sind die genannten Ausschlusskriterien und Schnittstellen zu prüfen.

## Verknüpfungen

- [[Wiki/Categories/fachanwendungen-und-microsoft-office-fachanwendung-einfuehrung-einer-anwendung|Fachanwendungen und Microsoft Office > Fachanwendung – Einführung einer Anwendung]] — Kategorie
- Quelle: `kb://internal-kb/glpi-kategorien/fachanwendungen-und-microsoft-office/fachanwendung-einfuhrung-einer-anwendung`
