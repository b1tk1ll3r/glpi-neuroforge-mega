---
type: "knowledge"
title: "Lizenzbestellung"
id: "KAT-LIZENZBESTELLUNG-SELECT"
source: "internal-category"
source_uri: "kb://internal-kb/glpi-kategorien/beschaffung-vertrage-und-lizenzen/lizenzbestellung"
language: "de-DE"
communication_style: "formal"
created: "2026-08-05"
updated: "2026-08-05"
auto_reply: false
min_score: 0.7
tags:
  - "Beschaffung, Verträge und Lizenzen"
  - "Lizenz bestellen"
  - "Lizenzbestellung"
  - "Seat"
  - "Subscription"
  - "Verlängerung"
  - "Volumenlizenz"
  - "zusätzliche Lizenz"
categories:
  - "Beschaffung, Verträge und Lizenzen \u003e Lizenzbestellung"
related:
  - "[[Wiki/Categories/beschaffung-vertraege-und-lizenzen-lizenzbestellung|Beschaffung, Verträge und Lizenzen \u003e Lizenzbestellung]]"
---

# Lizenzbestellung

## Kontext / Problem

Auswahlziel: Beschaffung, Verträge und Lizenzen > Lizenzbestellung. Primär zuständiges Team: Leitung und Finanzen / Beschaffung. Diese Kategorie ist auszuwählen, wenn zusätzliche Einzel-, Benutzer-, Geräte- oder Volumenlizenzen für bereits ausgewählte Produkte bestellt oder verlängert werden sollen. Typische Ticketformulierungen sind: „Zusätzliche Benutzerlizenz bestellen“; „Lizenz verlängern“; „Weitere Geräte lizenzieren“; „Volumenlizenz ergänzen“. Nicht auswählen, wenn nur die technische Aktivierung fehlschlägt, der gesamte Vertrag neu verhandelt oder der Lizenzbestand ausgewertet werden soll. Für die Klassifizierung sind der konkret betroffene Dienst oder Gegenstand, die Fehlermeldung, die Anzahl betroffener Personen, der Standort sowie die Unterscheidung zwischen Störung, Berechtigung, Bestellung und Änderungswunsch besonders wichtig. Einzelne unspezifische Wörter wie „geht nicht“, „Problem“ oder „dringend“ reichen ohne Sachbezug nicht für diese Zuordnung aus. Abgrenzungsregel: Produkt, Anzahl, Laufzeit, Kostenstelle und Genehmigung sollten angegeben werden.

## Lösung / Antwort

Interne Klassifizierung: Das Ticket ist der Kategorie „Beschaffung, Verträge und Lizenzen > Lizenzbestellung“ zuzuordnen. Primär zuständig ist „Leitung und Finanzen / Beschaffung“. Vor der endgültigen Zuweisung sind die genannten Ausschlusskriterien und Schnittstellen zu prüfen.

## Verknüpfungen

- [[Wiki/Categories/beschaffung-vertraege-und-lizenzen-lizenzbestellung|Beschaffung, Verträge und Lizenzen > Lizenzbestellung]] — Kategorie
- Quelle: `kb://internal-kb/glpi-kategorien/beschaffung-vertrage-und-lizenzen/lizenzbestellung`
