---
type: "knowledge"
title: "Sicherheitsupdate"
id: "KAT-SICHERHEITSUPDATE-SELECT"
source: "internal-category"
source_uri: "kb://internal-kb/glpi-kategorien/it-sicherheit-und-datensicherung/sicherheitsupdate"
language: "de-DE"
communication_style: "formal"
created: "2026-08-05"
updated: "2026-08-05"
auto_reply: false
min_score: 0.7
tags:
  - "CVE Patch"
  - "Herstellerwarnung"
  - "IT-Sicherheit und Datensicherung"
  - "Patchmanagement"
  - "Security Patch"
  - "Sicherheitsupdate"
  - "Update"
  - "Zero Day"
  - "kritischer Patch"
categories:
  - "IT-Sicherheit und Datensicherung \u003e Sicherheitsupdate"
related:
  - "[[Wiki/Categories/it-sicherheit-und-datensicherung-sicherheitsupdate|IT-Sicherheit und Datensicherung \u003e Sicherheitsupdate]]"
---

# Sicherheitsupdate

## Kontext / Problem

Auswahlziel: IT-Sicherheit und Datensicherung > Sicherheitsupdate. Primär zuständiges Team: Infrastruktur und Backend. Diese Kategorie ist auszuwählen, wenn ein sicherheitskritischer Patch, Herstellerhinweis oder dringendes Update bewertet, getestet und zeitnah auf Servern, Plattformen oder zentralen Komponenten ausgerollt werden soll. Typische Ticketformulierungen sind: „Kritischen Patch einspielen“; „Hersteller meldet Security Update“; „Zero-Day-Patch planen“; „Sicherheitsaktualisierung verteilen“. Nicht auswählen, wenn es um ein reguläres Fachanwendungsrelease, ein einzelnes Clientupdate ohne Sicherheitsbezug oder eine bereits ausgenutzte Schwachstelle geht. Für die Klassifizierung sind der konkret betroffene Dienst oder Gegenstand, die Fehlermeldung, die Anzahl betroffener Personen, der Standort sowie die Unterscheidung zwischen Störung, Berechtigung, Bestellung und Änderungswunsch besonders wichtig. Einzelne unspezifische Wörter wie „geht nicht“, „Problem“ oder „dringend“ reichen ohne Sachbezug nicht für diese Zuordnung aus. Abgrenzungsregel: Bei bestätigter aktiver Ausnutzung zusätzlich Sicherheitsvorfall wählen.

## Lösung / Antwort

Interne Klassifizierung: Das Ticket ist der Kategorie „IT-Sicherheit und Datensicherung > Sicherheitsupdate“ zuzuordnen. Primär zuständig ist „Infrastruktur und Backend“. Vor der endgültigen Zuweisung sind die genannten Ausschlusskriterien und Schnittstellen zu prüfen.

## Verknüpfungen

- [[Wiki/Categories/it-sicherheit-und-datensicherung-sicherheitsupdate|IT-Sicherheit und Datensicherung > Sicherheitsupdate]] — Kategorie
- Quelle: `kb://internal-kb/glpi-kategorien/it-sicherheit-und-datensicherung/sicherheitsupdate`
