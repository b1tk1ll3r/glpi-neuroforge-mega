---
type: "knowledge"
title: "Schulverwaltungsnetz"
id: "KAT-SCHULVERWALTUNGSNETZ-SELECT"
source: "internal-category"
source_uri: "kb://internal-kb/glpi-kategorien/schulspezifische-it-systeme/schulverwaltungsnetz"
language: "de-DE"
communication_style: "formal"
created: "2026-08-05"
updated: "2026-08-05"
auto_reply: false
min_score: 0.7
tags:
  - "Schulleitung Netzwerk"
  - "Schulspezifische IT-Systeme"
  - "Schulverwaltung"
  - "Schulverwaltungsnetz"
  - "Sekretariat Netzwerk"
  - "Verwaltungsnetz Schule"
categories:
  - "Schulspezifische IT-Systeme \u003e Schulverwaltungsnetz"
related:
  - "[[Wiki/Categories/schulspezifische-it-systeme-schulverwaltungsnetz|Schulspezifische IT-Systeme \u003e Schulverwaltungsnetz]]"
---

# Schulverwaltungsnetz

## Kontext / Problem

Auswahlziel: Schulspezifische IT-Systeme > Schulverwaltungsnetz. Primär zuständiges Team: Schulen. Diese Kategorie ist auszuwählen, wenn das getrennte Verwaltungsnetz einer Schule, Arbeitsplätze der Schulverwaltung oder schulverwaltungsspezifische Netzzugänge betroffen sind. Typische Ticketformulierungen sind: „Sekretariat ohne Verwaltungsnetz“; „Schulleitungs-PC erreicht Verwaltungsdienste nicht“; „Verwaltungs-WLAN gestört“. Nicht auswählen, wenn das pädagogische Schülernetz, eine konkrete Schulverwaltungsanwendung oder die gesamte Standortanbindung ausfällt. Für die Klassifizierung sind der konkret betroffene Dienst oder Gegenstand, die Fehlermeldung, die Anzahl betroffener Personen, der Standort sowie die Unterscheidung zwischen Störung, Berechtigung, Bestellung und Änderungswunsch besonders wichtig. Einzelne unspezifische Wörter wie „geht nicht“, „Problem“ oder „dringend“ reichen ohne Sachbezug nicht für diese Zuordnung aus. Abgrenzungsregel: Zentrale Netzwerkkomponenten werden durch Team Schulen qualifiziert und an Infrastruktur und Backend weitergegeben.

## Lösung / Antwort

Interne Klassifizierung: Das Ticket ist der Kategorie „Schulspezifische IT-Systeme > Schulverwaltungsnetz“ zuzuordnen. Primär zuständig ist „Schulen“. Vor der endgültigen Zuweisung sind die genannten Ausschlusskriterien und Schnittstellen zu prüfen.

## Verknüpfungen

- [[Wiki/Categories/schulspezifische-it-systeme-schulverwaltungsnetz|Schulspezifische IT-Systeme > Schulverwaltungsnetz]] — Kategorie
- Quelle: `kb://internal-kb/glpi-kategorien/schulspezifische-it-systeme/schulverwaltungsnetz`
