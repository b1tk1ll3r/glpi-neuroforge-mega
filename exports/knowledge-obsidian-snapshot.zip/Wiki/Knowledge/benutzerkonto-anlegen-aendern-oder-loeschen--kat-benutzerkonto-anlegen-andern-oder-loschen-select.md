---
type: "knowledge"
title: "Benutzerkonto anlegen, ändern oder löschen"
id: "KAT-BENUTZERKONTO-ANLEGEN-ANDERN-ODER-LOSCHEN-SELECT"
source: "internal-category"
source_uri: "kb://internal-kb/glpi-kategorien/benutzerkonten-und-berechtigungen/benutzerkonto-anlegen-andern-oder-loschen"
language: "de-DE"
communication_style: "formal"
created: "2026-08-05"
updated: "2026-08-05"
auto_reply: false
min_score: 0.7
tags:
  - "AD-Benutzer"
  - "Account erstellen"
  - "Austritt"
  - "Benutzerkonten und Berechtigungen"
  - "Benutzerkonto anlegen"
  - "Benutzerkonto anlegen, ändern oder löschen"
  - "Eintritt"
  - "Konto deaktivieren"
  - "Konto löschen"
  - "Namensänderung"
  - "Organisationseinheit"
  - "Versetzung"
  - "neuer Mitarbeiter"
categories:
  - "Benutzerkonten und Berechtigungen \u003e Benutzerkonto anlegen, ändern oder löschen"
related:
  - "[[Wiki/Categories/benutzerkonten-und-berechtigungen-benutzerkonto-anlegen-aendern-oder-loeschen|Benutzerkonten und Berechtigungen \u003e Benutzerkonto anlegen, ändern oder löschen]]"
---

# Benutzerkonto anlegen, ändern oder löschen

## Kontext / Problem

Auswahlziel: Benutzerkonten und Berechtigungen > Benutzerkonto anlegen, ändern oder löschen. Primär zuständiges Team: Infrastruktur und Backend. Diese Kategorie ist auszuwählen, wenn ein persönliches Benutzerkonto für Eintritt, Versetzung, Namensänderung, Organisationswechsel, längere Abwesenheit oder Austritt erstellt, angepasst, deaktiviert oder gelöscht werden muss. Dazu zählen technische Kontodaten im zentralen Verzeichnisdienst. Typische Ticketformulierungen sind: „Neuer Mitarbeiter benötigt ein Konto“; „Nachname hat sich geändert“; „Konto zum Austritt deaktivieren“; „Benutzer in andere Organisationseinheit verschieben“. Nicht auswählen, wenn nur ein Kennwort zurückgesetzt werden muss; wenn ausschließlich eine Rolle in einer Fachanwendung betroffen ist; wenn ein Funktionspostfach benötigt wird. Für die Klassifizierung sind der konkret betroffene Dienst oder Gegenstand, die Fehlermeldung, die Anzahl betroffener Personen, der Standort sowie die Unterscheidung zwischen Störung, Berechtigung, Bestellung und Änderungswunsch besonders wichtig. Einzelne unspezifische Wörter wie „geht nicht“, „Problem“ oder „dringend“ reichen ohne Sachbezug nicht für diese Zuordnung aus. Abgrenzungsregel: Fachliche Berechtigungen werden nicht automatisch mit dieser Kategorie abgedeckt und müssen gegebenenfalls separat beantragt werden.

## Lösung / Antwort

Interne Klassifizierung: Das Ticket ist der Kategorie „Benutzerkonten und Berechtigungen > Benutzerkonto anlegen, ändern oder löschen“ zuzuordnen. Primär zuständig ist „Infrastruktur und Backend“. Vor der endgültigen Zuweisung sind die genannten Ausschlusskriterien und Schnittstellen zu prüfen.

## Verknüpfungen

- [[Wiki/Categories/benutzerkonten-und-berechtigungen-benutzerkonto-anlegen-aendern-oder-loeschen|Benutzerkonten und Berechtigungen > Benutzerkonto anlegen, ändern oder löschen]] — Kategorie
- Quelle: `kb://internal-kb/glpi-kategorien/benutzerkonten-und-berechtigungen/benutzerkonto-anlegen-andern-oder-loschen`
