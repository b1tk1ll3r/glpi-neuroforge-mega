---
type: "knowledge"
title: "Verbrauchsmaterial"
id: "KAT-VERBRAUCHSMATERIAL-SELECT"
source: "internal-category"
source_uri: "kb://internal-kb/glpi-kategorien/drucken-scannen-und-kopieren/verbrauchsmaterial"
language: "de-DE"
communication_style: "formal"
created: "2026-08-05"
updated: "2026-08-05"
auto_reply: false
min_score: 0.7
tags:
  - "Drucken, Scannen und Kopieren"
  - "Druckerzubehör"
  - "Kartusche"
  - "Resttoner"
  - "Toner"
  - "Trommel"
  - "Verbrauchsmaterial"
  - "bestellen"
  - "leer"
categories:
  - "Drucken, Scannen und Kopieren \u003e Verbrauchsmaterial"
related:
  - "[[Wiki/Categories/drucken-scannen-und-kopieren-verbrauchsmaterial|Drucken, Scannen und Kopieren \u003e Verbrauchsmaterial]]"
---

# Verbrauchsmaterial

## Kontext / Problem

Auswahlziel: Drucken, Scannen und Kopieren > Verbrauchsmaterial. Primär zuständiges Team: Support und Telekommunikation. Diese Kategorie ist auszuwählen, wenn Toner, Trommel, Resttonerbehälter, Heftklammern oder anderes Verbrauchsmaterial für Drucker und Kopierer benötigt oder als leer gemeldet wird. Typische Ticketformulierungen sind: „Toner leer“; „Neue Trommel benötigt“; „Resttonerbehälter voll“; „Verbrauchsmaterial bestellen“. Nicht auswählen, wenn das Gerät trotz vorhandenem Material defekt ist oder eine allgemeine Hardwarebeschaffung ansteht. Für die Klassifizierung sind der konkret betroffene Dienst oder Gegenstand, die Fehlermeldung, die Anzahl betroffener Personen, der Standort sowie die Unterscheidung zwischen Störung, Berechtigung, Bestellung und Änderungswunsch besonders wichtig. Einzelne unspezifische Wörter wie „geht nicht“, „Problem“ oder „dringend“ reichen ohne Sachbezug nicht für diese Zuordnung aus. Abgrenzungsregel: Bestellprozess und Lagerhaltung können je nach Organisation bei Support oder Beschaffung liegen.

## Lösung / Antwort

Interne Klassifizierung: Das Ticket ist der Kategorie „Drucken, Scannen und Kopieren > Verbrauchsmaterial“ zuzuordnen. Primär zuständig ist „Support und Telekommunikation“. Vor der endgültigen Zuweisung sind die genannten Ausschlusskriterien und Schnittstellen zu prüfen.

## Verknüpfungen

- [[Wiki/Categories/drucken-scannen-und-kopieren-verbrauchsmaterial|Drucken, Scannen und Kopieren > Verbrauchsmaterial]] — Kategorie
- Quelle: `kb://internal-kb/glpi-kategorien/drucken-scannen-und-kopieren/verbrauchsmaterial`
