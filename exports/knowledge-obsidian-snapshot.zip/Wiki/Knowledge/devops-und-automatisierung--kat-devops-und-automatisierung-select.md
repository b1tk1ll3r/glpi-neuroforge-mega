---
type: "knowledge"
title: "DevOps und Automatisierung"
id: "KAT-DEVOPS-UND-AUTOMATISIERUNG-SELECT"
source: "internal-category"
source_uri: "kb://internal-kb/glpi-kategorien/server-backend-und-plattformen/devops-und-automatisierung"
language: "de-DE"
communication_style: "formal"
created: "2026-08-05"
updated: "2026-08-05"
auto_reply: false
min_score: 0.7
tags:
  - "Ansible"
  - "Automation"
  - "Build"
  - "CI/CD"
  - "Deployment"
  - "DevOps"
  - "DevOps und Automatisierung"
  - "Infrastructure as Code"
  - "Pipeline"
  - "Server, Backend und Plattformen"
  - "Terraform"
categories:
  - "Server, Backend und Plattformen \u003e DevOps und Automatisierung"
related:
  - "[[Wiki/Categories/server-backend-und-plattformen-devops-und-automatisierung|Server, Backend und Plattformen \u003e DevOps und Automatisierung]]"
---

# DevOps und Automatisierung

## Kontext / Problem

Auswahlziel: Server, Backend und Plattformen > DevOps und Automatisierung. Primär zuständiges Team: Infrastruktur und Backend. Diese Kategorie ist auszuwählen, wenn CI/CD-Pipelines, automatisierte Deployments, Infrastrukturcode, Konfigurationsmanagement, Build-Prozesse oder technische Automatisierungen erstellt oder gestört sind. Typische Ticketformulierungen sind: „Pipeline schlägt fehl“; „Deployment automatisieren“; „Ansible-Playbook anpassen“; „Infrastructure as Code bereitstellen“. Nicht auswählen, wenn nur ein Kubernetes-Pod ausfällt, eine normale Softwareinstallation am Arbeitsplatz benötigt wird oder ein fachlicher Workflow innerhalb einer Anwendung gemeint ist. Für die Klassifizierung sind der konkret betroffene Dienst oder Gegenstand, die Fehlermeldung, die Anzahl betroffener Personen, der Standort sowie die Unterscheidung zwischen Störung, Berechtigung, Bestellung und Änderungswunsch besonders wichtig. Einzelne unspezifische Wörter wie „geht nicht“, „Problem“ oder „dringend“ reichen ohne Sachbezug nicht für diese Zuordnung aus. Abgrenzungsregel: Fachanwendungsbezogene Releaseentscheidungen liegen bei Fachanwendungen; technische Delivery-Plattform bei Infrastruktur.

## Lösung / Antwort

Interne Klassifizierung: Das Ticket ist der Kategorie „Server, Backend und Plattformen > DevOps und Automatisierung“ zuzuordnen. Primär zuständig ist „Infrastruktur und Backend“. Vor der endgültigen Zuweisung sind die genannten Ausschlusskriterien und Schnittstellen zu prüfen.

## Verknüpfungen

- [[Wiki/Categories/server-backend-und-plattformen-devops-und-automatisierung|Server, Backend und Plattformen > DevOps und Automatisierung]] — Kategorie
- Quelle: `kb://internal-kb/glpi-kategorien/server-backend-und-plattformen/devops-und-automatisierung`
