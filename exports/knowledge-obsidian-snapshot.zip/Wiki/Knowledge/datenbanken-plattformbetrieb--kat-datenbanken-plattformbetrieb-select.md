---
type: "knowledge"
title: "Datenbanken – Plattformbetrieb"
id: "KAT-DATENBANKEN-PLATTFORMBETRIEB-SELECT"
source: "internal-category"
source_uri: "kb://internal-kb/glpi-kategorien/server-backend-und-plattformen/datenbanken-plattformbetrieb"
language: "de-DE"
communication_style: "formal"
created: "2026-08-05"
updated: "2026-08-05"
auto_reply: false
min_score: 0.7
tags:
  - "DB-Backup"
  - "Datenbank"
  - "Datenbanken – Plattformbetrieb"
  - "Datenbankperformance"
  - "Instanz"
  - "MySQL"
  - "Oracle"
  - "PostgreSQL"
  - "SQL"
  - "SQL Server"
  - "Server, Backend und Plattformen"
categories:
  - "Server, Backend und Plattformen \u003e Datenbanken – Plattformbetrieb"
related:
  - "[[Wiki/Categories/server-backend-und-plattformen-datenbanken-plattformbetrieb|Server, Backend und Plattformen \u003e Datenbanken – Plattformbetrieb]]"
---

# Datenbanken – Plattformbetrieb

## Kontext / Problem

Auswahlziel: Server, Backend und Plattformen > Datenbanken – Plattformbetrieb. Primär zuständiges Team: Infrastruktur und Backend. Diese Kategorie ist auszuwählen, wenn der zentrale Datenbankdienst, die Datenbankinstanz, Verfügbarkeit, Sicherung, Performance oder technische Administration von SQL-Plattformen betroffen ist. Typische Ticketformulierungen sind: „SQL-Server nicht erreichbar“; „Datenbankinstanz langsam“; „Backup der Datenbank fehlerhaft“; „Neue Datenbank technisch bereitstellen“. Nicht auswählen, wenn fachliche Daten korrigiert, Berichte angepasst oder anwendungsspezifische Tabelleninhalte verändert werden sollen. Für die Klassifizierung sind der konkret betroffene Dienst oder Gegenstand, die Fehlermeldung, die Anzahl betroffener Personen, der Standort sowie die Unterscheidung zwischen Störung, Berechtigung, Bestellung und Änderungswunsch besonders wichtig. Einzelne unspezifische Wörter wie „geht nicht“, „Problem“ oder „dringend“ reichen ohne Sachbezug nicht für diese Zuordnung aus. Abgrenzungsregel: Fachliches Datenmodell und Datenkorrekturen liegen bei Fachanwendungen; Plattformbetrieb bei Infrastruktur.

## Lösung / Antwort

Interne Klassifizierung: Das Ticket ist der Kategorie „Server, Backend und Plattformen > Datenbanken – Plattformbetrieb“ zuzuordnen. Primär zuständig ist „Infrastruktur und Backend“. Vor der endgültigen Zuweisung sind die genannten Ausschlusskriterien und Schnittstellen zu prüfen.

## Verknüpfungen

- [[Wiki/Categories/server-backend-und-plattformen-datenbanken-plattformbetrieb|Server, Backend und Plattformen > Datenbanken – Plattformbetrieb]] — Kategorie
- Quelle: `kb://internal-kb/glpi-kategorien/server-backend-und-plattformen/datenbanken-plattformbetrieb`
