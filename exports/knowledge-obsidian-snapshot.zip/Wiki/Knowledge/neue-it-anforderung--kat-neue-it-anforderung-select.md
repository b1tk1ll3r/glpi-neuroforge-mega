---
type: "knowledge"
title: "Neue IT-Anforderung"
id: "KAT-NEUE-IT-ANFORDERUNG-SELECT"
source: "internal-category"
source_uri: "kb://internal-kb/glpi-kategorien/projekte-anderungen-und-neue-anforderungen/neue-it-anforderung"
language: "de-DE"
communication_style: "formal"
created: "2026-08-05"
updated: "2026-08-05"
auto_reply: false
min_score: 0.7
tags:
  - "Anforderung"
  - "Bedarf"
  - "Digitalisierung"
  - "Idee"
  - "Projekte, Änderungen und neue Anforderungen"
  - "Prüfauftrag"
  - "neue IT-Anforderung"
  - "neue Lösung"
  - "neuer Service"
categories:
  - "Projekte, Änderungen und neue Anforderungen \u003e Neue IT-Anforderung"
related:
  - "[[Wiki/Categories/projekte-aenderungen-und-neue-anforderungen-neue-it-anforderung|Projekte, Änderungen und neue Anforderungen \u003e Neue IT-Anforderung]]"
---

# Neue IT-Anforderung

## Kontext / Problem

Auswahlziel: Projekte, Änderungen und neue Anforderungen > Neue IT-Anforderung. Primär zuständiges Team: Leitung und Finanzen / Beschaffung. Diese Kategorie ist auszuwählen, wenn ein bislang nicht vorhandener IT-Service, eine neue technische Fähigkeit oder ein organisationsübergreifender Bedarf zunächst bewertet, priorisiert und einem Fachteam zugeordnet werden soll. Typische Ticketformulierungen sind: „Neuen digitalen Dienst prüfen“; „Zusätzlichen IT-Service bereitstellen“; „Neue technische Lösung benötigt“; „Unklarer neuer IT-Bedarf“. Nicht auswählen, wenn die Lösung bereits eindeutig eine bestehende Fachanwendung betrifft, nur Hardware bestellt oder eine normale Störung gemeldet wird. Für die Klassifizierung sind der konkret betroffene Dienst oder Gegenstand, die Fehlermeldung, die Anzahl betroffener Personen, der Standort sowie die Unterscheidung zwischen Störung, Berechtigung, Bestellung und Änderungswunsch besonders wichtig. Einzelne unspezifische Wörter wie „geht nicht“, „Problem“ oder „dringend“ reichen ohne Sachbezug nicht für diese Zuordnung aus. Abgrenzungsregel: Diese Kategorie dient der qualifizierten Erstbewertung; danach erfolgt Übergabe an das zuständige Fachteam oder Projekt.

## Lösung / Antwort

Interne Klassifizierung: Das Ticket ist der Kategorie „Projekte, Änderungen und neue Anforderungen > Neue IT-Anforderung“ zuzuordnen. Primär zuständig ist „Leitung und Finanzen / Beschaffung“. Vor der endgültigen Zuweisung sind die genannten Ausschlusskriterien und Schnittstellen zu prüfen.

## Verknüpfungen

- [[Wiki/Categories/projekte-aenderungen-und-neue-anforderungen-neue-it-anforderung|Projekte, Änderungen und neue Anforderungen > Neue IT-Anforderung]] — Kategorie
- Quelle: `kb://internal-kb/glpi-kategorien/projekte-anderungen-und-neue-anforderungen/neue-it-anforderung`
