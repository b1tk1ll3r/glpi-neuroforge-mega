---
type: "knowledge"
title: "Inventarisierung"
id: "KAT-INVENTARISIERUNG-SELECT"
source: "internal-category"
source_uri: "kb://internal-kb/glpi-kategorien/beschaffung-vertrage-und-lizenzen/inventarisierung"
language: "de-DE"
communication_style: "formal"
created: "2026-08-05"
updated: "2026-08-05"
auto_reply: false
min_score: 0.7
tags:
  - "Anlagegut"
  - "Asset"
  - "Beschaffung, Verträge und Lizenzen"
  - "Bestand"
  - "Gerätezuordnung"
  - "Inventarisierung"
  - "Inventarnummer"
  - "Standortzuordnung"
  - "Umbuchung"
categories:
  - "Beschaffung, Verträge und Lizenzen \u003e Inventarisierung"
related:
  - "[[Wiki/Categories/beschaffung-vertraege-und-lizenzen-inventarisierung|Beschaffung, Verträge und Lizenzen \u003e Inventarisierung]]"
---

# Inventarisierung

## Kontext / Problem

Auswahlziel: Beschaffung, Verträge und Lizenzen > Inventarisierung. Primär zuständiges Team: Leitung und Finanzen / Beschaffung. Diese Kategorie ist auszuwählen, wenn ein IT-Asset neu inventarisiert, einer Person oder einem Standort zugeordnet, umgebucht, korrigiert oder im Bestand dokumentiert werden soll. Typische Ticketformulierungen sind: „Inventarnummer anlegen“; „Gerät anderem Standort zuordnen“; „Asset-Daten korrigieren“; „Bestand übernehmen“. Nicht auswählen, wenn ein Gerät physisch zurückgegeben, technisch repariert oder endgültig entsorgt werden soll. Für die Klassifizierung sind der konkret betroffene Dienst oder Gegenstand, die Fehlermeldung, die Anzahl betroffener Personen, der Standort sowie die Unterscheidung zwischen Störung, Berechtigung, Bestellung und Änderungswunsch besonders wichtig. Einzelne unspezifische Wörter wie „geht nicht“, „Problem“ oder „dringend“ reichen ohne Sachbezug nicht für diese Zuordnung aus. Abgrenzungsregel: Physische Rücknahme und Datenlöschung liegen beim Support; kaufmännischer Asset-Status bei Beschaffung.

## Lösung / Antwort

Interne Klassifizierung: Das Ticket ist der Kategorie „Beschaffung, Verträge und Lizenzen > Inventarisierung“ zuzuordnen. Primär zuständig ist „Leitung und Finanzen / Beschaffung“. Vor der endgültigen Zuweisung sind die genannten Ausschlusskriterien und Schnittstellen zu prüfen.

## Verknüpfungen

- [[Wiki/Categories/beschaffung-vertraege-und-lizenzen-inventarisierung|Beschaffung, Verträge und Lizenzen > Inventarisierung]] — Kategorie
- Quelle: `kb://internal-kb/glpi-kategorien/beschaffung-vertrage-und-lizenzen/inventarisierung`
