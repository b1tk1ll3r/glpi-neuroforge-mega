---
type: "knowledge"
title: "Fachanwendung – Störung"
id: "KAT-FACHANWENDUNG-STORUNG-SELECT"
source: "internal-category"
source_uri: "kb://internal-kb/glpi-kategorien/fachanwendungen-und-microsoft-office/fachanwendung-storung"
language: "de-DE"
communication_style: "formal"
created: "2026-08-05"
updated: "2026-08-05"
auto_reply: false
min_score: 0.7
tags:
  - "Anwendungsfehler"
  - "Fachanwendung"
  - "Fachanwendung – Störung"
  - "Fachanwendungen und Microsoft Office"
  - "Fachverfahren"
  - "Fehlermeldung"
  - "Maske"
  - "Modul"
  - "Störung"
  - "Verarbeitung abgebrochen"
  - "funktioniert nicht"
categories:
  - "Fachanwendungen und Microsoft Office \u003e Fachanwendung – Störung"
related:
  - "[[Wiki/Categories/fachanwendungen-und-microsoft-office-fachanwendung-stoerung|Fachanwendungen und Microsoft Office \u003e Fachanwendung – Störung]]"
---

# Fachanwendung – Störung

## Kontext / Problem

Auswahlziel: Fachanwendungen und Microsoft Office > Fachanwendung – Störung. Primär zuständiges Team: Fachanwendungen. Diese Kategorie ist auszuwählen, wenn eine konkrete Fachanwendung eine Fehlermeldung zeigt, eine fachliche Funktion nicht arbeitet, Masken nicht laden, Verarbeitungsschritte abbrechen oder einzelne Module nicht verfügbar sind. Typische Ticketformulierungen sind: „Fachverfahren zeigt Fehler“; „Buchung kann nicht abgeschlossen werden“; „Maske bleibt leer“; „Modul startet nicht“. Nicht auswählen, wenn das Problem ausschließlich durch Netzwerk, Serverplattform, Datenbankplattform oder das zentrale Benutzerkonto verursacht wird; wenn es sich nur um eine Bedienungsfrage oder neue Anforderung handelt. Für die Klassifizierung sind der konkret betroffene Dienst oder Gegenstand, die Fehlermeldung, die Anzahl betroffener Personen, der Standort sowie die Unterscheidung zwischen Störung, Berechtigung, Bestellung und Änderungswunsch besonders wichtig. Einzelne unspezifische Wörter wie „geht nicht“, „Problem“ oder „dringend“ reichen ohne Sachbezug nicht für diese Zuordnung aus. Abgrenzungsregel: Die konkrete Anwendung, Fehlermeldung, betroffene Funktion und Anzahl der Betroffenen sind entscheidend.

## Lösung / Antwort

Interne Klassifizierung: Das Ticket ist der Kategorie „Fachanwendungen und Microsoft Office > Fachanwendung – Störung“ zuzuordnen. Primär zuständig ist „Fachanwendungen“. Vor der endgültigen Zuweisung sind die genannten Ausschlusskriterien und Schnittstellen zu prüfen.

## Verknüpfungen

- [[Wiki/Categories/fachanwendungen-und-microsoft-office-fachanwendung-stoerung|Fachanwendungen und Microsoft Office > Fachanwendung – Störung]] — Kategorie
- Quelle: `kb://internal-kb/glpi-kategorien/fachanwendungen-und-microsoft-office/fachanwendung-storung`
