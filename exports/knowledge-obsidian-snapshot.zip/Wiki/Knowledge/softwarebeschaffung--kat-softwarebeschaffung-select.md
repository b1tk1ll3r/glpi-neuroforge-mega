---
type: "knowledge"
title: "Softwarebeschaffung"
id: "KAT-SOFTWAREBESCHAFFUNG-SELECT"
source: "internal-category"
source_uri: "kb://internal-kb/glpi-kategorien/beschaffung-vertrage-und-lizenzen/softwarebeschaffung"
language: "de-DE"
communication_style: "formal"
created: "2026-08-05"
updated: "2026-08-05"
auto_reply: false
min_score: 0.7
tags:
  - "Abonnement"
  - "Angebot Software"
  - "Beschaffung, Verträge und Lizenzen"
  - "Bestellung Software"
  - "Lizenz kaufen"
  - "SaaS"
  - "Software kaufen"
  - "Softwarebeschaffung"
categories:
  - "Beschaffung, Verträge und Lizenzen \u003e Softwarebeschaffung"
related:
  - "[[Wiki/Categories/beschaffung-vertraege-und-lizenzen-softwarebeschaffung|Beschaffung, Verträge und Lizenzen \u003e Softwarebeschaffung]]"
---

# Softwarebeschaffung

## Kontext / Problem

Auswahlziel: Beschaffung, Verträge und Lizenzen > Softwarebeschaffung. Primär zuständiges Team: Leitung und Finanzen / Beschaffung. Diese Kategorie ist auszuwählen, wenn neue Software, ein neues Produkt, ein Abonnement oder eine kostenpflichtige Erweiterung beschafft und vertraglich beauftragt werden soll. Typische Ticketformulierungen sind: „Neue Software kaufen“; „SaaS-Angebot beauftragen“; „Kostenpflichtiges Modul beschaffen“; „Softwareangebot prüfen“. Nicht auswählen, wenn bereits freigegebene Software nur installiert, eine Fachanwendung eingeführt oder eine vorhandene Lizenz technisch nicht erkannt wird. Für die Klassifizierung sind der konkret betroffene Dienst oder Gegenstand, die Fehlermeldung, die Anzahl betroffener Personen, der Standort sowie die Unterscheidung zwischen Störung, Berechtigung, Bestellung und Änderungswunsch besonders wichtig. Einzelne unspezifische Wörter wie „geht nicht“, „Problem“ oder „dringend“ reichen ohne Sachbezug nicht für diese Zuordnung aus. Abgrenzungsregel: Technische, datenschutzrechtliche und sicherheitsbezogene Prüfung erfolgt vor Beauftragung.

## Lösung / Antwort

Interne Klassifizierung: Das Ticket ist der Kategorie „Beschaffung, Verträge und Lizenzen > Softwarebeschaffung“ zuzuordnen. Primär zuständig ist „Leitung und Finanzen / Beschaffung“. Vor der endgültigen Zuweisung sind die genannten Ausschlusskriterien und Schnittstellen zu prüfen.

## Verknüpfungen

- [[Wiki/Categories/beschaffung-vertraege-und-lizenzen-softwarebeschaffung|Beschaffung, Verträge und Lizenzen > Softwarebeschaffung]] — Kategorie
- Quelle: `kb://internal-kb/glpi-kategorien/beschaffung-vertrage-und-lizenzen/softwarebeschaffung`
