---
type: "knowledge"
title: "Kubernetes"
id: "KAT-KUBERNETES-SELECT"
source: "internal-category"
source_uri: "kb://internal-kb/glpi-kategorien/server-backend-und-plattformen/kubernetes"
language: "de-DE"
communication_style: "formal"
created: "2026-08-05"
updated: "2026-08-05"
auto_reply: false
min_score: 0.7
tags:
  - "Cluster"
  - "Deployment"
  - "Ingress"
  - "K8s"
  - "Kubernetes"
  - "Namespace"
  - "Node"
  - "Pod"
  - "Server, Backend und Plattformen"
  - "Service"
categories:
  - "Server, Backend und Plattformen \u003e Kubernetes"
related:
  - "[[Wiki/Categories/server-backend-und-plattformen-kubernetes|Server, Backend und Plattformen \u003e Kubernetes]]"
---

# Kubernetes

## Kontext / Problem

Auswahlziel: Server, Backend und Plattformen > Kubernetes. Primär zuständiges Team: Infrastruktur und Backend. Diese Kategorie ist auszuwählen, wenn Kubernetes-Cluster, Nodes, Namespaces, Deployments, Services, Ingress, Pods oder clusterbezogene Plattformdienste betroffen sind. Typische Ticketformulierungen sind: „Pod startet nicht“; „Deployment fehlerhaft“; „Namespace anlegen“; „Kubernetes-Cluster erweitern“. Nicht auswählen, wenn nur ein einzelner Docker-Host ohne Kubernetes, eine klassische VM oder eine fachliche Anwendung ohne Clusterbezug gemeint ist. Für die Klassifizierung sind der konkret betroffene Dienst oder Gegenstand, die Fehlermeldung, die Anzahl betroffener Personen, der Standort sowie die Unterscheidung zwischen Störung, Berechtigung, Bestellung und Änderungswunsch besonders wichtig. Einzelne unspezifische Wörter wie „geht nicht“, „Problem“ oder „dringend“ reichen ohne Sachbezug nicht für diese Zuordnung aus. Abgrenzungsregel: Anwendungsdeployment kann mit DevOps zusammenhängen; Clusterbetrieb bleibt in dieser Kategorie.

## Lösung / Antwort

Interne Klassifizierung: Das Ticket ist der Kategorie „Server, Backend und Plattformen > Kubernetes“ zuzuordnen. Primär zuständig ist „Infrastruktur und Backend“. Vor der endgültigen Zuweisung sind die genannten Ausschlusskriterien und Schnittstellen zu prüfen.

## Verknüpfungen

- [[Wiki/Categories/server-backend-und-plattformen-kubernetes|Server, Backend und Plattformen > Kubernetes]] — Kategorie
- Quelle: `kb://internal-kb/glpi-kategorien/server-backend-und-plattformen/kubernetes`
