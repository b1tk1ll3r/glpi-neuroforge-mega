---
type: "knowledge"
title: "Serverbetrieb"
id: "KAT-SERVERBETRIEB-SELECT"
source: "internal-category"
source_uri: "kb://internal-kb/glpi-kategorien/server-backend-und-plattformen/serverbetrieb"
language: "de-DE"
communication_style: "formal"
created: "2026-08-05"
updated: "2026-08-05"
auto_reply: false
min_score: 0.7
tags:
  - "Betriebssystem Server"
  - "Dienst"
  - "Linux Server"
  - "Patchen"
  - "Server"
  - "Server, Backend und Plattformen"
  - "Serverausfall"
  - "Serverbetrieb"
  - "Systemdienst"
  - "Windows Server"
categories:
  - "Server, Backend und Plattformen \u003e Serverbetrieb"
related:
  - "[[Wiki/Categories/server-backend-und-plattformen-serverbetrieb|Server, Backend und Plattformen \u003e Serverbetrieb]]"
---

# Serverbetrieb

## Kontext / Problem

Auswahlziel: Server, Backend und Plattformen > Serverbetrieb. Primär zuständiges Team: Infrastruktur und Backend. Diese Kategorie ist auszuwählen, wenn ein Windows- oder Linux-Server als Betriebssystemplattform ausfällt, gewartet, gepatcht, konfiguriert oder analysiert werden muss. Typische Ticketformulierungen sind: „Server nicht erreichbar“; „Linux-Dienst startet nicht“; „Windows Server patchen“; „Serverleistung analysieren“. Nicht auswählen, wenn ausschließlich eine darauf laufende Fachanwendung, virtuelle Maschine, Datenbank, Containerplattform oder ein Arbeitsplatz-PC betroffen ist. Für die Klassifizierung sind der konkret betroffene Dienst oder Gegenstand, die Fehlermeldung, die Anzahl betroffener Personen, der Standort sowie die Unterscheidung zwischen Störung, Berechtigung, Bestellung und Änderungswunsch besonders wichtig. Einzelne unspezifische Wörter wie „geht nicht“, „Problem“ oder „dringend“ reichen ohne Sachbezug nicht für diese Zuordnung aus. Abgrenzungsregel: Die konkrete Anwendungsebene wird getrennt klassifiziert; diese Kategorie betrifft die Serverplattform selbst.

## Lösung / Antwort

Interne Klassifizierung: Das Ticket ist der Kategorie „Server, Backend und Plattformen > Serverbetrieb“ zuzuordnen. Primär zuständig ist „Infrastruktur und Backend“. Vor der endgültigen Zuweisung sind die genannten Ausschlusskriterien und Schnittstellen zu prüfen.

## Verknüpfungen

- [[Wiki/Categories/server-backend-und-plattformen-serverbetrieb|Server, Backend und Plattformen > Serverbetrieb]] — Kategorie
- Quelle: `kb://internal-kb/glpi-kategorien/server-backend-und-plattformen/serverbetrieb`
