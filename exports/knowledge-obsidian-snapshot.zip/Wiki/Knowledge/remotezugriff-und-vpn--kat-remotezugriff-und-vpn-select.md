---
type: "knowledge"
title: "Remotezugriff und VPN"
id: "KAT-REMOTEZUGRIFF-UND-VPN-SELECT"
source: "internal-category"
source_uri: "kb://internal-kb/glpi-kategorien/benutzerkonten-und-berechtigungen/remotezugriff-und-vpn"
language: "de-DE"
communication_style: "formal"
created: "2026-08-05"
updated: "2026-08-05"
auto_reply: false
min_score: 0.7
tags:
  - "Benutzerkonten und Berechtigungen"
  - "Bereitschaft"
  - "Fernzugriff"
  - "Freischaltung VPN"
  - "Homeoffice"
  - "Remote Access"
  - "Remotezugriff"
  - "Remotezugriff und VPN"
  - "VPN-Zugang"
  - "Zugriff von außen"
  - "externer Zugriff"
categories:
  - "Benutzerkonten und Berechtigungen \u003e Remotezugriff und VPN"
related:
  - "[[Wiki/Categories/benutzerkonten-und-berechtigungen-remotezugriff-und-vpn|Benutzerkonten und Berechtigungen \u003e Remotezugriff und VPN]]"
---

# Remotezugriff und VPN

## Kontext / Problem

Auswahlziel: Benutzerkonten und Berechtigungen > Remotezugriff und VPN. Primär zuständiges Team: Infrastruktur und Backend. Diese Kategorie ist auszuwählen, wenn ein neuer oder geänderter Fernzugriff auf interne Systeme benötigt wird, ein VPN-Zugang beantragt werden soll oder Zugriffsrechte für Homeoffice, Bereitschaft oder externe Administration eingerichtet werden müssen. Typische Ticketformulierungen sind: „VPN-Zugang beantragen“; „Homeoffice-Zugriff freischalten“; „Remotezugriff für Bereitschaft“; „Externer Dienstleister benötigt zeitlich begrenzten Zugang“. Nicht auswählen, wenn ein bereits eingerichteter VPN-Tunnel technisch nicht verbindet; dafür ist die Kategorie Netzwerk und Verbindungen > VPN vorgesehen. Ein allgemeines Kennwortproblem gehört zu Kennwort zurücksetzen. Für die Klassifizierung sind der konkret betroffene Dienst oder Gegenstand, die Fehlermeldung, die Anzahl betroffener Personen, der Standort sowie die Unterscheidung zwischen Störung, Berechtigung, Bestellung und Änderungswunsch besonders wichtig. Einzelne unspezifische Wörter wie „geht nicht“, „Problem“ oder „dringend“ reichen ohne Sachbezug nicht für diese Zuordnung aus. Abgrenzungsregel: Diese Kategorie beschreibt die Berechtigung beziehungsweise Bereitstellung. Technische Verbindungsstörungen eines vorhandenen VPN werden unter Netzwerk > VPN erfasst.

## Lösung / Antwort

Interne Klassifizierung: Das Ticket ist der Kategorie „Benutzerkonten und Berechtigungen > Remotezugriff und VPN“ zuzuordnen. Primär zuständig ist „Infrastruktur und Backend“. Vor der endgültigen Zuweisung sind die genannten Ausschlusskriterien und Schnittstellen zu prüfen.

## Verknüpfungen

- [[Wiki/Categories/benutzerkonten-und-berechtigungen-remotezugriff-und-vpn|Benutzerkonten und Berechtigungen > Remotezugriff und VPN]] — Kategorie
- Quelle: `kb://internal-kb/glpi-kategorien/benutzerkonten-und-berechtigungen/remotezugriff-und-vpn`
