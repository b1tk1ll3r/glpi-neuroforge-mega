---
type: "knowledge"
title: "Microsoft PowerPoint"
id: "KAT-MICROSOFT-POWERPOINT-SELECT"
source: "internal-category"
source_uri: "kb://internal-kb/glpi-kategorien/fachanwendungen-und-microsoft-office/microsoft-powerpoint"
language: "de-DE"
communication_style: "formal"
created: "2026-08-05"
updated: "2026-08-05"
auto_reply: false
min_score: 0.7
tags:
  - "Bildschirmpräsentation"
  - "Fachanwendungen und Microsoft Office"
  - "Folie"
  - "Layout"
  - "Microsoft PowerPoint"
  - "PPTX"
  - "PowerPoint"
  - "Präsentation"
  - "Referentenansicht"
categories:
  - "Fachanwendungen und Microsoft Office \u003e Microsoft PowerPoint"
related:
  - "[[Wiki/Categories/fachanwendungen-und-microsoft-office-microsoft-powerpoint|Fachanwendungen und Microsoft Office \u003e Microsoft PowerPoint]]"
---

# Microsoft PowerPoint

## Kontext / Problem

Auswahlziel: Fachanwendungen und Microsoft Office > Microsoft PowerPoint. Primär zuständiges Team: Fachanwendungen. Diese Kategorie ist auszuwählen, wenn Microsoft PowerPoint bei Präsentationen, Folienlayouts, Medien, Referentenansicht oder programmspezifischen Funktionen nicht korrekt arbeitet oder Unterstützung benötigt wird. Typische Ticketformulierungen sind: „Präsentation lässt sich nicht starten“; „Video in Folie spielt nicht“; „Folienlayout fehlerhaft“; „PowerPoint stürzt ab“. Nicht auswählen, wenn Beamer, Monitor oder Videokonferenztechnik physisch nicht funktioniert oder eine zentrale Office-Installation fehlt. Für die Klassifizierung sind der konkret betroffene Dienst oder Gegenstand, die Fehlermeldung, die Anzahl betroffener Personen, der Standort sowie die Unterscheidung zwischen Störung, Berechtigung, Bestellung und Änderungswunsch besonders wichtig. Einzelne unspezifische Wörter wie „geht nicht“, „Problem“ oder „dringend“ reichen ohne Sachbezug nicht für diese Zuordnung aus. Abgrenzungsregel: Physische Anzeige- und Konferenzprobleme bleiben beim Support.

## Lösung / Antwort

Interne Klassifizierung: Das Ticket ist der Kategorie „Fachanwendungen und Microsoft Office > Microsoft PowerPoint“ zuzuordnen. Primär zuständig ist „Fachanwendungen“. Vor der endgültigen Zuweisung sind die genannten Ausschlusskriterien und Schnittstellen zu prüfen.

## Verknüpfungen

- [[Wiki/Categories/fachanwendungen-und-microsoft-office-microsoft-powerpoint|Fachanwendungen und Microsoft Office > Microsoft PowerPoint]] — Kategorie
- Quelle: `kb://internal-kb/glpi-kategorien/fachanwendungen-und-microsoft-office/microsoft-powerpoint`
