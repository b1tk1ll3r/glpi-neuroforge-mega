---
type: "knowledge"
title: "DNS und DHCP"
id: "KAT-DNS-UND-DHCP-SELECT"
source: "internal-category"
source_uri: "kb://internal-kb/glpi-kategorien/netzwerk-und-verbindungen/dns-und-dhcp"
language: "de-DE"
communication_style: "formal"
created: "2026-08-05"
updated: "2026-08-05"
auto_reply: false
min_score: 0.7
tags:
  - "A-Record"
  - "CNAME"
  - "DHCP"
  - "DNS"
  - "DNS und DHCP"
  - "Hostname"
  - "IP-Adresse"
  - "IP-Vergabe"
  - "Lease"
  - "Namensauflösung"
  - "Netzwerk und Verbindungen"
  - "Reservierung"
categories:
  - "Netzwerk und Verbindungen \u003e DNS und DHCP"
related:
  - "[[Wiki/Categories/netzwerk-und-verbindungen-dns-und-dhcp|Netzwerk und Verbindungen \u003e DNS und DHCP]]"
---

# DNS und DHCP

## Kontext / Problem

Auswahlziel: Netzwerk und Verbindungen > DNS und DHCP. Primär zuständiges Team: Infrastruktur und Backend. Diese Kategorie ist auszuwählen, wenn Namensauflösung, DNS-Einträge, IP-Adressvergabe, DHCP-Leases, Reservierungen oder damit verbundene zentrale Netzwerkfunktionen fehlerhaft sind oder geändert werden sollen. Typische Ticketformulierungen sind: „Hostname wird nicht aufgelöst“; „Falsche IP-Adresse“; „DHCP-Reservierung anlegen“; „DNS-Eintrag ändern“. Nicht auswählen, wenn lediglich ein Benutzer keine Internetverbindung hat, eine Firewallfreigabe benötigt wird oder eine Fachanwendung einen eigenen Namensfehler meldet. Für die Klassifizierung sind der konkret betroffene Dienst oder Gegenstand, die Fehlermeldung, die Anzahl betroffener Personen, der Standort sowie die Unterscheidung zwischen Störung, Berechtigung, Bestellung und Änderungswunsch besonders wichtig. Einzelne unspezifische Wörter wie „geht nicht“, „Problem“ oder „dringend“ reichen ohne Sachbezug nicht für diese Zuordnung aus. Abgrenzungsregel: Einzelne Symptome ohne technische Hinweise sollten zunächst unter LAN, WLAN oder Internetzugang eingeordnet werden.

## Lösung / Antwort

Interne Klassifizierung: Das Ticket ist der Kategorie „Netzwerk und Verbindungen > DNS und DHCP“ zuzuordnen. Primär zuständig ist „Infrastruktur und Backend“. Vor der endgültigen Zuweisung sind die genannten Ausschlusskriterien und Schnittstellen zu prüfen.

## Verknüpfungen

- [[Wiki/Categories/netzwerk-und-verbindungen-dns-und-dhcp|Netzwerk und Verbindungen > DNS und DHCP]] — Kategorie
- Quelle: `kb://internal-kb/glpi-kategorien/netzwerk-und-verbindungen/dns-und-dhcp`
