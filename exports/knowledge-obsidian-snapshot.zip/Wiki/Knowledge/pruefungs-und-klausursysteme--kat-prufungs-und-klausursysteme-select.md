---
type: "knowledge"
title: "Prüfungs- und Klausursysteme"
id: "KAT-PRUFUNGS-UND-KLAUSURSYSTEME-SELECT"
source: "internal-category"
source_uri: "kb://internal-kb/glpi-kategorien/schulspezifische-it-systeme/prufungs-und-klausursysteme"
language: "de-DE"
communication_style: "formal"
created: "2026-08-05"
updated: "2026-08-05"
auto_reply: false
min_score: 0.7
tags:
  - "Klausuraccount"
  - "Klausursystem"
  - "Prüfungs- und Klausursysteme"
  - "Prüfungsbrowser"
  - "Prüfungsnetz"
  - "Prüfungssystem"
  - "Safe Exam Browser"
  - "Schulspezifische IT-Systeme"
  - "digitale Prüfung"
categories:
  - "Schulspezifische IT-Systeme \u003e Prüfungs- und Klausursysteme"
related:
  - "[[Wiki/Categories/schulspezifische-it-systeme-pruefungs-und-klausursysteme|Schulspezifische IT-Systeme \u003e Prüfungs- und Klausursysteme]]"
---

# Prüfungs- und Klausursysteme

## Kontext / Problem

Auswahlziel: Schulspezifische IT-Systeme > Prüfungs- und Klausursysteme. Primär zuständiges Team: Schulen. Diese Kategorie ist auszuwählen, wenn digitale Prüfungsumgebungen, Klausurclients, Prüfungsaccounts, sichere Browser, Prüfungsnetz oder technische Vorbereitung einer digitalen Prüfung betroffen sind. Typische Ticketformulierungen sind: „Prüfungsbrowser startet nicht“; „Klausuraccount fehlt“; „Digitale Prüfung vorbereiten“; „Prüfungsnetz gestört“. Nicht auswählen, wenn eine normale Lernplattformaufgabe oder allgemeine Computerraumstörung ohne Prüfungsbezug vorliegt. Für die Klassifizierung sind der konkret betroffene Dienst oder Gegenstand, die Fehlermeldung, die Anzahl betroffener Personen, der Standort sowie die Unterscheidung zwischen Störung, Berechtigung, Bestellung und Änderungswunsch besonders wichtig. Einzelne unspezifische Wörter wie „geht nicht“, „Problem“ oder „dringend“ reichen ohne Sachbezug nicht für diese Zuordnung aus. Abgrenzungsregel: Tickets mit unmittelbarem Prüfungstermin sind zeitkritisch und entsprechend zu priorisieren.

## Lösung / Antwort

Interne Klassifizierung: Das Ticket ist der Kategorie „Schulspezifische IT-Systeme > Prüfungs- und Klausursysteme“ zuzuordnen. Primär zuständig ist „Schulen“. Vor der endgültigen Zuweisung sind die genannten Ausschlusskriterien und Schnittstellen zu prüfen.

## Verknüpfungen

- [[Wiki/Categories/schulspezifische-it-systeme-pruefungs-und-klausursysteme|Schulspezifische IT-Systeme > Prüfungs- und Klausursysteme]] — Kategorie
- Quelle: `kb://internal-kb/glpi-kategorien/schulspezifische-it-systeme/prufungs-und-klausursysteme`
