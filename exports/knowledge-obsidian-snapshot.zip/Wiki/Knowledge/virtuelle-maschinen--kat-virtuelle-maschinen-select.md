---
type: "knowledge"
title: "Virtuelle Maschinen"
id: "KAT-VIRTUELLE-MASCHINEN-SELECT"
source: "internal-category"
source_uri: "kb://internal-kb/glpi-kategorien/server-backend-und-plattformen/virtuelle-maschinen"
language: "de-DE"
communication_style: "formal"
created: "2026-08-05"
updated: "2026-08-05"
auto_reply: false
min_score: 0.7
tags:
  - "Ressourcen erhöhen"
  - "Server, Backend und Plattformen"
  - "Snapshot"
  - "VM"
  - "VM bereitstellen"
  - "VM startet nicht"
  - "Virtuelle Maschinen"
  - "vCPU"
  - "virtuelle Maschine"
  - "virtueller Server"
categories:
  - "Server, Backend und Plattformen \u003e Virtuelle Maschinen"
related:
  - "[[Wiki/Categories/server-backend-und-plattformen-virtuelle-maschinen|Server, Backend und Plattformen \u003e Virtuelle Maschinen]]"
---

# Virtuelle Maschinen

## Kontext / Problem

Auswahlziel: Server, Backend und Plattformen > Virtuelle Maschinen. Primär zuständiges Team: Infrastruktur und Backend. Diese Kategorie ist auszuwählen, wenn eine konkrete virtuelle Maschine neu bereitgestellt, geändert, vergrößert, geklont, gestartet, wiederhergestellt oder bei einem VM-spezifischen Fehler bearbeitet werden soll. Typische Ticketformulierungen sind: „Neue VM bereitstellen“; „Virtuelle Maschine startet nicht“; „RAM oder CPU erhöhen“; „VM klonen“. Nicht auswählen, wenn der gesamte Hypervisor-Cluster betroffen ist, nur die Anwendung in der VM fehlerhaft ist oder ein Container benötigt wird. Für die Klassifizierung sind der konkret betroffene Dienst oder Gegenstand, die Fehlermeldung, die Anzahl betroffener Personen, der Standort sowie die Unterscheidung zwischen Störung, Berechtigung, Bestellung und Änderungswunsch besonders wichtig. Einzelne unspezifische Wörter wie „geht nicht“, „Problem“ oder „dringend“ reichen ohne Sachbezug nicht für diese Zuordnung aus. Abgrenzungsregel: Betriebssystem- und Anwendungsprobleme innerhalb der VM sind getrennt zu betrachten.

## Lösung / Antwort

Interne Klassifizierung: Das Ticket ist der Kategorie „Server, Backend und Plattformen > Virtuelle Maschinen“ zuzuordnen. Primär zuständig ist „Infrastruktur und Backend“. Vor der endgültigen Zuweisung sind die genannten Ausschlusskriterien und Schnittstellen zu prüfen.

## Verknüpfungen

- [[Wiki/Categories/server-backend-und-plattformen-virtuelle-maschinen|Server, Backend und Plattformen > Virtuelle Maschinen]] — Kategorie
- Quelle: `kb://internal-kb/glpi-kategorien/server-backend-und-plattformen/virtuelle-maschinen`
