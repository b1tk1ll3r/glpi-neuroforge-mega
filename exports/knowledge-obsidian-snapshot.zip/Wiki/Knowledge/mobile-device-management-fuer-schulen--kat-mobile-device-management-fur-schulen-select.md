---
type: "knowledge"
title: "Mobile-Device-Management für Schulen"
id: "KAT-MOBILE-DEVICE-MANAGEMENT-FUR-SCHULEN-SELECT"
source: "internal-category"
source_uri: "kb://internal-kb/glpi-kategorien/schulspezifische-it-systeme/mobile-device-management-fur-schulen"
language: "de-DE"
communication_style: "formal"
created: "2026-08-05"
updated: "2026-08-05"
auto_reply: false
min_score: 0.7
tags:
  - "App-Verteilung"
  - "DEP"
  - "Enrollment"
  - "Gerätegruppe"
  - "Geräteprofil"
  - "MDM"
  - "Mobile Device Management"
  - "Mobile-Device-Management für Schulen"
  - "Schulspezifische IT-Systeme"
  - "Schülergeräte verwalten"
categories:
  - "Schulspezifische IT-Systeme \u003e Mobile-Device-Management für Schulen"
related:
  - "[[Wiki/Categories/schulspezifische-it-systeme-mobile-device-management-fuer-schulen|Schulspezifische IT-Systeme \u003e Mobile-Device-Management für Schulen]]"
---

# Mobile-Device-Management für Schulen

## Kontext / Problem

Auswahlziel: Schulspezifische IT-Systeme > Mobile-Device-Management für Schulen. Primär zuständiges Team: Schulen. Diese Kategorie ist auszuwählen, wenn die zentrale Verwaltung schulischer mobiler Geräte, MDM-Profile, App-Verteilung, Gerätegruppen, Richtlinien oder Enrollment betroffen ist. Typische Ticketformulierungen sind: „MDM-Profil wird nicht installiert“; „App an Schülergeräte verteilen“; „Gerät aus MDM entfernen“; „Enrollment schlägt fehl“. Nicht auswählen, wenn nur ein einzelnes Gerät physisch defekt ist oder ein allgemeines kommunales Smartphone eingerichtet werden soll. Für die Klassifizierung sind der konkret betroffene Dienst oder Gegenstand, die Fehlermeldung, die Anzahl betroffener Personen, der Standort sowie die Unterscheidung zwischen Störung, Berechtigung, Bestellung und Änderungswunsch besonders wichtig. Einzelne unspezifische Wörter wie „geht nicht“, „Problem“ oder „dringend“ reichen ohne Sachbezug nicht für diese Zuordnung aus. Abgrenzungsregel: Plattformbetrieb kann mittelfristig an Infrastruktur und Backend übergehen; schulfachliche Gerätezuordnung bleibt zu klären.

## Lösung / Antwort

Interne Klassifizierung: Das Ticket ist der Kategorie „Schulspezifische IT-Systeme > Mobile-Device-Management für Schulen“ zuzuordnen. Primär zuständig ist „Schulen“. Vor der endgültigen Zuweisung sind die genannten Ausschlusskriterien und Schnittstellen zu prüfen.

## Verknüpfungen

- [[Wiki/Categories/schulspezifische-it-systeme-mobile-device-management-fuer-schulen|Schulspezifische IT-Systeme > Mobile-Device-Management für Schulen]] — Kategorie
- Quelle: `kb://internal-kb/glpi-kategorien/schulspezifische-it-systeme/mobile-device-management-fur-schulen`
