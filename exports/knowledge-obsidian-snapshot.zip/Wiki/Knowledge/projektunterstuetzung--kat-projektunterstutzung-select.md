---
type: "knowledge"
title: "Projektunterstützung"
id: "KAT-PROJEKTUNTERSTUTZUNG-SELECT"
source: "internal-category"
source_uri: "kb://internal-kb/glpi-kategorien/projekte-anderungen-und-neue-anforderungen/projektunterstutzung"
language: "de-DE"
communication_style: "formal"
created: "2026-08-05"
updated: "2026-08-05"
auto_reply: false
min_score: 0.7
tags:
  - "Aufwandsschätzung"
  - "IT-Beratung"
  - "Mitarbeit Projekt"
  - "Projektanfrage"
  - "Projekte, Änderungen und neue Anforderungen"
  - "Projektunterstützung"
  - "Ressource"
  - "Teilprojekt"
categories:
  - "Projekte, Änderungen und neue Anforderungen \u003e Projektunterstützung"
related:
  - "[[Wiki/Categories/projekte-aenderungen-und-neue-anforderungen-projektunterstuetzung|Projekte, Änderungen und neue Anforderungen \u003e Projektunterstützung]]"
---

# Projektunterstützung

## Kontext / Problem

Auswahlziel: Projekte, Änderungen und neue Anforderungen > Projektunterstützung. Primär zuständiges Team: Leitung und Finanzen / Beschaffung. Diese Kategorie ist auszuwählen, wenn die IT in einem fachbereichsgeführten Projekt beraten, mitarbeiten, Aufwände schätzen, technische Teilaufgaben übernehmen oder feste Ressourcen bereitstellen soll. Typische Ticketformulierungen sind: „IT-Mitarbeit im Bauprojekt“; „Technische Beratung für Fachprojekt“; „Aufwandsschätzung benötigt“; „IT-Ressource für Projekt anfragen“. Nicht auswählen, wenn die IT selbst das Projekt führt, eine normale Störung bearbeitet oder nur eine einzelne Standardleistung bestellt wird. Für die Klassifizierung sind der konkret betroffene Dienst oder Gegenstand, die Fehlermeldung, die Anzahl betroffener Personen, der Standort sowie die Unterscheidung zwischen Störung, Berechtigung, Bestellung und Änderungswunsch besonders wichtig. Einzelne unspezifische Wörter wie „geht nicht“, „Problem“ oder „dringend“ reichen ohne Sachbezug nicht für diese Zuordnung aus. Abgrenzungsregel: Leitung priorisiert Ressourcen und benennt das zuständige Fachteam.

## Lösung / Antwort

Interne Klassifizierung: Das Ticket ist der Kategorie „Projekte, Änderungen und neue Anforderungen > Projektunterstützung“ zuzuordnen. Primär zuständig ist „Leitung und Finanzen / Beschaffung“. Vor der endgültigen Zuweisung sind die genannten Ausschlusskriterien und Schnittstellen zu prüfen.

## Verknüpfungen

- [[Wiki/Categories/projekte-aenderungen-und-neue-anforderungen-projektunterstuetzung|Projekte, Änderungen und neue Anforderungen > Projektunterstützung]] — Kategorie
- Quelle: `kb://internal-kb/glpi-kategorien/projekte-anderungen-und-neue-anforderungen/projektunterstutzung`
