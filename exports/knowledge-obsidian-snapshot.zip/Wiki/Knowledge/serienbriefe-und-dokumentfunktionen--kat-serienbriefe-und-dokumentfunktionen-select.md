---
type: "knowledge"
title: "Serienbriefe und Dokumentfunktionen"
id: "KAT-SERIENBRIEFE-UND-DOKUMENTFUNKTIONEN-SELECT"
source: "internal-category"
source_uri: "kb://internal-kb/glpi-kategorien/fachanwendungen-und-microsoft-office/serienbriefe-und-dokumentfunktionen"
language: "de-DE"
communication_style: "formal"
created: "2026-08-05"
updated: "2026-08-05"
auto_reply: false
min_score: 0.7
tags:
  - "Datenquelle"
  - "Dokumentautomatisierung"
  - "Dokumentfunktion"
  - "Etiketten"
  - "Fachanwendungen und Microsoft Office"
  - "Feldfunktion"
  - "Mail Merge"
  - "Serienbrief"
  - "Serienbriefe und Dokumentfunktionen"
  - "Seriendruck"
categories:
  - "Fachanwendungen und Microsoft Office \u003e Serienbriefe und Dokumentfunktionen"
related:
  - "[[Wiki/Categories/fachanwendungen-und-microsoft-office-serienbriefe-und-dokumentfunktionen|Fachanwendungen und Microsoft Office \u003e Serienbriefe und Dokumentfunktionen]]"
---

# Serienbriefe und Dokumentfunktionen

## Kontext / Problem

Auswahlziel: Fachanwendungen und Microsoft Office > Serienbriefe und Dokumentfunktionen. Primär zuständiges Team: Fachanwendungen. Diese Kategorie ist auszuwählen, wenn Serienbriefe, Datenquellen, Feldfunktionen, Dokumentverknüpfungen, Etiketten oder automatisierte Dokumenterstellung in Office fehlerhaft sind oder eingerichtet werden sollen. Typische Ticketformulierungen sind: „Serienbrief verbindet Datenquelle nicht“; „Feldfunktion zeigt Fehler“; „Etikettendruck aus Word vorbereiten“; „Dokument automatisch befüllen“. Nicht auswählen, wenn ein allgemeines Word-Formatierungsproblem, ein Fachverfahrensbericht oder ein Druckerdefekt vorliegt. Für die Klassifizierung sind der konkret betroffene Dienst oder Gegenstand, die Fehlermeldung, die Anzahl betroffener Personen, der Standort sowie die Unterscheidung zwischen Störung, Berechtigung, Bestellung und Änderungswunsch besonders wichtig. Einzelne unspezifische Wörter wie „geht nicht“, „Problem“ oder „dringend“ reichen ohne Sachbezug nicht für diese Zuordnung aus. Abgrenzungsregel: Bei Datenübergabe aus einer Fachanwendung ist gegebenenfalls zusätzlich die Schnittstellenkategorie relevant.

## Lösung / Antwort

Interne Klassifizierung: Das Ticket ist der Kategorie „Fachanwendungen und Microsoft Office > Serienbriefe und Dokumentfunktionen“ zuzuordnen. Primär zuständig ist „Fachanwendungen“. Vor der endgültigen Zuweisung sind die genannten Ausschlusskriterien und Schnittstellen zu prüfen.

## Verknüpfungen

- [[Wiki/Categories/fachanwendungen-und-microsoft-office-serienbriefe-und-dokumentfunktionen|Fachanwendungen und Microsoft Office > Serienbriefe und Dokumentfunktionen]] — Kategorie
- Quelle: `kb://internal-kb/glpi-kategorien/fachanwendungen-und-microsoft-office/serienbriefe-und-dokumentfunktionen`
