---
type: "knowledge"
title: "Betriebssystem am Arbeitsplatz"
id: "KAT-BETRIEBSSYSTEM-AM-ARBEITSPLATZ-SELECT"
source: "internal-category"
source_uri: "kb://internal-kb/glpi-kategorien/arbeitsplatz-und-endgerate/betriebssystem-am-arbeitsplatz"
language: "de-DE"
communication_style: "formal"
created: "2026-08-05"
updated: "2026-08-05"
auto_reply: false
min_score: 0.7
tags:
  - "Arbeitsplatz und Endgeräte"
  - "Benutzerprofil"
  - "Betriebssystem"
  - "Betriebssystem am Arbeitsplatz"
  - "Client"
  - "Startmenü"
  - "Systemfehler"
  - "Treiberproblem"
  - "Windows"
  - "Windows Update"
  - "lokale Anmeldung"
categories:
  - "Arbeitsplatz und Endgeräte \u003e Betriebssystem am Arbeitsplatz"
related:
  - "[[Wiki/Categories/arbeitsplatz-und-endgeraete-betriebssystem-am-arbeitsplatz|Arbeitsplatz und Endgeräte \u003e Betriebssystem am Arbeitsplatz]]"
---

# Betriebssystem am Arbeitsplatz

## Kontext / Problem

Auswahlziel: Arbeitsplatz und Endgeräte > Betriebssystem am Arbeitsplatz. Primär zuständiges Team: Support und Telekommunikation. Diese Kategorie ist auszuwählen, wenn Windows oder ein anderes Client-Betriebssystem an einem einzelnen Arbeitsplatz lokale Fehler zeigt, Updates scheitern, Anmeldung am Gerät fehlerhaft ist oder Systemeinstellungen repariert werden müssen. Typische Ticketformulierungen sind: „Windows-Update schlägt fehl“; „Benutzerprofil defekt“; „Startmenü funktioniert nicht“; „Lokale Anmeldung fehlerhaft“. Nicht auswählen, wenn die Ursache eine zentrale Gruppenrichtlinie, das Active Directory, eine flächige Update-Störung oder ein Serverbetriebssystem ist. Für die Klassifizierung sind der konkret betroffene Dienst oder Gegenstand, die Fehlermeldung, die Anzahl betroffener Personen, der Standort sowie die Unterscheidung zwischen Störung, Berechtigung, Bestellung und Änderungswunsch besonders wichtig. Einzelne unspezifische Wörter wie „geht nicht“, „Problem“ oder „dringend“ reichen ohne Sachbezug nicht für diese Zuordnung aus. Abgrenzungsregel: Zentrale Richtlinien und mehrere gleichzeitig betroffene Clients werden an Infrastruktur und Backend übergeben.

## Lösung / Antwort

Interne Klassifizierung: Das Ticket ist der Kategorie „Arbeitsplatz und Endgeräte > Betriebssystem am Arbeitsplatz“ zuzuordnen. Primär zuständig ist „Support und Telekommunikation“. Vor der endgültigen Zuweisung sind die genannten Ausschlusskriterien und Schnittstellen zu prüfen.

## Verknüpfungen

- [[Wiki/Categories/arbeitsplatz-und-endgeraete-betriebssystem-am-arbeitsplatz|Arbeitsplatz und Endgeräte > Betriebssystem am Arbeitsplatz]] — Kategorie
- Quelle: `kb://internal-kb/glpi-kategorien/arbeitsplatz-und-endgerate/betriebssystem-am-arbeitsplatz`
