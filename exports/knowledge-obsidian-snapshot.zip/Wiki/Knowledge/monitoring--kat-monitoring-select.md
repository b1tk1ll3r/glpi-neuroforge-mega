---
type: "knowledge"
title: "Monitoring"
id: "KAT-MONITORING-SELECT"
source: "internal-category"
source_uri: "kb://internal-kb/glpi-kategorien/server-backend-und-plattformen/monitoring"
language: "de-DE"
communication_style: "formal"
created: "2026-08-05"
updated: "2026-08-05"
auto_reply: false
min_score: 0.7
tags:
  - "Alarmierung"
  - "Alert"
  - "Check"
  - "Dashboard"
  - "Metrik"
  - "Monitoring"
  - "Nagios"
  - "Schwellwert"
  - "Server, Backend und Plattformen"
  - "Zabbix"
  - "Überwachung"
categories:
  - "Server, Backend und Plattformen \u003e Monitoring"
related:
  - "[[Wiki/Categories/server-backend-und-plattformen-monitoring|Server, Backend und Plattformen \u003e Monitoring]]"
---

# Monitoring

## Kontext / Problem

Auswahlziel: Server, Backend und Plattformen > Monitoring. Primär zuständiges Team: Infrastruktur und Backend. Diese Kategorie ist auszuwählen, wenn technische Überwachung, Checks, Alarmierung, Dashboards, Schwellwerte oder Benachrichtigungen für Infrastruktur und Plattformen eingerichtet oder fehlerhaft sind. Typische Ticketformulierungen sind: „Monitoring-Check hinzufügen“; „Alarm wird nicht ausgelöst“; „Schwellwert anpassen“; „Infrastruktur-Dashboard erstellen“. Nicht auswählen, wenn ein konkreter Dienst bereits ausgefallen ist und die Behebung im Vordergrund steht oder eine fachliche Statistik benötigt wird. Für die Klassifizierung sind der konkret betroffene Dienst oder Gegenstand, die Fehlermeldung, die Anzahl betroffener Personen, der Standort sowie die Unterscheidung zwischen Störung, Berechtigung, Bestellung und Änderungswunsch besonders wichtig. Einzelne unspezifische Wörter wie „geht nicht“, „Problem“ oder „dringend“ reichen ohne Sachbezug nicht für diese Zuordnung aus. Abgrenzungsregel: Ein Alarm ist ein Hinweis; die eigentliche Störung kann zusätzlich in ihrer fachlich passenden Kategorie erfasst werden.

## Lösung / Antwort

Interne Klassifizierung: Das Ticket ist der Kategorie „Server, Backend und Plattformen > Monitoring“ zuzuordnen. Primär zuständig ist „Infrastruktur und Backend“. Vor der endgültigen Zuweisung sind die genannten Ausschlusskriterien und Schnittstellen zu prüfen.

## Verknüpfungen

- [[Wiki/Categories/server-backend-und-plattformen-monitoring|Server, Backend und Plattformen > Monitoring]] — Kategorie
- Quelle: `kb://internal-kb/glpi-kategorien/server-backend-und-plattformen/monitoring`
