---
type: "knowledge"
title: "Verdächtige E-Mail und Phishing"
id: "KAT-VERDACHTIGE-E-MAIL-UND-PHISHING-SELECT"
source: "internal-category"
source_uri: "kb://internal-kb/glpi-kategorien/it-sicherheit-und-datensicherung/verdachtige-e-mail-und-phishing"
language: "de-DE"
communication_style: "formal"
created: "2026-08-05"
updated: "2026-08-05"
auto_reply: false
min_score: 0.7
tags:
  - "Anhang"
  - "CEO-Fraud"
  - "Fake Mail"
  - "IT-Sicherheit und Datensicherung"
  - "Phishing"
  - "Spam"
  - "Verdächtige E-Mail und Phishing"
  - "Zugangsdaten"
  - "gefälschter Absender"
  - "verdächtige E-Mail"
  - "verdächtiger Link"
categories:
  - "IT-Sicherheit und Datensicherung \u003e Verdächtige E-Mail und Phishing"
related:
  - "[[Wiki/Categories/it-sicherheit-und-datensicherung-verdaechtige-e-mail-und-phishing|IT-Sicherheit und Datensicherung \u003e Verdächtige E-Mail und Phishing]]"
---

# Verdächtige E-Mail und Phishing

## Kontext / Problem

Auswahlziel: IT-Sicherheit und Datensicherung > Verdächtige E-Mail und Phishing. Primär zuständiges Team: Infrastruktur und Backend. Diese Kategorie ist auszuwählen, wenn eine E-Mail verdächtig wirkt, einen ungewöhnlichen Link oder Anhang enthält, Zugangsdaten abfragt, eine Zahlung fordert oder der Absender möglicherweise gefälscht ist. Typische Ticketformulierungen sind: „Verdächtige Rechnung per E-Mail“; „Link in Mail angeklickt“; „Absender scheint gefälscht“; „Passwortabfrage per Mail“. Nicht auswählen, wenn es sich nur um normalen Spam ohne Sicherheitsbezug, eine Outlook-Client-Störung oder eine bekannte legitime Nachricht handelt. Für die Klassifizierung sind der konkret betroffene Dienst oder Gegenstand, die Fehlermeldung, die Anzahl betroffener Personen, der Standort sowie die Unterscheidung zwischen Störung, Berechtigung, Bestellung und Änderungswunsch besonders wichtig. Einzelne unspezifische Wörter wie „geht nicht“, „Problem“ oder „dringend“ reichen ohne Sachbezug nicht für diese Zuordnung aus. Abgrenzungsregel: Bei geklicktem Link, geöffnetem Anhang oder eingegebenen Zugangsdaten ist die Dringlichkeit zu erhöhen und gegebenenfalls Sicherheitsvorfall zu wählen.

## Lösung / Antwort

Interne Klassifizierung: Das Ticket ist der Kategorie „IT-Sicherheit und Datensicherung > Verdächtige E-Mail und Phishing“ zuzuordnen. Primär zuständig ist „Infrastruktur und Backend“. Vor der endgültigen Zuweisung sind die genannten Ausschlusskriterien und Schnittstellen zu prüfen.

## Verknüpfungen

- [[Wiki/Categories/it-sicherheit-und-datensicherung-verdaechtige-e-mail-und-phishing|IT-Sicherheit und Datensicherung > Verdächtige E-Mail und Phishing]] — Kategorie
- Quelle: `kb://internal-kb/glpi-kategorien/it-sicherheit-und-datensicherung/verdachtige-e-mail-und-phishing`
