---
type: "knowledge"
title: "Standortanbindung"
id: "KAT-STANDORTANBINDUNG-SELECT"
source: "internal-category"
source_uri: "kb://internal-kb/glpi-kategorien/netzwerk-und-verbindungen/standortanbindung"
language: "de-DE"
communication_style: "formal"
created: "2026-08-05"
updated: "2026-08-05"
auto_reply: false
min_score: 0.7
tags:
  - "Außenstelle"
  - "Gebäude offline"
  - "Glasfaser"
  - "Liegenschaft"
  - "MPLS"
  - "Netzwerk und Verbindungen"
  - "Standleitung"
  - "Standortanbindung"
  - "Standortverbindung"
  - "WAN"
categories:
  - "Netzwerk und Verbindungen \u003e Standortanbindung"
related:
  - "[[Wiki/Categories/netzwerk-und-verbindungen-standortanbindung|Netzwerk und Verbindungen \u003e Standortanbindung]]"
---

# Standortanbindung

## Kontext / Problem

Auswahlziel: Netzwerk und Verbindungen > Standortanbindung. Primär zuständiges Team: Infrastruktur und Backend. Diese Kategorie ist auszuwählen, wenn eine Außenstelle, Schule, Verwaltungsstelle oder ein gesamtes Gebäude keine Verbindung zum kommunalen Netz oder Rechenzentrum hat beziehungsweise eine neue Standortverbindung benötigt. Typische Ticketformulierungen sind: „Außenstelle nicht erreichbar“; „Standortverbindung ausgefallen“; „Neue Liegenschaft anbinden“; „Gesamte Schule ohne Verwaltungsnetz“. Nicht auswählen, wenn nur ein einzelner Arbeitsplatz oder eine einzelne Netzwerkdose betroffen ist. Für die Klassifizierung sind der konkret betroffene Dienst oder Gegenstand, die Fehlermeldung, die Anzahl betroffener Personen, der Standort sowie die Unterscheidung zwischen Störung, Berechtigung, Bestellung und Änderungswunsch besonders wichtig. Einzelne unspezifische Wörter wie „geht nicht“, „Problem“ oder „dringend“ reichen ohne Sachbezug nicht für diese Zuordnung aus. Abgrenzungsregel: Standortausfälle betreffen meist mehrere Nutzer und sind höher zu priorisieren als Einzelplatzprobleme.

## Lösung / Antwort

Interne Klassifizierung: Das Ticket ist der Kategorie „Netzwerk und Verbindungen > Standortanbindung“ zuzuordnen. Primär zuständig ist „Infrastruktur und Backend“. Vor der endgültigen Zuweisung sind die genannten Ausschlusskriterien und Schnittstellen zu prüfen.

## Verknüpfungen

- [[Wiki/Categories/netzwerk-und-verbindungen-standortanbindung|Netzwerk und Verbindungen > Standortanbindung]] — Kategorie
- Quelle: `kb://internal-kb/glpi-kategorien/netzwerk-und-verbindungen/standortanbindung`
