---
type: "knowledge"
title: "Office-Vorlagen"
id: "KAT-OFFICE-VORLAGEN-SELECT"
source: "internal-category"
source_uri: "kb://internal-kb/glpi-kategorien/fachanwendungen-und-microsoft-office/office-vorlagen"
language: "de-DE"
communication_style: "formal"
created: "2026-08-05"
updated: "2026-08-05"
auto_reply: false
min_score: 0.7
tags:
  - "Briefkopf"
  - "Corporate Design"
  - "Excel-Vorlage"
  - "Fachanwendungen und Microsoft Office"
  - "Office-Vorlage"
  - "Office-Vorlagen"
  - "PowerPoint-Vorlage"
  - "Template"
  - "Textbaustein"
  - "Word-Vorlage"
categories:
  - "Fachanwendungen und Microsoft Office \u003e Office-Vorlagen"
related:
  - "[[Wiki/Categories/fachanwendungen-und-microsoft-office-office-vorlagen|Fachanwendungen und Microsoft Office \u003e Office-Vorlagen]]"
---

# Office-Vorlagen

## Kontext / Problem

Auswahlziel: Fachanwendungen und Microsoft Office > Office-Vorlagen. Primär zuständiges Team: Fachanwendungen. Diese Kategorie ist auszuwählen, wenn zentrale Word-, Excel- oder PowerPoint-Vorlagen erstellt, geändert, verteilt oder korrigiert werden sollen, einschließlich Briefkopf, Layout, Textbausteinen und Organisationsvorgaben. Typische Ticketformulierungen sind: „Briefvorlage anpassen“; „Neues Corporate-Design-Layout“; „Vorlage wird nicht geladen“; „Textbaustein zentral ändern“. Nicht auswählen, wenn nur ein einzelnes Dokument formatiert werden soll, ein Makro fehlerhaft ist oder ein Drucker die Vorlage nicht ausgibt. Für die Klassifizierung sind der konkret betroffene Dienst oder Gegenstand, die Fehlermeldung, die Anzahl betroffener Personen, der Standort sowie die Unterscheidung zwischen Störung, Berechtigung, Bestellung und Änderungswunsch besonders wichtig. Einzelne unspezifische Wörter wie „geht nicht“, „Problem“ oder „dringend“ reichen ohne Sachbezug nicht für diese Zuordnung aus. Abgrenzungsregel: Inhaltliche Freigaben durch zuständige Organisationseinheiten bleiben erforderlich.

## Lösung / Antwort

Interne Klassifizierung: Das Ticket ist der Kategorie „Fachanwendungen und Microsoft Office > Office-Vorlagen“ zuzuordnen. Primär zuständig ist „Fachanwendungen“. Vor der endgültigen Zuweisung sind die genannten Ausschlusskriterien und Schnittstellen zu prüfen.

## Verknüpfungen

- [[Wiki/Categories/fachanwendungen-und-microsoft-office-office-vorlagen|Fachanwendungen und Microsoft Office > Office-Vorlagen]] — Kategorie
- Quelle: `kb://internal-kb/glpi-kategorien/fachanwendungen-und-microsoft-office/office-vorlagen`
