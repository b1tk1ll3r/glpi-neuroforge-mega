---
type: "knowledge"
title: "Computerräume"
id: "KAT-COMPUTERRAUME-SELECT"
source: "internal-category"
source_uri: "kb://internal-kb/glpi-kategorien/schulspezifische-it-systeme/computerraume"
language: "de-DE"
communication_style: "formal"
created: "2026-08-05"
updated: "2026-08-05"
auto_reply: false
min_score: 0.7
tags:
  - "Computerraum"
  - "Computerräume"
  - "Informatikraum"
  - "PC-Raum"
  - "Raumausstattung"
  - "Schulspezifische IT-Systeme"
  - "Schüler-PC"
  - "Unterrichtsraum"
  - "mehrere Rechner"
categories:
  - "Schulspezifische IT-Systeme \u003e Computerräume"
related:
  - "[[Wiki/Categories/schulspezifische-it-systeme-computerraeume|Schulspezifische IT-Systeme \u003e Computerräume]]"
---

# Computerräume

## Kontext / Problem

Auswahlziel: Schulspezifische IT-Systeme > Computerräume. Primär zuständiges Team: Schulen. Diese Kategorie ist auszuwählen, wenn mehrere PCs, Peripheriegeräte, Anmeldungen oder die technische Ausstattung eines Computerraums betroffen sind oder der Raum neu eingerichtet werden soll. Typische Ticketformulierungen sind: „Mehrere PCs im Computerraum starten nicht“; „Computerraum neu ausstatten“; „Schüler können sich im Raum nicht anmelden“; „Raumsoftware verteilen“. Nicht auswählen, wenn nur ein einzelner Lehrerarbeitsplatz oder eine allgemeine Standortstörung vorliegt. Für die Klassifizierung sind der konkret betroffene Dienst oder Gegenstand, die Fehlermeldung, die Anzahl betroffener Personen, der Standort sowie die Unterscheidung zwischen Störung, Berechtigung, Bestellung und Änderungswunsch besonders wichtig. Einzelne unspezifische Wörter wie „geht nicht“, „Problem“ oder „dringend“ reichen ohne Sachbezug nicht für diese Zuordnung aus. Abgrenzungsregel: Mehrgeräteprobleme sprechen oft für zentrale Richtlinien, Images oder Netzwerkursachen.

## Lösung / Antwort

Interne Klassifizierung: Das Ticket ist der Kategorie „Schulspezifische IT-Systeme > Computerräume“ zuzuordnen. Primär zuständig ist „Schulen“. Vor der endgültigen Zuweisung sind die genannten Ausschlusskriterien und Schnittstellen zu prüfen.

## Verknüpfungen

- [[Wiki/Categories/schulspezifische-it-systeme-computerraeume|Schulspezifische IT-Systeme > Computerräume]] — Kategorie
- Quelle: `kb://internal-kb/glpi-kategorien/schulspezifische-it-systeme/computerraume`
