---
type: "knowledge"
title: "Fachanwendung – Update und Release"
id: "KAT-FACHANWENDUNG-UPDATE-UND-RELEASE-SELECT"
source: "internal-category"
source_uri: "kb://internal-kb/glpi-kategorien/fachanwendungen-und-microsoft-office/fachanwendung-update-und-release"
language: "de-DE"
communication_style: "formal"
created: "2026-08-05"
updated: "2026-08-05"
auto_reply: false
min_score: 0.7
tags:
  - "Fachanwendung aktualisieren"
  - "Fachanwendung – Update und Release"
  - "Fachanwendungen und Microsoft Office"
  - "Freigabe"
  - "Herstellerupdate"
  - "Patch"
  - "Release"
  - "Testsystem"
  - "Update"
  - "Upgrade"
  - "Version"
categories:
  - "Fachanwendungen und Microsoft Office \u003e Fachanwendung – Update und Release"
related:
  - "[[Wiki/Categories/fachanwendungen-und-microsoft-office-fachanwendung-update-und-release|Fachanwendungen und Microsoft Office \u003e Fachanwendung – Update und Release]]"
---

# Fachanwendung – Update und Release

## Kontext / Problem

Auswahlziel: Fachanwendungen und Microsoft Office > Fachanwendung – Update und Release. Primär zuständiges Team: Fachanwendungen. Diese Kategorie ist auszuwählen, wenn ein Update, Patch, Releasewechsel oder Versionsupgrade einer Fachanwendung geplant, getestet, freigegeben oder nachbereitet werden soll. Typische Ticketformulierungen sind: „Neue Fachverfahrensversion testen“; „Release einspielen“; „Herstellerupdate planen“; „Patch der Anwendung freigeben“. Nicht auswählen, wenn nur ein Windows-Clientupdate scheitert, ein Sicherheitspatch der Serverplattform betroffen ist oder eine neue Anwendung erstmals eingeführt wird. Für die Klassifizierung sind der konkret betroffene Dienst oder Gegenstand, die Fehlermeldung, die Anzahl betroffener Personen, der Standort sowie die Unterscheidung zwischen Störung, Berechtigung, Bestellung und Änderungswunsch besonders wichtig. Einzelne unspezifische Wörter wie „geht nicht“, „Problem“ oder „dringend“ reichen ohne Sachbezug nicht für diese Zuordnung aus. Abgrenzungsregel: Technische Server- und Datenbankarbeiten werden mit Infrastruktur und Backend abgestimmt.

## Lösung / Antwort

Interne Klassifizierung: Das Ticket ist der Kategorie „Fachanwendungen und Microsoft Office > Fachanwendung – Update und Release“ zuzuordnen. Primär zuständig ist „Fachanwendungen“. Vor der endgültigen Zuweisung sind die genannten Ausschlusskriterien und Schnittstellen zu prüfen.

## Verknüpfungen

- [[Wiki/Categories/fachanwendungen-und-microsoft-office-fachanwendung-update-und-release|Fachanwendungen und Microsoft Office > Fachanwendung – Update und Release]] — Kategorie
- Quelle: `kb://internal-kb/glpi-kategorien/fachanwendungen-und-microsoft-office/fachanwendung-update-und-release`
