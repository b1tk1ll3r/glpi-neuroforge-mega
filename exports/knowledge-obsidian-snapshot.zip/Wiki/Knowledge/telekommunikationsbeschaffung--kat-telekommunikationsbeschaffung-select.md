---
type: "knowledge"
title: "Telekommunikationsbeschaffung"
id: "KAT-TELEKOMMUNIKATIONSBESCHAFFUNG-SELECT"
source: "internal-category"
source_uri: "kb://internal-kb/glpi-kategorien/telefonie-und-kommunikation/telekommunikationsbeschaffung"
language: "de-DE"
communication_style: "formal"
created: "2026-08-05"
updated: "2026-08-05"
auto_reply: false
min_score: 0.7
tags:
  - "Diensthandy bestellen"
  - "Headset beschaffen"
  - "Kauf"
  - "Mobilfunkvertrag"
  - "SIM bestellen"
  - "Telefon bestellen"
  - "Telefonie und Kommunikation"
  - "Telekommunikation Beschaffung"
  - "Telekommunikationsbeschaffung"
categories:
  - "Telefonie und Kommunikation \u003e Telekommunikationsbeschaffung"
related:
  - "[[Wiki/Categories/telefonie-und-kommunikation-telekommunikationsbeschaffung|Telefonie und Kommunikation \u003e Telekommunikationsbeschaffung]]"
---

# Telekommunikationsbeschaffung

## Kontext / Problem

Auswahlziel: Telefonie und Kommunikation > Telekommunikationsbeschaffung. Primär zuständiges Team: Leitung und Finanzen / Beschaffung. Diese Kategorie ist auszuwählen, wenn neue Telefone, Smartphones, SIM-Karten, Mobilfunkverträge, Headsets oder andere Telekommunikationsleistungen beschafft, verlängert oder wirtschaftlich bewertet werden sollen. Typische Ticketformulierungen sind: „Neues Diensthandy bestellen“; „Mobilfunkvertrag abschließen“; „Telefone für neue Arbeitsplätze beschaffen“; „Headsets in größerer Stückzahl kaufen“. Nicht auswählen, wenn ein vorhandenes Gerät nur defekt ist, eine Rufumleitung geändert oder eine technische Störung behoben werden muss. Für die Klassifizierung sind der konkret betroffene Dienst oder Gegenstand, die Fehlermeldung, die Anzahl betroffener Personen, der Standort sowie die Unterscheidung zwischen Störung, Berechtigung, Bestellung und Änderungswunsch besonders wichtig. Einzelne unspezifische Wörter wie „geht nicht“, „Problem“ oder „dringend“ reichen ohne Sachbezug nicht für diese Zuordnung aus. Abgrenzungsregel: Technische Spezifikation erfolgt gemeinsam mit Support und Telekommunikation.

## Lösung / Antwort

Interne Klassifizierung: Das Ticket ist der Kategorie „Telefonie und Kommunikation > Telekommunikationsbeschaffung“ zuzuordnen. Primär zuständig ist „Leitung und Finanzen / Beschaffung“. Vor der endgültigen Zuweisung sind die genannten Ausschlusskriterien und Schnittstellen zu prüfen.

## Verknüpfungen

- [[Wiki/Categories/telefonie-und-kommunikation-telekommunikationsbeschaffung|Telefonie und Kommunikation > Telekommunikationsbeschaffung]] — Kategorie
- Quelle: `kb://internal-kb/glpi-kategorien/telefonie-und-kommunikation/telekommunikationsbeschaffung`
