---
type: "knowledge"
title: "Fachanwendung – Bedienung und Beratung"
id: "KAT-FACHANWENDUNG-BEDIENUNG-UND-BERATUNG-SELECT"
source: "internal-category"
source_uri: "kb://internal-kb/glpi-kategorien/fachanwendungen-und-microsoft-office/fachanwendung-bedienung-und-beratung"
language: "de-DE"
communication_style: "formal"
created: "2026-08-05"
updated: "2026-08-05"
auto_reply: false
min_score: 0.7
tags:
  - "Anleitung"
  - "Anwenderfrage"
  - "Arbeitsschritt"
  - "Bedienung"
  - "Beratung"
  - "Fachanwendung – Bedienung und Beratung"
  - "Fachanwendungen und Microsoft Office"
  - "Fachverfahren Hilfe"
  - "Nutzung"
  - "Wie kann ich"
  - "Wo finde ich"
categories:
  - "Fachanwendungen und Microsoft Office \u003e Fachanwendung – Bedienung und Beratung"
related:
  - "[[Wiki/Categories/fachanwendungen-und-microsoft-office-fachanwendung-bedienung-und-beratung|Fachanwendungen und Microsoft Office \u003e Fachanwendung – Bedienung und Beratung]]"
---

# Fachanwendung – Bedienung und Beratung

## Kontext / Problem

Auswahlziel: Fachanwendungen und Microsoft Office > Fachanwendung – Bedienung und Beratung. Primär zuständiges Team: Fachanwendungen. Diese Kategorie ist auszuwählen, wenn die Anwendung technisch funktioniert, aber Unterstützung bei Bedienung, Prozessschritten, Eingaben, fachlicher Nutzung oder Best-Practice benötigt wird. Typische Ticketformulierungen sind: „Wie erfasse ich einen Vorgang“; „Wo finde ich die Auswertung“; „Unterstützung bei Arbeitsschritt“; „Frage zur Bedienung des Fachverfahrens“. Nicht auswählen, wenn eine Fehlermeldung oder ein technischer Ausfall vorliegt; wenn eine neue Funktion entwickelt oder eine Berechtigung geändert werden soll. Für die Klassifizierung sind der konkret betroffene Dienst oder Gegenstand, die Fehlermeldung, die Anzahl betroffener Personen, der Standort sowie die Unterscheidung zwischen Störung, Berechtigung, Bestellung und Änderungswunsch besonders wichtig. Einzelne unspezifische Wörter wie „geht nicht“, „Problem“ oder „dringend“ reichen ohne Sachbezug nicht für diese Zuordnung aus. Abgrenzungsregel: Reine Standardfragen können im First-Level angenommen werden; fachliche Prozessberatung bleibt bei Fachanwendungen.

## Lösung / Antwort

Interne Klassifizierung: Das Ticket ist der Kategorie „Fachanwendungen und Microsoft Office > Fachanwendung – Bedienung und Beratung“ zuzuordnen. Primär zuständig ist „Fachanwendungen“. Vor der endgültigen Zuweisung sind die genannten Ausschlusskriterien und Schnittstellen zu prüfen.

## Verknüpfungen

- [[Wiki/Categories/fachanwendungen-und-microsoft-office-fachanwendung-bedienung-und-beratung|Fachanwendungen und Microsoft Office > Fachanwendung – Bedienung und Beratung]] — Kategorie
- Quelle: `kb://internal-kb/glpi-kategorien/fachanwendungen-und-microsoft-office/fachanwendung-bedienung-und-beratung`
