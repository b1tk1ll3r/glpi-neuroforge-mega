---
type: "knowledge"
title: "Netzwerksegment und VLAN"
id: "KAT-NETZWERKSEGMENT-UND-VLAN-SELECT"
source: "internal-category"
source_uri: "kb://internal-kb/glpi-kategorien/netzwerk-und-verbindungen/netzwerksegment-und-vlan"
language: "de-DE"
communication_style: "formal"
created: "2026-08-05"
updated: "2026-08-05"
auto_reply: false
min_score: 0.7
tags:
  - "IP-Netz"
  - "Netzsegment"
  - "Netztrennung"
  - "Netzwerk und Verbindungen"
  - "Netzwerksegment und VLAN"
  - "Portzuordnung"
  - "Segmentierung"
  - "Subnetz"
  - "Switchport"
  - "VLAN"
categories:
  - "Netzwerk und Verbindungen \u003e Netzwerksegment und VLAN"
related:
  - "[[Wiki/Categories/netzwerk-und-verbindungen-netzwerksegment-und-vlan|Netzwerk und Verbindungen \u003e Netzwerksegment und VLAN]]"
---

# Netzwerksegment und VLAN

## Kontext / Problem

Auswahlziel: Netzwerk und Verbindungen > Netzwerksegment und VLAN. Primär zuständiges Team: Infrastruktur und Backend. Diese Kategorie ist auszuwählen, wenn VLANs, Netzsegmente, Subnetze, logische Trennungen oder Portzuordnungen neu eingerichtet, geändert oder analysiert werden sollen. Typische Ticketformulierungen sind: „Gerät in anderes VLAN verschieben“; „Neues Netzsegment anlegen“; „Port falschem VLAN zugeordnet“; „Subnetz für neues System“. Nicht auswählen, wenn nur eine einzelne Netzwerkdose ohne Verbindung ist oder eine Firewallregel zwischen bestehenden Segmenten fehlt. Für die Klassifizierung sind der konkret betroffene Dienst oder Gegenstand, die Fehlermeldung, die Anzahl betroffener Personen, der Standort sowie die Unterscheidung zwischen Störung, Berechtigung, Bestellung und Änderungswunsch besonders wichtig. Einzelne unspezifische Wörter wie „geht nicht“, „Problem“ oder „dringend“ reichen ohne Sachbezug nicht für diese Zuordnung aus. Abgrenzungsregel: Sicherheitsrelevante Segmentierungsentscheidungen sind mit IT-Sicherheit und Leitung abzustimmen.

## Lösung / Antwort

Interne Klassifizierung: Das Ticket ist der Kategorie „Netzwerk und Verbindungen > Netzwerksegment und VLAN“ zuzuordnen. Primär zuständig ist „Infrastruktur und Backend“. Vor der endgültigen Zuweisung sind die genannten Ausschlusskriterien und Schnittstellen zu prüfen.

## Verknüpfungen

- [[Wiki/Categories/netzwerk-und-verbindungen-netzwerksegment-und-vlan|Netzwerk und Verbindungen > Netzwerksegment und VLAN]] — Kategorie
- Quelle: `kb://internal-kb/glpi-kategorien/netzwerk-und-verbindungen/netzwerksegment-und-vlan`
