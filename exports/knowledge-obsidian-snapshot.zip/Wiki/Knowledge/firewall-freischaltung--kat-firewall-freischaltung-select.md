---
type: "knowledge"
title: "Firewall-Freischaltung"
id: "KAT-FIREWALL-FREISCHALTUNG-SELECT"
source: "internal-category"
source_uri: "kb://internal-kb/glpi-kategorien/netzwerk-und-verbindungen/firewall-freischaltung"
language: "de-DE"
communication_style: "formal"
created: "2026-08-05"
updated: "2026-08-05"
auto_reply: false
min_score: 0.7
tags:
  - "Firewall"
  - "Firewall-Freischaltung"
  - "Freischaltung"
  - "Netzwerk und Verbindungen"
  - "Netzwerkfreigabe"
  - "Port"
  - "Protokoll"
  - "Quelle"
  - "Regel"
  - "Whitelist"
  - "Ziel"
  - "blockiert"
categories:
  - "Netzwerk und Verbindungen \u003e Firewall-Freischaltung"
related:
  - "[[Wiki/Categories/netzwerk-und-verbindungen-firewall-freischaltung|Netzwerk und Verbindungen \u003e Firewall-Freischaltung]]"
---

# Firewall-Freischaltung

## Kontext / Problem

Auswahlziel: Netzwerk und Verbindungen > Firewall-Freischaltung. Primär zuständiges Team: Infrastruktur und Backend. Diese Kategorie ist auszuwählen, wenn eine konkrete Netzwerkkommunikation durch Firewallregeln erlaubt, geändert, zeitlich begrenzt oder geprüft werden soll, typischerweise mit Quelle, Ziel, Port und Protokoll. Typische Ticketformulierungen sind: „Port 443 zu Zielsystem freischalten“; „Firewall blockiert Anwendung“; „Kommunikation zwischen Netzen erlauben“; „Externer Dienst benötigt Zugriff“. Nicht auswählen, wenn ein allgemeiner Internetausfall, ein VPN-Berechtigungsantrag oder eine fachliche Schnittstellenkonfiguration ohne Firewallbezug vorliegt. Für die Klassifizierung sind der konkret betroffene Dienst oder Gegenstand, die Fehlermeldung, die Anzahl betroffener Personen, der Standort sowie die Unterscheidung zwischen Störung, Berechtigung, Bestellung und Änderungswunsch besonders wichtig. Einzelne unspezifische Wörter wie „geht nicht“, „Problem“ oder „dringend“ reichen ohne Sachbezug nicht für diese Zuordnung aus. Abgrenzungsregel: Unklare pauschale Freischaltungen sind nicht ausreichend; Sicherheitsprüfung und Minimalprinzip gelten.

## Lösung / Antwort

Interne Klassifizierung: Das Ticket ist der Kategorie „Netzwerk und Verbindungen > Firewall-Freischaltung“ zuzuordnen. Primär zuständig ist „Infrastruktur und Backend“. Vor der endgültigen Zuweisung sind die genannten Ausschlusskriterien und Schnittstellen zu prüfen.

## Verknüpfungen

- [[Wiki/Categories/netzwerk-und-verbindungen-firewall-freischaltung|Netzwerk und Verbindungen > Firewall-Freischaltung]] — Kategorie
- Quelle: `kb://internal-kb/glpi-kategorien/netzwerk-und-verbindungen/firewall-freischaltung`
