---
type: "knowledge"
title: "Standorteröffnung und Umzug"
id: "KAT-STANDORTEROFFNUNG-UND-UMZUG-SELECT"
source: "internal-category"
source_uri: "kb://internal-kb/glpi-kategorien/projekte-anderungen-und-neue-anforderungen/standorteroffnung-und-umzug"
language: "de-DE"
communication_style: "formal"
created: "2026-08-05"
updated: "2026-08-05"
auto_reply: false
min_score: 0.7
tags:
  - "Außenstelle"
  - "Gebäudeumzug"
  - "IT-Ausstattung Standort"
  - "Projekte, Änderungen und neue Anforderungen"
  - "Standorteröffnung"
  - "Standorteröffnung und Umzug"
  - "Standortumzug"
  - "Umzugsprojekt"
  - "neue Liegenschaft"
categories:
  - "Projekte, Änderungen und neue Anforderungen \u003e Standorteröffnung und Umzug"
related:
  - "[[Wiki/Categories/projekte-aenderungen-und-neue-anforderungen-standorteroeffnung-und-umzug|Projekte, Änderungen und neue Anforderungen \u003e Standorteröffnung und Umzug]]"
---

# Standorteröffnung und Umzug

## Kontext / Problem

Auswahlziel: Projekte, Änderungen und neue Anforderungen > Standorteröffnung und Umzug. Primär zuständiges Team: Leitung und Finanzen / Beschaffung. Diese Kategorie ist auszuwählen, wenn eine neue Liegenschaft, Außenstelle, Schule oder ein größerer Gebäudebereich IT-seitig ausgestattet, angebunden oder vollständig umgezogen werden soll. Typische Ticketformulierungen sind: „Neue Außenstelle ausstatten“; „Verwaltungsbereich zieht um“; „Neues Gebäude ans Netz anbinden“; „Kompletter Standortwechsel“. Nicht auswählen, wenn nur ein einzelner Arbeitsplatz innerhalb eines Gebäudes umgesetzt oder eine bestehende Standortleitung gestört ist. Für die Klassifizierung sind der konkret betroffene Dienst oder Gegenstand, die Fehlermeldung, die Anzahl betroffener Personen, der Standort sowie die Unterscheidung zwischen Störung, Berechtigung, Bestellung und Änderungswunsch besonders wichtig. Einzelne unspezifische Wörter wie „geht nicht“, „Problem“ oder „dringend“ reichen ohne Sachbezug nicht für diese Zuordnung aus. Abgrenzungsregel: Die Leitung koordiniert; Infrastruktur, Support, Fachanwendungen, Telekommunikation und Beschaffung liefern Teilaufgaben.

## Lösung / Antwort

Interne Klassifizierung: Das Ticket ist der Kategorie „Projekte, Änderungen und neue Anforderungen > Standorteröffnung und Umzug“ zuzuordnen. Primär zuständig ist „Leitung und Finanzen / Beschaffung“. Vor der endgültigen Zuweisung sind die genannten Ausschlusskriterien und Schnittstellen zu prüfen.

## Verknüpfungen

- [[Wiki/Categories/projekte-aenderungen-und-neue-anforderungen-standorteroeffnung-und-umzug|Projekte, Änderungen und neue Anforderungen > Standorteröffnung und Umzug]] — Kategorie
- Quelle: `kb://internal-kb/glpi-kategorien/projekte-anderungen-und-neue-anforderungen/standorteroffnung-und-umzug`
