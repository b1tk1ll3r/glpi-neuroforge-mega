---
type: "knowledge"
title: "LAN"
id: "KAT-LAN-SELECT"
source: "internal-category"
source_uri: "kb://internal-kb/glpi-kategorien/netzwerk-und-verbindungen/lan"
language: "de-DE"
communication_style: "formal"
created: "2026-08-05"
updated: "2026-08-05"
auto_reply: false
min_score: 0.7
tags:
  - "Ethernet"
  - "LAN"
  - "Netzwerk und Verbindungen"
  - "Netzwerkdose"
  - "Netzwerkkabel"
  - "Patchen"
  - "Switchport"
  - "kabelgebunden"
  - "kein Netzwerk"
categories:
  - "Netzwerk und Verbindungen \u003e LAN"
related:
  - "[[Wiki/Categories/netzwerk-und-verbindungen-lan|Netzwerk und Verbindungen \u003e LAN]]"
---

# LAN

## Kontext / Problem

Auswahlziel: Netzwerk und Verbindungen > LAN. Primär zuständiges Team: Infrastruktur und Backend. Diese Kategorie ist auszuwählen, wenn eine kabelgebundene Netzwerkverbindung, Netzwerkdose, Patchung oder Ethernet-Verbindung nicht funktioniert, instabil ist oder neu bereitgestellt werden soll. Typische Ticketformulierungen sind: „Netzwerkdose ohne Verbindung“; „LAN bricht ab“; „Kein Netzwerk über Kabel“; „Neue Dose patchen“. Nicht auswählen, wenn ausschließlich WLAN, VPN, Internetzugang oder ein einzelner defekter Dockingadapter betroffen ist. Für die Klassifizierung sind der konkret betroffene Dienst oder Gegenstand, die Fehlermeldung, die Anzahl betroffener Personen, der Standort sowie die Unterscheidung zwischen Störung, Berechtigung, Bestellung und Änderungswunsch besonders wichtig. Einzelne unspezifische Wörter wie „geht nicht“, „Problem“ oder „dringend“ reichen ohne Sachbezug nicht für diese Zuordnung aus. Abgrenzungsregel: Bei nur einem Arbeitsplatz prüft der Support zunächst Kabel, Dock und Gerät; zentrale Komponenten liegen bei Infrastruktur.

## Lösung / Antwort

Interne Klassifizierung: Das Ticket ist der Kategorie „Netzwerk und Verbindungen > LAN“ zuzuordnen. Primär zuständig ist „Infrastruktur und Backend“. Vor der endgültigen Zuweisung sind die genannten Ausschlusskriterien und Schnittstellen zu prüfen.

## Verknüpfungen

- [[Wiki/Categories/netzwerk-und-verbindungen-lan|Netzwerk und Verbindungen > LAN]] — Kategorie
- Quelle: `kb://internal-kb/glpi-kategorien/netzwerk-und-verbindungen/lan`
