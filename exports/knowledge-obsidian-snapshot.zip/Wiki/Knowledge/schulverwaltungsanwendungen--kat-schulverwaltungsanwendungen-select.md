---
type: "knowledge"
title: "Schulverwaltungsanwendungen"
id: "KAT-SCHULVERWALTUNGSANWENDUNGEN-SELECT"
source: "internal-category"
source_uri: "kb://internal-kb/glpi-kategorien/schulspezifische-it-systeme/schulverwaltungsanwendungen"
language: "de-DE"
communication_style: "formal"
created: "2026-08-05"
updated: "2026-08-05"
auto_reply: false
min_score: 0.7
tags:
  - "Schulorganisation"
  - "Schulsoftware"
  - "Schulspezifische IT-Systeme"
  - "Schulverwaltungsanwendung"
  - "Schulverwaltungsanwendungen"
  - "Schülerverwaltung"
  - "Stundenplan"
  - "Vertretungsplan"
  - "Zeugnisprogramm"
categories:
  - "Schulspezifische IT-Systeme \u003e Schulverwaltungsanwendungen"
related:
  - "[[Wiki/Categories/schulspezifische-it-systeme-schulverwaltungsanwendungen|Schulspezifische IT-Systeme \u003e Schulverwaltungsanwendungen]]"
---

# Schulverwaltungsanwendungen

## Kontext / Problem

Auswahlziel: Schulspezifische IT-Systeme > Schulverwaltungsanwendungen. Primär zuständiges Team: Schulen. Diese Kategorie ist auszuwählen, wenn eine speziell in Schulen eingesetzte Verwaltungsanwendung für Stundenplan, Schülerverwaltung, Zeugnisse, Vertretung oder Schulorganisation gestört ist oder Unterstützung benötigt wird. Typische Ticketformulierungen sind: „Zeugnisprogramm zeigt Fehler“; „Stundenplananwendung funktioniert nicht“; „Schülerverwaltungssoftware gestört“; „Vertretungsplan synchronisiert nicht“. Nicht auswählen, wenn eine allgemeine kommunale Fachanwendung, Lernplattform oder reine Netzwerkstörung betroffen ist. Für die Klassifizierung sind der konkret betroffene Dienst oder Gegenstand, die Fehlermeldung, die Anzahl betroffener Personen, der Standort sowie die Unterscheidung zwischen Störung, Berechtigung, Bestellung und Änderungswunsch besonders wichtig. Einzelne unspezifische Wörter wie „geht nicht“, „Problem“ oder „dringend“ reichen ohne Sachbezug nicht für diese Zuordnung aus. Abgrenzungsregel: Fachanwendungs-Know-how kann mittelfristig an Fachanwendungen überführt werden; zentrale Plattformursachen an Infrastruktur.

## Lösung / Antwort

Interne Klassifizierung: Das Ticket ist der Kategorie „Schulspezifische IT-Systeme > Schulverwaltungsanwendungen“ zuzuordnen. Primär zuständig ist „Schulen“. Vor der endgültigen Zuweisung sind die genannten Ausschlusskriterien und Schnittstellen zu prüfen.

## Verknüpfungen

- [[Wiki/Categories/schulspezifische-it-systeme-schulverwaltungsanwendungen|Schulspezifische IT-Systeme > Schulverwaltungsanwendungen]] — Kategorie
- Quelle: `kb://internal-kb/glpi-kategorien/schulspezifische-it-systeme/schulverwaltungsanwendungen`
