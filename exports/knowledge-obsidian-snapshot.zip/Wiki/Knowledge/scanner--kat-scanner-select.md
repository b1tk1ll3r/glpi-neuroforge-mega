---
type: "knowledge"
title: "Scanner"
id: "KAT-SCANNER-SELECT"
source: "internal-category"
source_uri: "kb://internal-kb/glpi-kategorien/drucken-scannen-und-kopieren/scanner"
language: "de-DE"
communication_style: "formal"
created: "2026-08-05"
updated: "2026-08-05"
auto_reply: false
min_score: 0.7
tags:
  - "Dokumentenscanner"
  - "Drucken, Scannen und Kopieren"
  - "Einzug"
  - "Scanfehler"
  - "Scannen"
  - "Scanner"
  - "Scanprogramm"
  - "TWAIN"
  - "WIA"
categories:
  - "Drucken, Scannen und Kopieren \u003e Scanner"
related:
  - "[[Wiki/Categories/drucken-scannen-und-kopieren-scanner|Drucken, Scannen und Kopieren \u003e Scanner]]"
---

# Scanner

## Kontext / Problem

Auswahlziel: Drucken, Scannen und Kopieren > Scanner. Primär zuständiges Team: Support und Telekommunikation. Diese Kategorie ist auszuwählen, wenn ein Arbeitsplatz- oder Dokumentenscanner nicht erkannt wird, nicht scannt, Einzugsprobleme zeigt oder die lokale Scansoftware fehlerhaft ist. Typische Ticketformulierungen sind: „Scanner wird nicht erkannt“; „Dokumenteneinzug fehlerhaft“; „Scanprogramm startet nicht“; „Scandatei wird nicht erzeugt“. Nicht auswählen, wenn die zentrale Übertragung per Scan-to-Mail oder Scan-to-Folder scheitert oder ein Multifunktionsgerät insgesamt betroffen ist. Für die Klassifizierung sind der konkret betroffene Dienst oder Gegenstand, die Fehlermeldung, die Anzahl betroffener Personen, der Standort sowie die Unterscheidung zwischen Störung, Berechtigung, Bestellung und Änderungswunsch besonders wichtig. Einzelne unspezifische Wörter wie „geht nicht“, „Problem“ oder „dringend“ reichen ohne Sachbezug nicht für diese Zuordnung aus. Abgrenzungsregel: Übertragungsziele und zentrale Dienste werden in Scan-to-Mail und Scan-to-Folder erfasst.

## Lösung / Antwort

Interne Klassifizierung: Das Ticket ist der Kategorie „Drucken, Scannen und Kopieren > Scanner“ zuzuordnen. Primär zuständig ist „Support und Telekommunikation“. Vor der endgültigen Zuweisung sind die genannten Ausschlusskriterien und Schnittstellen zu prüfen.

## Verknüpfungen

- [[Wiki/Categories/drucken-scannen-und-kopieren-scanner|Drucken, Scannen und Kopieren > Scanner]] — Kategorie
- Quelle: `kb://internal-kb/glpi-kategorien/drucken-scannen-und-kopieren/scanner`
