---
type: "knowledge"
title: "Multifunktionsgerät und Kopierer"
id: "KAT-MULTIFUNKTIONSGERAT-UND-KOPIERER-SELECT"
source: "internal-category"
source_uri: "kb://internal-kb/glpi-kategorien/drucken-scannen-und-kopieren/multifunktionsgerat-und-kopierer"
language: "de-DE"
communication_style: "formal"
created: "2026-08-05"
updated: "2026-08-05"
auto_reply: false
min_score: 0.7
tags:
  - "Bedienfeld"
  - "Dokumenteneinzug"
  - "Drucken, Scannen und Kopieren"
  - "Fehlercode"
  - "Kopieren"
  - "Kopierer"
  - "MFP"
  - "Multifunktionsgerät"
  - "Multifunktionsgerät und Kopierer"
categories:
  - "Drucken, Scannen und Kopieren \u003e Multifunktionsgerät und Kopierer"
related:
  - "[[Wiki/Categories/drucken-scannen-und-kopieren-multifunktionsgeraet-und-kopierer|Drucken, Scannen und Kopieren \u003e Multifunktionsgerät und Kopierer]]"
---

# Multifunktionsgerät und Kopierer

## Kontext / Problem

Auswahlziel: Drucken, Scannen und Kopieren > Multifunktionsgerät und Kopierer. Primär zuständiges Team: Support und Telekommunikation. Diese Kategorie ist auszuwählen, wenn ein Multifunktionsgerät oder Kopierer beim Drucken, Kopieren, Einzug, Bedienfeld oder Gerätebetrieb fehlerhaft ist. Typische Ticketformulierungen sind: „Kopierer zeigt Fehlercode“; „Dokumenteneinzug klemmt“; „MFP kopiert nicht“; „Bedienfeld reagiert nicht“. Nicht auswählen, wenn ausschließlich Scan-to-Mail, ein einzelner Arbeitsplatzdrucker oder eine Neubeschaffung betroffen ist. Für die Klassifizierung sind der konkret betroffene Dienst oder Gegenstand, die Fehlermeldung, die Anzahl betroffener Personen, der Standort sowie die Unterscheidung zwischen Störung, Berechtigung, Bestellung und Änderungswunsch besonders wichtig. Einzelne unspezifische Wörter wie „geht nicht“, „Problem“ oder „dringend“ reichen ohne Sachbezug nicht für diese Zuordnung aus. Abgrenzungsregel: Vertragspartner- oder Wartungseinsätze können durch Support koordiniert werden.

## Lösung / Antwort

Interne Klassifizierung: Das Ticket ist der Kategorie „Drucken, Scannen und Kopieren > Multifunktionsgerät und Kopierer“ zuzuordnen. Primär zuständig ist „Support und Telekommunikation“. Vor der endgültigen Zuweisung sind die genannten Ausschlusskriterien und Schnittstellen zu prüfen.

## Verknüpfungen

- [[Wiki/Categories/drucken-scannen-und-kopieren-multifunktionsgeraet-und-kopierer|Drucken, Scannen und Kopieren > Multifunktionsgerät und Kopierer]] — Kategorie
- Quelle: `kb://internal-kb/glpi-kategorien/drucken-scannen-und-kopieren/multifunktionsgerat-und-kopierer`
