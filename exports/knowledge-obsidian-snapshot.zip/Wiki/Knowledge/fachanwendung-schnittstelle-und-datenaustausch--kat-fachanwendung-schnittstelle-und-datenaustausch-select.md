---
type: "knowledge"
title: "Fachanwendung – Schnittstelle und Datenaustausch"
id: "KAT-FACHANWENDUNG-SCHNITTSTELLE-UND-DATENAUSTAUSCH-SELECT"
source: "internal-category"
source_uri: "kb://internal-kb/glpi-kategorien/fachanwendungen-und-microsoft-office/fachanwendung-schnittstelle-und-datenaustausch"
language: "de-DE"
communication_style: "formal"
created: "2026-08-05"
updated: "2026-08-05"
auto_reply: false
min_score: 0.7
tags:
  - "API"
  - "Dateiübergabe"
  - "Datenaustausch"
  - "Export"
  - "Fachanwendung – Schnittstelle und Datenaustausch"
  - "Fachanwendungen und Microsoft Office"
  - "Fremdsystem"
  - "Import"
  - "Interface"
  - "Schnittstelle"
  - "Webservice"
  - "Übertragung"
categories:
  - "Fachanwendungen und Microsoft Office \u003e Fachanwendung – Schnittstelle und Datenaustausch"
related:
  - "[[Wiki/Categories/fachanwendungen-und-microsoft-office-fachanwendung-schnittstelle-und-datenaustausch|Fachanwendungen und Microsoft Office \u003e Fachanwendung – Schnittstelle und Datenaustausch]]"
---

# Fachanwendung – Schnittstelle und Datenaustausch

## Kontext / Problem

Auswahlziel: Fachanwendungen und Microsoft Office > Fachanwendung – Schnittstelle und Datenaustausch. Primär zuständiges Team: Fachanwendungen. Diese Kategorie ist auszuwählen, wenn Import, Export, Webservice, Dateiübergabe oder Datenaustausch zwischen einer Fachanwendung und einem anderen System fehlschlägt oder neu eingerichtet werden soll. Typische Ticketformulierungen sind: „Importdatei wird abgewiesen“; „Export kommt nicht im Zielsystem an“; „Schnittstelle liefert Fehler“; „Datenaustausch einrichten“. Nicht auswählen, wenn nur die Netzwerkverbindung eines Standorts gestört ist, ein allgemeiner Dateiablagefehler vorliegt oder eine rein manuelle Auswertung benötigt wird. Für die Klassifizierung sind der konkret betroffene Dienst oder Gegenstand, die Fehlermeldung, die Anzahl betroffener Personen, der Standort sowie die Unterscheidung zwischen Störung, Berechtigung, Bestellung und Änderungswunsch besonders wichtig. Einzelne unspezifische Wörter wie „geht nicht“, „Problem“ oder „dringend“ reichen ohne Sachbezug nicht für diese Zuordnung aus. Abgrenzungsregel: Bei Firewall- oder Netzwerkfreischaltungen arbeitet Fachanwendungen mit Infrastruktur und Backend zusammen; fachliche Datenformate bleiben bei Fachanwendungen.

## Lösung / Antwort

Interne Klassifizierung: Das Ticket ist der Kategorie „Fachanwendungen und Microsoft Office > Fachanwendung – Schnittstelle und Datenaustausch“ zuzuordnen. Primär zuständig ist „Fachanwendungen“. Vor der endgültigen Zuweisung sind die genannten Ausschlusskriterien und Schnittstellen zu prüfen.

## Verknüpfungen

- [[Wiki/Categories/fachanwendungen-und-microsoft-office-fachanwendung-schnittstelle-und-datenaustausch|Fachanwendungen und Microsoft Office > Fachanwendung – Schnittstelle und Datenaustausch]] — Kategorie
- Quelle: `kb://internal-kb/glpi-kategorien/fachanwendungen-und-microsoft-office/fachanwendung-schnittstelle-und-datenaustausch`
