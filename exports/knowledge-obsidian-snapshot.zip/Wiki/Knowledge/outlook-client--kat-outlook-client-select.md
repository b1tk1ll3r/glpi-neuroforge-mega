---
type: "knowledge"
title: "Outlook-Client"
id: "KAT-OUTLOOK-CLIENT-SELECT"
source: "internal-category"
source_uri: "kb://internal-kb/glpi-kategorien/fachanwendungen-und-microsoft-office/outlook-client"
language: "de-DE"
communication_style: "formal"
created: "2026-08-05"
updated: "2026-08-05"
auto_reply: false
min_score: 0.7
tags:
  - "Fachanwendungen und Microsoft Office"
  - "Kalenderansicht"
  - "OST"
  - "Outlook"
  - "Outlook Suche"
  - "Outlook-Client"
  - "PST"
  - "Profil"
  - "Signatur"
  - "lokales Outlook"
categories:
  - "Fachanwendungen und Microsoft Office \u003e Outlook-Client"
related:
  - "[[Wiki/Categories/fachanwendungen-und-microsoft-office-outlook-client|Fachanwendungen und Microsoft Office \u003e Outlook-Client]]"
---

# Outlook-Client

## Kontext / Problem

Auswahlziel: Fachanwendungen und Microsoft Office > Outlook-Client. Primär zuständiges Team: Fachanwendungen. Diese Kategorie ist auszuwählen, wenn die lokale Outlook-Anwendung nicht startet, Profile oder Ansichten fehlerhaft sind, Suche, Kalenderdarstellung, Signatur oder lokale Outlook-Funktionen nicht korrekt arbeiten. Typische Ticketformulierungen sind: „Outlook startet nicht“; „Outlook-Profil defekt“; „Suche findet nichts“; „Kalenderansicht fehlerhaft“; „Signatur fehlt“. Nicht auswählen, wenn das Postfach serverseitig nicht erreichbar ist, E-Mails organisationsweit nicht zugestellt werden, ein Funktionspostfach beantragt wird oder nur das Kennwort gesperrt ist. Für die Klassifizierung sind der konkret betroffene Dienst oder Gegenstand, die Fehlermeldung, die Anzahl betroffener Personen, der Standort sowie die Unterscheidung zwischen Störung, Berechtigung, Bestellung und Änderungswunsch besonders wichtig. Einzelne unspezifische Wörter wie „geht nicht“, „Problem“ oder „dringend“ reichen ohne Sachbezug nicht für diese Zuordnung aus. Abgrenzungsregel: Serverseitige Mail- und Postfachstörungen werden an Infrastruktur und Backend übergeben.

## Lösung / Antwort

Interne Klassifizierung: Das Ticket ist der Kategorie „Fachanwendungen und Microsoft Office > Outlook-Client“ zuzuordnen. Primär zuständig ist „Fachanwendungen“. Vor der endgültigen Zuweisung sind die genannten Ausschlusskriterien und Schnittstellen zu prüfen.

## Verknüpfungen

- [[Wiki/Categories/fachanwendungen-und-microsoft-office-outlook-client|Fachanwendungen und Microsoft Office > Outlook-Client]] — Kategorie
- Quelle: `kb://internal-kb/glpi-kategorien/fachanwendungen-und-microsoft-office/outlook-client`
