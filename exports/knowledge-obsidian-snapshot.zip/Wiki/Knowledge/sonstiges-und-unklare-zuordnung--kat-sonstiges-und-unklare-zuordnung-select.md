---
type: "knowledge"
title: "Sonstiges und unklare Zuordnung"
id: "KAT-SONSTIGES-UND-UNKLARE-ZUORDNUNG-SELECT"
source: "internal-category"
source_uri: "kb://internal-kb/glpi-kategorien/sonstiges-und-unklare-zuordnung/sonstiges-und-unklare-zuordnung"
language: "de-DE"
communication_style: "formal"
created: "2026-08-05"
updated: "2026-08-05"
auto_reply: false
min_score: 0.7
tags:
  - "Sonstiges und unklare Zuordnung"
  - "allgemeines IT-Problem"
  - "divers"
  - "keine Zuordnung"
  - "nicht näher beschrieben"
  - "sonstiges"
  - "unklar"
categories:
  - "Sonstiges und unklare Zuordnung \u003e Sonstiges und unklare Zuordnung"
related:
  - "[[Wiki/Categories/sonstiges-und-unklare-zuordnung-sonstiges-und-unklare-zuordnung|Sonstiges und unklare Zuordnung \u003e Sonstiges und unklare Zuordnung]]"
---

# Sonstiges und unklare Zuordnung

## Kontext / Problem

Auswahlziel: Sonstiges und unklare Zuordnung > Sonstiges und unklare Zuordnung. Primär zuständiges Team: Support und Telekommunikation. Diese Kategorie ist auszuwählen, nur wenn das Ticket trotz ausreichender Beschreibung keiner vorhandenen Kategorie zuverlässig zugeordnet werden kann, mehrere völlig unterschiedliche Anliegen untrennbar vermischt oder der betroffene IT-Service nicht erkennbar ist. Typische Ticketformulierungen sind: „Unklarer IT-Fehler ohne erkennbaren Dienst“; „Mehrere nicht trennbare Anliegen“; „Betroffenes System nicht identifizierbar“. Nicht auswählen, wenn anhand von Anwendung, Gerät, Fehlermeldung, Standort oder gewünschter Leistung eine spezifische Kategorie gewählt werden kann. Diese Kategorie darf nicht allein wegen kurzer oder unvollständiger Formulierung bevorzugt werden. Für die Klassifizierung sind der konkret betroffene Dienst oder Gegenstand, die Fehlermeldung, die Anzahl betroffener Personen, der Standort sowie die Unterscheidung zwischen Störung, Berechtigung, Bestellung und Änderungswunsch besonders wichtig. Einzelne unspezifische Wörter wie „geht nicht“, „Problem“ oder „dringend“ reichen ohne Sachbezug nicht für diese Zuordnung aus. Abgrenzungsregel: Diese Auffangkategorie soll selten verwendet und regelmäßig ausgewertet werden. Vor Auswahl sind Hauptbegriffe und Kontext gegen alle spezifischen Kategorien zu prüfen.

## Lösung / Antwort

Interne Klassifizierung: Das Ticket ist der Kategorie „Sonstiges und unklare Zuordnung > Sonstiges und unklare Zuordnung“ zuzuordnen. Primär zuständig ist „Support und Telekommunikation“. Vor der endgültigen Zuweisung sind die genannten Ausschlusskriterien und Schnittstellen zu prüfen.

## Verknüpfungen

- [[Wiki/Categories/sonstiges-und-unklare-zuordnung-sonstiges-und-unklare-zuordnung|Sonstiges und unklare Zuordnung > Sonstiges und unklare Zuordnung]] — Kategorie
- Quelle: `kb://internal-kb/glpi-kategorien/sonstiges-und-unklare-zuordnung/sonstiges-und-unklare-zuordnung`
