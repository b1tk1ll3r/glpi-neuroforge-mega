---
type: "knowledge"
title: "Druckertreiber"
id: "KAT-DRUCKERTREIBER-SELECT"
source: "internal-category"
source_uri: "kb://internal-kb/glpi-kategorien/drucken-scannen-und-kopieren/druckertreiber"
language: "de-DE"
communication_style: "formal"
created: "2026-08-05"
updated: "2026-08-05"
auto_reply: false
min_score: 0.7
tags:
  - "Drucken, Scannen und Kopieren"
  - "Druckerinstallation"
  - "Druckertreiber"
  - "Duplex"
  - "Papierfach"
  - "Printer Driver"
  - "Treiber"
  - "Treiberfehler"
categories:
  - "Drucken, Scannen und Kopieren \u003e Druckertreiber"
related:
  - "[[Wiki/Categories/drucken-scannen-und-kopieren-druckertreiber|Drucken, Scannen und Kopieren \u003e Druckertreiber]]"
---

# Druckertreiber

## Kontext / Problem

Auswahlziel: Drucken, Scannen und Kopieren > Druckertreiber. Primär zuständiges Team: Support und Telekommunikation. Diese Kategorie ist auszuwählen, wenn ein Druckertreiber fehlt, fehlerhaft ist, aktualisiert werden muss oder falsche Papierfächer, Formate und Gerätefunktionen bereitstellt. Typische Ticketformulierungen sind: „Treiber lässt sich nicht installieren“; „Falsches Papierformat“; „Duplexoption fehlt“; „Druckertreiber aktualisieren“. Nicht auswählen, wenn der Drucker physisch defekt, das Netzwerk ausgefallen oder eine zentrale Druckserverplattform gestört ist. Für die Klassifizierung sind der konkret betroffene Dienst oder Gegenstand, die Fehlermeldung, die Anzahl betroffener Personen, der Standort sowie die Unterscheidung zwischen Störung, Berechtigung, Bestellung und Änderungswunsch besonders wichtig. Einzelne unspezifische Wörter wie „geht nicht“, „Problem“ oder „dringend“ reichen ohne Sachbezug nicht für diese Zuordnung aus. Abgrenzungsregel: Zentrale Treiberpakete können eine Abstimmung mit Infrastruktur und Backend erfordern.

## Lösung / Antwort

Interne Klassifizierung: Das Ticket ist der Kategorie „Drucken, Scannen und Kopieren > Druckertreiber“ zuzuordnen. Primär zuständig ist „Support und Telekommunikation“. Vor der endgültigen Zuweisung sind die genannten Ausschlusskriterien und Schnittstellen zu prüfen.

## Verknüpfungen

- [[Wiki/Categories/drucken-scannen-und-kopieren-druckertreiber|Drucken, Scannen und Kopieren > Druckertreiber]] — Kategorie
- Quelle: `kb://internal-kb/glpi-kategorien/drucken-scannen-und-kopieren/druckertreiber`
