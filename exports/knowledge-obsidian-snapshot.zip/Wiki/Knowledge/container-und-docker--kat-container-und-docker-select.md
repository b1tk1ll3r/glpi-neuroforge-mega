---
type: "knowledge"
title: "Container und Docker"
id: "KAT-CONTAINER-UND-DOCKER-SELECT"
source: "internal-category"
source_uri: "kb://internal-kb/glpi-kategorien/server-backend-und-plattformen/container-und-docker"
language: "de-DE"
communication_style: "formal"
created: "2026-08-05"
updated: "2026-08-05"
auto_reply: false
min_score: 0.7
tags:
  - "Container"
  - "Container Runtime"
  - "Container startet nicht"
  - "Container und Docker"
  - "Containerplattform"
  - "Docker"
  - "Docker Compose"
  - "Image"
  - "Registry"
  - "Server, Backend und Plattformen"
categories:
  - "Server, Backend und Plattformen \u003e Container und Docker"
related:
  - "[[Wiki/Categories/server-backend-und-plattformen-container-und-docker|Server, Backend und Plattformen \u003e Container und Docker]]"
---

# Container und Docker

## Kontext / Problem

Auswahlziel: Server, Backend und Plattformen > Container und Docker. Primär zuständiges Team: Infrastruktur und Backend. Diese Kategorie ist auszuwählen, wenn Docker-Hosts, Container, Images, Registries, Compose-Stacks oder containerbasierte Laufzeitumgebungen bereitgestellt, gewartet oder analysiert werden sollen. Typische Ticketformulierungen sind: „Docker-Container startet nicht“; „Image bereitstellen“; „Registry-Zugriff fehlerhaft“; „Compose-Stack deployen“. Nicht auswählen, wenn ein Kubernetes-Cluster betroffen ist, eine klassische VM benötigt wird oder nur die Fachanwendung im Container fachlich fehlerhaft ist. Für die Klassifizierung sind der konkret betroffene Dienst oder Gegenstand, die Fehlermeldung, die Anzahl betroffener Personen, der Standort sowie die Unterscheidung zwischen Störung, Berechtigung, Bestellung und Änderungswunsch besonders wichtig. Einzelne unspezifische Wörter wie „geht nicht“, „Problem“ oder „dringend“ reichen ohne Sachbezug nicht für diese Zuordnung aus. Abgrenzungsregel: Bei Sicherheitslücken in Images ist zusätzlich IT-Sicherheit relevant.

## Lösung / Antwort

Interne Klassifizierung: Das Ticket ist der Kategorie „Server, Backend und Plattformen > Container und Docker“ zuzuordnen. Primär zuständig ist „Infrastruktur und Backend“. Vor der endgültigen Zuweisung sind die genannten Ausschlusskriterien und Schnittstellen zu prüfen.

## Verknüpfungen

- [[Wiki/Categories/server-backend-und-plattformen-container-und-docker|Server, Backend und Plattformen > Container und Docker]] — Kategorie
- Quelle: `kb://internal-kb/glpi-kategorien/server-backend-und-plattformen/container-und-docker`
