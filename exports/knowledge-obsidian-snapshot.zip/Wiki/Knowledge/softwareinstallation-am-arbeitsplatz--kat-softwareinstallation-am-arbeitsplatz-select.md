---
type: "knowledge"
title: "Softwareinstallation am Arbeitsplatz"
id: "KAT-SOFTWAREINSTALLATION-AM-ARBEITSPLATZ-SELECT"
source: "internal-category"
source_uri: "kb://internal-kb/glpi-kategorien/arbeitsplatz-und-endgerate/softwareinstallation-am-arbeitsplatz"
language: "de-DE"
communication_style: "formal"
created: "2026-08-05"
updated: "2026-08-05"
auto_reply: false
min_score: 0.7
tags:
  - "Anwendung installieren"
  - "Arbeitsplatz und Endgeräte"
  - "Client"
  - "Deinstallation"
  - "Neuinstallation"
  - "Programm installieren"
  - "Setup"
  - "Software fehlt"
  - "Softwareinstallation"
  - "Softwareinstallation am Arbeitsplatz"
  - "Standardsoftware"
categories:
  - "Arbeitsplatz und Endgeräte \u003e Softwareinstallation am Arbeitsplatz"
related:
  - "[[Wiki/Categories/arbeitsplatz-und-endgeraete-softwareinstallation-am-arbeitsplatz|Arbeitsplatz und Endgeräte \u003e Softwareinstallation am Arbeitsplatz]]"
---

# Softwareinstallation am Arbeitsplatz

## Kontext / Problem

Auswahlziel: Arbeitsplatz und Endgeräte > Softwareinstallation am Arbeitsplatz. Primär zuständiges Team: Support und Telekommunikation. Diese Kategorie ist auszuwählen, wenn freigegebene Standardsoftware auf einem einzelnen Arbeitsplatz installiert, aktualisiert, repariert oder deinstalliert werden soll und keine zentrale Plattformänderung erforderlich ist. Typische Ticketformulierungen sind: „PDF-Programm installieren“; „Freigegebene Software fehlt“; „Client-Anwendung neu installieren“; „Programm deinstallieren“. Nicht auswählen, wenn eine neue, bisher nicht freigegebene Software beschafft oder fachlich eingeführt werden soll; wenn ein Server, Container oder eine größere Clientverteilung betroffen ist. Für die Klassifizierung sind der konkret betroffene Dienst oder Gegenstand, die Fehlermeldung, die Anzahl betroffener Personen, der Standort sowie die Unterscheidung zwischen Störung, Berechtigung, Bestellung und Änderungswunsch besonders wichtig. Einzelne unspezifische Wörter wie „geht nicht“, „Problem“ oder „dringend“ reichen ohne Sachbezug nicht für diese Zuordnung aus. Abgrenzungsregel: Neue oder lizenzpflichtige Software wird zunächst über Beschaffung beziehungsweise Fachanwendungen geprüft.

## Lösung / Antwort

Interne Klassifizierung: Das Ticket ist der Kategorie „Arbeitsplatz und Endgeräte > Softwareinstallation am Arbeitsplatz“ zuzuordnen. Primär zuständig ist „Support und Telekommunikation“. Vor der endgültigen Zuweisung sind die genannten Ausschlusskriterien und Schnittstellen zu prüfen.

## Verknüpfungen

- [[Wiki/Categories/arbeitsplatz-und-endgeraete-softwareinstallation-am-arbeitsplatz|Arbeitsplatz und Endgeräte > Softwareinstallation am Arbeitsplatz]] — Kategorie
- Quelle: `kb://internal-kb/glpi-kategorien/arbeitsplatz-und-endgerate/softwareinstallation-am-arbeitsplatz`
