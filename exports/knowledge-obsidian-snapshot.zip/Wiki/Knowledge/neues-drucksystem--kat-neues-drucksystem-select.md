---
type: "knowledge"
title: "Neues Drucksystem"
id: "KAT-NEUES-DRUCKSYSTEM-SELECT"
source: "internal-category"
source_uri: "kb://internal-kb/glpi-kategorien/drucken-scannen-und-kopieren/neues-drucksystem"
language: "de-DE"
communication_style: "formal"
created: "2026-08-05"
updated: "2026-08-05"
auto_reply: false
min_score: 0.7
tags:
  - "Ausschreibung Drucker"
  - "Drucken, Scannen und Kopieren"
  - "Drucker beschaffen"
  - "Druckkonzept"
  - "Kopierer beschaffen"
  - "MFP kaufen"
  - "Neugerät"
  - "neues Drucksystem"
categories:
  - "Drucken, Scannen und Kopieren \u003e Neues Drucksystem"
related:
  - "[[Wiki/Categories/drucken-scannen-und-kopieren-neues-drucksystem|Drucken, Scannen und Kopieren \u003e Neues Drucksystem]]"
---

# Neues Drucksystem

## Kontext / Problem

Auswahlziel: Drucken, Scannen und Kopieren > Neues Drucksystem. Primär zuständiges Team: Leitung und Finanzen / Beschaffung. Diese Kategorie ist auszuwählen, wenn ein neuer Drucker, Kopierer, Scannerverbund oder ein standortweites Druckkonzept beschafft, ersetzt oder geplant werden soll. Typische Ticketformulierungen sind: „Neuen Kopierer beschaffen“; „Druckerkonzept für Standort“; „Zusätzlichen Netzwerkdrucker bestellen“; „Altgerät ersetzen“. Nicht auswählen, wenn nur ein vorhandenes Gerät gestört ist, ein Treiber fehlt oder Verbrauchsmaterial benötigt wird. Für die Klassifizierung sind der konkret betroffene Dienst oder Gegenstand, die Fehlermeldung, die Anzahl betroffener Personen, der Standort sowie die Unterscheidung zwischen Störung, Berechtigung, Bestellung und Änderungswunsch besonders wichtig. Einzelne unspezifische Wörter wie „geht nicht“, „Problem“ oder „dringend“ reichen ohne Sachbezug nicht für diese Zuordnung aus. Abgrenzungsregel: Technische Anforderungen werden gemeinsam mit Support und Infrastruktur bewertet; Kauf und Vertrag liegen bei Beschaffung.

## Lösung / Antwort

Interne Klassifizierung: Das Ticket ist der Kategorie „Drucken, Scannen und Kopieren > Neues Drucksystem“ zuzuordnen. Primär zuständig ist „Leitung und Finanzen / Beschaffung“. Vor der endgültigen Zuweisung sind die genannten Ausschlusskriterien und Schnittstellen zu prüfen.

## Verknüpfungen

- [[Wiki/Categories/drucken-scannen-und-kopieren-neues-drucksystem|Drucken, Scannen und Kopieren > Neues Drucksystem]] — Kategorie
- Quelle: `kb://internal-kb/glpi-kategorien/drucken-scannen-und-kopieren/neues-drucksystem`
