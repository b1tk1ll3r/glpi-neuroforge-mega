---
type: "knowledge"
title: "Lizenzverwaltung"
id: "KAT-LIZENZVERWALTUNG-SELECT"
source: "internal-category"
source_uri: "kb://internal-kb/glpi-kategorien/beschaffung-vertrage-und-lizenzen/lizenzverwaltung"
language: "de-DE"
communication_style: "formal"
created: "2026-08-05"
updated: "2026-08-05"
auto_reply: false
min_score: 0.7
tags:
  - "Ablaufdatum"
  - "Asset Management"
  - "Beschaffung, Verträge und Lizenzen"
  - "Compliance"
  - "Kontingent"
  - "Lizenzbestand"
  - "Lizenzverwaltung"
  - "Lizenzzuordnung"
  - "Nutzungsrecht"
categories:
  - "Beschaffung, Verträge und Lizenzen \u003e Lizenzverwaltung"
related:
  - "[[Wiki/Categories/beschaffung-vertraege-und-lizenzen-lizenzverwaltung|Beschaffung, Verträge und Lizenzen \u003e Lizenzverwaltung]]"
---

# Lizenzverwaltung

## Kontext / Problem

Auswahlziel: Beschaffung, Verträge und Lizenzen > Lizenzverwaltung. Primär zuständiges Team: Leitung und Finanzen / Beschaffung. Diese Kategorie ist auszuwählen, wenn Lizenzbestände, Zuordnungen, Nutzungsrechte, Laufzeiten, Compliance oder verfügbare Kontingente dokumentiert und geprüft werden sollen. Typische Ticketformulierungen sind: „Lizenzbestand prüfen“; „Lizenz einem Benutzer zuordnen“; „Unterlizenzierung bewerten“; „Laufzeiten auswerten“. Nicht auswählen, wenn neue Lizenzen konkret bestellt oder eine technische Aktivierungsstörung behoben werden muss. Für die Klassifizierung sind der konkret betroffene Dienst oder Gegenstand, die Fehlermeldung, die Anzahl betroffener Personen, der Standort sowie die Unterscheidung zwischen Störung, Berechtigung, Bestellung und Änderungswunsch besonders wichtig. Einzelne unspezifische Wörter wie „geht nicht“, „Problem“ oder „dringend“ reichen ohne Sachbezug nicht für diese Zuordnung aus. Abgrenzungsregel: Technische Zuweisung kann durch Fachteam erfolgen; kaufmännischer Bestand bleibt bei Beschaffung.

## Lösung / Antwort

Interne Klassifizierung: Das Ticket ist der Kategorie „Beschaffung, Verträge und Lizenzen > Lizenzverwaltung“ zuzuordnen. Primär zuständig ist „Leitung und Finanzen / Beschaffung“. Vor der endgültigen Zuweisung sind die genannten Ausschlusskriterien und Schnittstellen zu prüfen.

## Verknüpfungen

- [[Wiki/Categories/beschaffung-vertraege-und-lizenzen-lizenzverwaltung|Beschaffung, Verträge und Lizenzen > Lizenzverwaltung]] — Kategorie
- Quelle: `kb://internal-kb/glpi-kategorien/beschaffung-vertrage-und-lizenzen/lizenzverwaltung`
