---
type: "knowledge"
title: "Anwendungsberechtigung"
id: "KAT-ANWENDUNGSBERECHTIGUNG-SELECT"
source: "internal-category"
source_uri: "kb://internal-kb/glpi-kategorien/benutzerkonten-und-berechtigungen/anwendungsberechtigung"
language: "de-DE"
communication_style: "formal"
created: "2026-08-05"
updated: "2026-08-05"
auto_reply: false
min_score: 0.7
tags:
  - "Anwendungsberechtigung"
  - "Benutzerkonten und Berechtigungen"
  - "Benutzerrolle"
  - "Berechtigung"
  - "Fachanwendung"
  - "Fachverfahren"
  - "Freischaltung"
  - "Mandant"
  - "Modul"
  - "Organisationseinheit"
  - "Rechte"
  - "Rolle"
  - "Zugriff"
categories:
  - "Benutzerkonten und Berechtigungen \u003e Anwendungsberechtigung"
related:
  - "[[Wiki/Categories/benutzerkonten-und-berechtigungen-anwendungsberechtigung|Benutzerkonten und Berechtigungen \u003e Anwendungsberechtigung]]"
---

# Anwendungsberechtigung

## Kontext / Problem

Auswahlziel: Benutzerkonten und Berechtigungen > Anwendungsberechtigung. Primär zuständiges Team: Fachanwendungen. Diese Kategorie ist auszuwählen, wenn ein Benutzer Zugriff, eine Rolle, ein Funktionsrecht oder eine organisatorische Zuordnung innerhalb einer konkreten Fachanwendung benötigt oder wenn eine vorhandene Berechtigung dort nicht korrekt wirkt. Typische Ticketformulierungen sind: „Rolle Sachbearbeitung fehlt“; „Kein Zugriff auf Modul Kasse“; „Berechtigung in Fachverfahren beantragen“; „Benutzer sieht falsche Organisationseinheit“. Nicht auswählen, wenn das zentrale Benutzerkonto selbst fehlt oder gesperrt ist; wenn eine AD-Gruppe oder GPO geändert werden soll; wenn der Zugriff technisch wegen Netzwerk, VPN oder Serverausfall scheitert. Für die Klassifizierung sind der konkret betroffene Dienst oder Gegenstand, die Fehlermeldung, die Anzahl betroffener Personen, der Standort sowie die Unterscheidung zwischen Störung, Berechtigung, Bestellung und Änderungswunsch besonders wichtig. Einzelne unspezifische Wörter wie „geht nicht“, „Problem“ oder „dringend“ reichen ohne Sachbezug nicht für diese Zuordnung aus. Abgrenzungsregel: Die betroffene Anwendung und die gewünschte Rolle sollten genannt werden. Technische Konten bleiben bei Infrastruktur und Backend.

## Lösung / Antwort

Interne Klassifizierung: Das Ticket ist der Kategorie „Benutzerkonten und Berechtigungen > Anwendungsberechtigung“ zuzuordnen. Primär zuständig ist „Fachanwendungen“. Vor der endgültigen Zuweisung sind die genannten Ausschlusskriterien und Schnittstellen zu prüfen.

## Verknüpfungen

- [[Wiki/Categories/benutzerkonten-und-berechtigungen-anwendungsberechtigung|Benutzerkonten und Berechtigungen > Anwendungsberechtigung]] — Kategorie
- Quelle: `kb://internal-kb/glpi-kategorien/benutzerkonten-und-berechtigungen/anwendungsberechtigung`
