---
type: "knowledge"
title: "Schüler- und Lehrkräftekonten"
id: "KAT-SCHULER-UND-LEHRKRAFTEKONTEN-SELECT"
source: "internal-category"
source_uri: "kb://internal-kb/glpi-kategorien/schulspezifische-it-systeme/schuler-und-lehrkraftekonten"
language: "de-DE"
communication_style: "formal"
created: "2026-08-05"
updated: "2026-08-05"
auto_reply: false
min_score: 0.7
tags:
  - "Klassenkonto"
  - "Kontensynchronisation"
  - "Lehrerkonto"
  - "Lehrkräftekonto"
  - "Passwort Schule"
  - "Schulaccount"
  - "Schulspezifische IT-Systeme"
  - "Schüler- und Lehrkräftekonten"
  - "Schülerkonto"
categories:
  - "Schulspezifische IT-Systeme \u003e Schüler- und Lehrkräftekonten"
related:
  - "[[Wiki/Categories/schulspezifische-it-systeme-schueler-und-lehrkraeftekonten|Schulspezifische IT-Systeme \u003e Schüler- und Lehrkräftekonten]]"
---

# Schüler- und Lehrkräftekonten

## Kontext / Problem

Auswahlziel: Schulspezifische IT-Systeme > Schüler- und Lehrkräftekonten. Primär zuständiges Team: Schulen. Diese Kategorie ist auszuwählen, wenn Konten für Schüler, Lehrkräfte oder schulische Gruppen angelegt, geändert, zurückgesetzt, synchronisiert oder deaktiviert werden müssen. Typische Ticketformulierungen sind: „Schülerpasswort zurücksetzen“; „Lehrkraftkonto anlegen“; „Klassenwechsel synchronisieren“; „Schülerkonto deaktivieren“. Nicht auswählen, wenn es um kommunale Verwaltungsaccounts, reine Fachanwendungsrollen oder Konten externer Anbieter ohne Schulbezug geht. Für die Klassifizierung sind der konkret betroffene Dienst oder Gegenstand, die Fehlermeldung, die Anzahl betroffener Personen, der Standort sowie die Unterscheidung zwischen Störung, Berechtigung, Bestellung und Änderungswunsch besonders wichtig. Einzelne unspezifische Wörter wie „geht nicht“, „Problem“ oder „dringend“ reichen ohne Sachbezug nicht für diese Zuordnung aus. Abgrenzungsregel: Bei zentralem AD- oder Identitätsplattformproblem arbeitet Team Schulen mit Infrastruktur und Backend zusammen.

## Lösung / Antwort

Interne Klassifizierung: Das Ticket ist der Kategorie „Schulspezifische IT-Systeme > Schüler- und Lehrkräftekonten“ zuzuordnen. Primär zuständig ist „Schulen“. Vor der endgültigen Zuweisung sind die genannten Ausschlusskriterien und Schnittstellen zu prüfen.

## Verknüpfungen

- [[Wiki/Categories/schulspezifische-it-systeme-schueler-und-lehrkraeftekonten|Schulspezifische IT-Systeme > Schüler- und Lehrkräftekonten]] — Kategorie
- Quelle: `kb://internal-kb/glpi-kategorien/schulspezifische-it-systeme/schuler-und-lehrkraftekonten`
