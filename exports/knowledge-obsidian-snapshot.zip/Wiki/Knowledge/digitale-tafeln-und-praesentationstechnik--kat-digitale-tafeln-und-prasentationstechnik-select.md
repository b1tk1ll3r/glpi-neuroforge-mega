---
type: "knowledge"
title: "Digitale Tafeln und Präsentationstechnik"
id: "KAT-DIGITALE-TAFELN-UND-PRASENTATIONSTECHNIK-SELECT"
source: "internal-category"
source_uri: "kb://internal-kb/glpi-kategorien/schulspezifische-it-systeme/digitale-tafeln-und-prasentationstechnik"
language: "de-DE"
communication_style: "formal"
created: "2026-08-05"
updated: "2026-08-05"
auto_reply: false
min_score: 0.7
tags:
  - "Beamer"
  - "Digitale Tafeln und Präsentationstechnik"
  - "Dokumentenkamera"
  - "Klassenraumtechnik"
  - "Schulspezifische IT-Systeme"
  - "Smartboard"
  - "Whiteboard"
  - "digitale Tafel"
  - "interaktives Display"
categories:
  - "Schulspezifische IT-Systeme \u003e Digitale Tafeln und Präsentationstechnik"
related:
  - "[[Wiki/Categories/schulspezifische-it-systeme-digitale-tafeln-und-praesentationstechnik|Schulspezifische IT-Systeme \u003e Digitale Tafeln und Präsentationstechnik]]"
---

# Digitale Tafeln und Präsentationstechnik

## Kontext / Problem

Auswahlziel: Schulspezifische IT-Systeme > Digitale Tafeln und Präsentationstechnik. Primär zuständiges Team: Schulen. Diese Kategorie ist auszuwählen, wenn interaktive Tafeln, Displays, Beamer, Dokumentenkameras oder fest installierte Präsentationstechnik im Unterricht nicht funktioniert oder eingerichtet werden muss. Typische Ticketformulierungen sind: „Digitale Tafel reagiert nicht“; „Beamer im Klassenraum ohne Bild“; „Dokumentenkamera defekt“; „Interaktives Display kalibrieren“. Nicht auswählen, wenn nur ein normales Arbeitsplatzmonitorproblem, eine allgemeine Videokonferenz oder ein privates Endgerät betroffen ist. Für die Klassifizierung sind der konkret betroffene Dienst oder Gegenstand, die Fehlermeldung, die Anzahl betroffener Personen, der Standort sowie die Unterscheidung zwischen Störung, Berechtigung, Bestellung und Änderungswunsch besonders wichtig. Einzelne unspezifische Wörter wie „geht nicht“, „Problem“ oder „dringend“ reichen ohne Sachbezug nicht für diese Zuordnung aus. Abgrenzungsregel: Netzwerk- oder Backendursachen werden nach Erstprüfung an Infrastruktur weitergegeben.

## Lösung / Antwort

Interne Klassifizierung: Das Ticket ist der Kategorie „Schulspezifische IT-Systeme > Digitale Tafeln und Präsentationstechnik“ zuzuordnen. Primär zuständig ist „Schulen“. Vor der endgültigen Zuweisung sind die genannten Ausschlusskriterien und Schnittstellen zu prüfen.

## Verknüpfungen

- [[Wiki/Categories/schulspezifische-it-systeme-digitale-tafeln-und-praesentationstechnik|Schulspezifische IT-Systeme > Digitale Tafeln und Präsentationstechnik]] — Kategorie
- Quelle: `kb://internal-kb/glpi-kategorien/schulspezifische-it-systeme/digitale-tafeln-und-prasentationstechnik`
