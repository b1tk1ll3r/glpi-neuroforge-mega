---
type: "knowledge"
title: "Fachanwendung – Neue Anforderung"
id: "KAT-FACHANWENDUNG-NEUE-ANFORDERUNG-SELECT"
source: "internal-category"
source_uri: "kb://internal-kb/glpi-kategorien/fachanwendungen-und-microsoft-office/fachanwendung-neue-anforderung"
language: "de-DE"
communication_style: "formal"
created: "2026-08-05"
updated: "2026-08-05"
auto_reply: false
min_score: 0.7
tags:
  - "Anpassungswunsch"
  - "Change Request"
  - "Erweiterung"
  - "Fachanwendung – Neue Anforderung"
  - "Fachanwendungen und Microsoft Office"
  - "Feature"
  - "Prozess digitalisieren"
  - "neue Anforderung"
  - "neue Funktion"
  - "zusätzliches Modul"
categories:
  - "Fachanwendungen und Microsoft Office \u003e Fachanwendung – Neue Anforderung"
related:
  - "[[Wiki/Categories/fachanwendungen-und-microsoft-office-fachanwendung-neue-anforderung|Fachanwendungen und Microsoft Office \u003e Fachanwendung – Neue Anforderung]]"
---

# Fachanwendung – Neue Anforderung

## Kontext / Problem

Auswahlziel: Fachanwendungen und Microsoft Office > Fachanwendung – Neue Anforderung. Primär zuständiges Team: Fachanwendungen. Diese Kategorie ist auszuwählen, wenn eine bestehende Fachanwendung funktional erweitert, ein neuer Prozess abgebildet, ein zusätzliches Modul eingeführt oder eine bislang nicht vorhandene fachliche Funktion umgesetzt werden soll. Typische Ticketformulierungen sind: „Neues Formular im Fachverfahren“; „Zusätzliches Modul benötigt“; „Prozess soll digital abgebildet werden“; „Funktionserweiterung anfragen“. Nicht auswählen, wenn lediglich eine vorhandene Funktion gestört ist, eine kleine Parametrierung ausreicht oder eine komplett neue Anwendung beschafft und eingeführt werden soll. Für die Klassifizierung sind der konkret betroffene Dienst oder Gegenstand, die Fehlermeldung, die Anzahl betroffener Personen, der Standort sowie die Unterscheidung zwischen Störung, Berechtigung, Bestellung und Änderungswunsch besonders wichtig. Einzelne unspezifische Wörter wie „geht nicht“, „Problem“ oder „dringend“ reichen ohne Sachbezug nicht für diese Zuordnung aus. Abgrenzungsregel: Umfang, Nutzen, betroffene Organisation und Priorität sollten dokumentiert werden; größere Vorhaben können in ein Projekt überführt werden.

## Lösung / Antwort

Interne Klassifizierung: Das Ticket ist der Kategorie „Fachanwendungen und Microsoft Office > Fachanwendung – Neue Anforderung“ zuzuordnen. Primär zuständig ist „Fachanwendungen“. Vor der endgültigen Zuweisung sind die genannten Ausschlusskriterien und Schnittstellen zu prüfen.

## Verknüpfungen

- [[Wiki/Categories/fachanwendungen-und-microsoft-office-fachanwendung-neue-anforderung|Fachanwendungen und Microsoft Office > Fachanwendung – Neue Anforderung]] — Kategorie
- Quelle: `kb://internal-kb/glpi-kategorien/fachanwendungen-und-microsoft-office/fachanwendung-neue-anforderung`
