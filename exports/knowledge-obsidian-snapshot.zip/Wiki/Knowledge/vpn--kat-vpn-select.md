---
type: "knowledge"
title: "VPN"
id: "KAT-VPN-SELECT"
source: "internal-category"
source_uri: "kb://internal-kb/glpi-kategorien/netzwerk-und-verbindungen/vpn"
language: "de-DE"
communication_style: "formal"
created: "2026-08-05"
updated: "2026-08-05"
auto_reply: false
min_score: 0.7
tags:
  - "Gateway"
  - "Homeoffice Verbindung"
  - "Netzwerk und Verbindungen"
  - "Remote Access"
  - "Tunnel"
  - "VPN"
  - "VPN Fehler"
  - "VPN-Client"
  - "Verbindung von außen"
categories:
  - "Netzwerk und Verbindungen \u003e VPN"
related:
  - "[[Wiki/Categories/netzwerk-und-verbindungen-vpn|Netzwerk und Verbindungen \u003e VPN]]"
---

# VPN

## Kontext / Problem

Auswahlziel: Netzwerk und Verbindungen > VPN. Primär zuständiges Team: Infrastruktur und Backend. Diese Kategorie ist auszuwählen, wenn ein bereits eingerichteter VPN-Tunnel technisch nicht aufgebaut wird, abbricht, keine internen Ziele erreicht oder eine Client- beziehungsweise Gateway-Fehlermeldung zeigt. Typische Ticketformulierungen sind: „VPN verbindet nicht“; „Tunnel bricht ab“; „Interne Laufwerke über VPN nicht erreichbar“; „VPN-Client meldet Fehler“. Nicht auswählen, wenn der VPN-Zugang erstmals beantragt oder berechtigt werden soll; dafür ist Benutzerkonten und Berechtigungen > Remotezugriff und VPN vorgesehen. Für die Klassifizierung sind der konkret betroffene Dienst oder Gegenstand, die Fehlermeldung, die Anzahl betroffener Personen, der Standort sowie die Unterscheidung zwischen Störung, Berechtigung, Bestellung und Änderungswunsch besonders wichtig. Einzelne unspezifische Wörter wie „geht nicht“, „Problem“ oder „dringend“ reichen ohne Sachbezug nicht für diese Zuordnung aus. Abgrenzungsregel: Berechtigungsfragen und technische Störungen sind bewusst getrennt, um Fehlzuordnungen zu vermeiden.

## Lösung / Antwort

Interne Klassifizierung: Das Ticket ist der Kategorie „Netzwerk und Verbindungen > VPN“ zuzuordnen. Primär zuständig ist „Infrastruktur und Backend“. Vor der endgültigen Zuweisung sind die genannten Ausschlusskriterien und Schnittstellen zu prüfen.

## Verknüpfungen

- [[Wiki/Categories/netzwerk-und-verbindungen-vpn|Netzwerk und Verbindungen > VPN]] — Kategorie
- Quelle: `kb://internal-kb/glpi-kategorien/netzwerk-und-verbindungen/vpn`
