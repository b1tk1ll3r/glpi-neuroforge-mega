---
type: "knowledge"
title: "Rufgruppe und Weiterleitung"
id: "KAT-RUFGRUPPE-UND-WEITERLEITUNG-SELECT"
source: "internal-category"
source_uri: "kb://internal-kb/glpi-kategorien/telefonie-und-kommunikation/rufgruppe-und-weiterleitung"
language: "de-DE"
communication_style: "formal"
created: "2026-08-05"
updated: "2026-08-05"
auto_reply: false
min_score: 0.7
tags:
  - "Anrufweiterleitung"
  - "Erreichbarkeit"
  - "Rufgruppe"
  - "Rufgruppe und Weiterleitung"
  - "Rufumleitung"
  - "Sammelruf"
  - "Telefonie und Kommunikation"
  - "Vertretung"
  - "Weiterleitung"
  - "Zeitsteuerung"
categories:
  - "Telefonie und Kommunikation \u003e Rufgruppe und Weiterleitung"
related:
  - "[[Wiki/Categories/telefonie-und-kommunikation-rufgruppe-und-weiterleitung|Telefonie und Kommunikation \u003e Rufgruppe und Weiterleitung]]"
---

# Rufgruppe und Weiterleitung

## Kontext / Problem

Auswahlziel: Telefonie und Kommunikation > Rufgruppe und Weiterleitung. Primär zuständiges Team: Support und Telekommunikation. Diese Kategorie ist auszuwählen, wenn Rufgruppen, Sammelanschlüsse, Vertretungen, Anrufweiterleitungen, Zeitsteuerungen oder Erreichbarkeitsregeln eingerichtet oder geändert werden sollen. Typische Ticketformulierungen sind: „Rufumleitung für Urlaub“; „Mitarbeiter in Rufgruppe aufnehmen“; „Sammelruf ändern“; „Zeitsteuerung der Zentrale“. Nicht auswählen, wenn eine neue Rufnummer benötigt wird, das Telefon physisch defekt ist oder eine E-Mail-Weiterleitung gemeint ist. Für die Klassifizierung sind der konkret betroffene Dienst oder Gegenstand, die Fehlermeldung, die Anzahl betroffener Personen, der Standort sowie die Unterscheidung zwischen Störung, Berechtigung, Bestellung und Änderungswunsch besonders wichtig. Einzelne unspezifische Wörter wie „geht nicht“, „Problem“ oder „dringend“ reichen ohne Sachbezug nicht für diese Zuordnung aus. Abgrenzungsregel: Gewünschte Quell- und Zielnummer sowie Zeitraum müssen klar angegeben werden.

## Lösung / Antwort

Interne Klassifizierung: Das Ticket ist der Kategorie „Telefonie und Kommunikation > Rufgruppe und Weiterleitung“ zuzuordnen. Primär zuständig ist „Support und Telekommunikation“. Vor der endgültigen Zuweisung sind die genannten Ausschlusskriterien und Schnittstellen zu prüfen.

## Verknüpfungen

- [[Wiki/Categories/telefonie-und-kommunikation-rufgruppe-und-weiterleitung|Telefonie und Kommunikation > Rufgruppe und Weiterleitung]] — Kategorie
- Quelle: `kb://internal-kb/glpi-kategorien/telefonie-und-kommunikation/rufgruppe-und-weiterleitung`
