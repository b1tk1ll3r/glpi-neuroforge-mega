---
type: "knowledge"
title: "Wartungs- und Supportvertrag"
id: "KAT-WARTUNGS-UND-SUPPORTVERTRAG-SELECT"
source: "internal-category"
source_uri: "kb://internal-kb/glpi-kategorien/beschaffung-vertrage-und-lizenzen/wartungs-und-supportvertrag"
language: "de-DE"
communication_style: "formal"
created: "2026-08-05"
updated: "2026-08-05"
auto_reply: false
min_score: 0.7
tags:
  - "Beschaffung, Verträge und Lizenzen"
  - "Herstellersupport"
  - "Kündigung"
  - "Maintenance"
  - "Pflegevertrag"
  - "SLA"
  - "Supportvertrag"
  - "Verlängerung"
  - "Wartungs- und Supportvertrag"
  - "Wartungsvertrag"
categories:
  - "Beschaffung, Verträge und Lizenzen \u003e Wartungs- und Supportvertrag"
related:
  - "[[Wiki/Categories/beschaffung-vertraege-und-lizenzen-wartungs-und-supportvertrag|Beschaffung, Verträge und Lizenzen \u003e Wartungs- und Supportvertrag]]"
---

# Wartungs- und Supportvertrag

## Kontext / Problem

Auswahlziel: Beschaffung, Verträge und Lizenzen > Wartungs- und Supportvertrag. Primär zuständiges Team: Leitung und Finanzen / Beschaffung. Diese Kategorie ist auszuwählen, wenn Wartungs-, Pflege-, Hersteller- oder Supportverträge abgeschlossen, verlängert, angepasst, geprüft oder gekündigt werden sollen. Typische Ticketformulierungen sind: „Wartungsvertrag verlängern“; „Herstellersupport beauftragen“; „Pflegevertrag prüfen“; „Supportvertrag kündigen“. Nicht auswählen, wenn ein konkreter technischer Supportfall beim Hersteller eröffnet oder eine Rechnung ohne Vertragsänderung geprüft wird. Für die Klassifizierung sind der konkret betroffene Dienst oder Gegenstand, die Fehlermeldung, die Anzahl betroffener Personen, der Standort sowie die Unterscheidung zwischen Störung, Berechtigung, Bestellung und Änderungswunsch besonders wichtig. Einzelne unspezifische Wörter wie „geht nicht“, „Problem“ oder „dringend“ reichen ohne Sachbezug nicht für diese Zuordnung aus. Abgrenzungsregel: Leistungsumfang, Laufzeit, Kündigungsfrist und zuständiges Fachteam sind zu dokumentieren.

## Lösung / Antwort

Interne Klassifizierung: Das Ticket ist der Kategorie „Beschaffung, Verträge und Lizenzen > Wartungs- und Supportvertrag“ zuzuordnen. Primär zuständig ist „Leitung und Finanzen / Beschaffung“. Vor der endgültigen Zuweisung sind die genannten Ausschlusskriterien und Schnittstellen zu prüfen.

## Verknüpfungen

- [[Wiki/Categories/beschaffung-vertraege-und-lizenzen-wartungs-und-supportvertrag|Beschaffung, Verträge und Lizenzen > Wartungs- und Supportvertrag]] — Kategorie
- Quelle: `kb://internal-kb/glpi-kategorien/beschaffung-vertrage-und-lizenzen/wartungs-und-supportvertrag`
