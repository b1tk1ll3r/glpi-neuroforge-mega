---
type: "knowledge"
title: "Dienstliches Smartphone"
id: "KAT-DIENSTLICHES-SMARTPHONE-SELECT"
source: "internal-category"
source_uri: "kb://internal-kb/glpi-kategorien/telefonie-und-kommunikation/dienstliches-smartphone"
language: "de-DE"
communication_style: "formal"
created: "2026-08-05"
updated: "2026-08-05"
auto_reply: false
min_score: 0.7
tags:
  - "Diensthandy"
  - "Dienstliches Smartphone"
  - "Handytausch"
  - "Kontakte"
  - "Mobiltelefon"
  - "Smartphone einrichten"
  - "Telefon-App"
  - "Telefonie und Kommunikation"
categories:
  - "Telefonie und Kommunikation \u003e Dienstliches Smartphone"
related:
  - "[[Wiki/Categories/telefonie-und-kommunikation-dienstliches-smartphone|Telefonie und Kommunikation \u003e Dienstliches Smartphone]]"
---

# Dienstliches Smartphone

## Kontext / Problem

Auswahlziel: Telefonie und Kommunikation > Dienstliches Smartphone. Primär zuständiges Team: Support und Telekommunikation. Diese Kategorie ist auszuwählen, wenn ein dienstliches Smartphone als Telekommunikationsgerät neu eingerichtet, getauscht, repariert oder für Telefonie, Kontakte und dienstliche Kommunikation konfiguriert werden muss. Typische Ticketformulierungen sind: „Diensthandy einrichten“; „Smartphone austauschen“; „Kontakte synchronisieren“; „Telefon-App funktioniert nicht“. Nicht auswählen, wenn ausschließlich SIM, Tarif oder Roaming betroffen ist; wenn ein Tablet ohne Telefoniefunktion oder ein MFA-Token im Mittelpunkt steht. Für die Klassifizierung sind der konkret betroffene Dienst oder Gegenstand, die Fehlermeldung, die Anzahl betroffener Personen, der Standort sowie die Unterscheidung zwischen Störung, Berechtigung, Bestellung und Änderungswunsch besonders wichtig. Einzelne unspezifische Wörter wie „geht nicht“, „Problem“ oder „dringend“ reichen ohne Sachbezug nicht für diese Zuordnung aus. Abgrenzungsregel: Allgemeine mobile Endgeräteprobleme können zunächst beim Support bleiben; Mobilfunkvertrag und SIM sind separat.

## Lösung / Antwort

Interne Klassifizierung: Das Ticket ist der Kategorie „Telefonie und Kommunikation > Dienstliches Smartphone“ zuzuordnen. Primär zuständig ist „Support und Telekommunikation“. Vor der endgültigen Zuweisung sind die genannten Ausschlusskriterien und Schnittstellen zu prüfen.

## Verknüpfungen

- [[Wiki/Categories/telefonie-und-kommunikation-dienstliches-smartphone|Telefonie und Kommunikation > Dienstliches Smartphone]] — Kategorie
- Quelle: `kb://internal-kb/glpi-kategorien/telefonie-und-kommunikation/dienstliches-smartphone`
