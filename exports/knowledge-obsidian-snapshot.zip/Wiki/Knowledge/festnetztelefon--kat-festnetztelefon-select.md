---
type: "knowledge"
title: "Festnetztelefon"
id: "KAT-FESTNETZTELEFON-SELECT"
source: "internal-category"
source_uri: "kb://internal-kb/glpi-kategorien/telefonie-und-kommunikation/festnetztelefon"
language: "de-DE"
communication_style: "formal"
created: "2026-08-05"
updated: "2026-08-05"
auto_reply: false
min_score: 0.7
tags:
  - "Festnetz"
  - "Festnetztelefon"
  - "Hörer"
  - "Telefon"
  - "Telefon defekt"
  - "Telefonapparat"
  - "Telefonie und Kommunikation"
  - "Tischtelefon"
  - "Wählton"
  - "kein Ton"
categories:
  - "Telefonie und Kommunikation \u003e Festnetztelefon"
related:
  - "[[Wiki/Categories/telefonie-und-kommunikation-festnetztelefon|Telefonie und Kommunikation \u003e Festnetztelefon]]"
---

# Festnetztelefon

## Kontext / Problem

Auswahlziel: Telefonie und Kommunikation > Festnetztelefon. Primär zuständiges Team: Support und Telekommunikation. Diese Kategorie ist auszuwählen, wenn ein Tischtelefon oder Festnetzanschluss nicht klingelt, keine Gespräche ermöglicht, Tonprobleme zeigt, defekt ist oder lokal eingerichtet werden muss. Typische Ticketformulierungen sind: „Telefon hat keinen Wählton“; „Tischtelefon defekt“; „Anrufer nicht hörbar“; „Festnetztelefon startet nicht“. Nicht auswählen, wenn eine Rufnummer neu vergeben, eine Rufgruppe geändert oder ein Mobilfunkgerät betroffen ist. Für die Klassifizierung sind der konkret betroffene Dienst oder Gegenstand, die Fehlermeldung, die Anzahl betroffener Personen, der Standort sowie die Unterscheidung zwischen Störung, Berechtigung, Bestellung und Änderungswunsch besonders wichtig. Einzelne unspezifische Wörter wie „geht nicht“, „Problem“ oder „dringend“ reichen ohne Sachbezug nicht für diese Zuordnung aus. Abgrenzungsregel: Bei flächigem Telefonieausfall ist eine zentrale Störung zu prüfen und höher zu priorisieren.

## Lösung / Antwort

Interne Klassifizierung: Das Ticket ist der Kategorie „Telefonie und Kommunikation > Festnetztelefon“ zuzuordnen. Primär zuständig ist „Support und Telekommunikation“. Vor der endgültigen Zuweisung sind die genannten Ausschlusskriterien und Schnittstellen zu prüfen.

## Verknüpfungen

- [[Wiki/Categories/telefonie-und-kommunikation-festnetztelefon|Telefonie und Kommunikation > Festnetztelefon]] — Kategorie
- Quelle: `kb://internal-kb/glpi-kategorien/telefonie-und-kommunikation/festnetztelefon`
