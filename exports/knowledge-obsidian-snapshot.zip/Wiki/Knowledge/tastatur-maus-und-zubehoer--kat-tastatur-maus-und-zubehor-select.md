---
type: "knowledge"
title: "Tastatur, Maus und Zubehör"
id: "KAT-TASTATUR-MAUS-UND-ZUBEHOR-SELECT"
source: "internal-category"
source_uri: "kb://internal-kb/glpi-kategorien/arbeitsplatz-und-endgerate/tastatur-maus-und-zubehor"
language: "de-DE"
communication_style: "formal"
created: "2026-08-05"
updated: "2026-08-05"
auto_reply: false
min_score: 0.7
tags:
  - "Adapter"
  - "Arbeitsplatz und Endgeräte"
  - "Headset"
  - "Kabel"
  - "Maus"
  - "Netzteil"
  - "Peripherie"
  - "Tastatur"
  - "Tastatur, Maus und Zubehör"
  - "USB-Gerät"
  - "Webcam"
  - "Zubehör"
categories:
  - "Arbeitsplatz und Endgeräte \u003e Tastatur, Maus und Zubehör"
related:
  - "[[Wiki/Categories/arbeitsplatz-und-endgeraete-tastatur-maus-und-zubehoer|Arbeitsplatz und Endgeräte \u003e Tastatur, Maus und Zubehör]]"
---

# Tastatur, Maus und Zubehör

## Kontext / Problem

Auswahlziel: Arbeitsplatz und Endgeräte > Tastatur, Maus und Zubehör. Primär zuständiges Team: Support und Telekommunikation. Diese Kategorie ist auszuwählen, wenn Tastatur, Maus, Headset, Webcam, Netzteil, Adapter, Kabel oder sonstige Arbeitsplatzperipherie defekt, nicht erkannt oder nicht vorhanden ist. Typische Ticketformulierungen sind: „Maus reagiert nicht“; „Tastatur defekt“; „Webcam wird nicht erkannt“; „Headset ohne Ton“; „Netzteil fehlt“. Nicht auswählen, wenn ein komplettes Endgerät ausfällt, ein Telekommunikationsgerät betroffen ist oder eine Neubeschaffung außerhalb eines Ersatzfalls beantragt wird. Für die Klassifizierung sind der konkret betroffene Dienst oder Gegenstand, die Fehlermeldung, die Anzahl betroffener Personen, der Standort sowie die Unterscheidung zwischen Störung, Berechtigung, Bestellung und Änderungswunsch besonders wichtig. Einzelne unspezifische Wörter wie „geht nicht“, „Problem“ oder „dringend“ reichen ohne Sachbezug nicht für diese Zuordnung aus. Abgrenzungsregel: Einfache Ersatzteile bearbeitet der Support; kostenpflichtige Neubeschaffungen können an Beschaffung übergeben werden.

## Lösung / Antwort

Interne Klassifizierung: Das Ticket ist der Kategorie „Arbeitsplatz und Endgeräte > Tastatur, Maus und Zubehör“ zuzuordnen. Primär zuständig ist „Support und Telekommunikation“. Vor der endgültigen Zuweisung sind die genannten Ausschlusskriterien und Schnittstellen zu prüfen.

## Verknüpfungen

- [[Wiki/Categories/arbeitsplatz-und-endgeraete-tastatur-maus-und-zubehoer|Arbeitsplatz und Endgeräte > Tastatur, Maus und Zubehör]] — Kategorie
- Quelle: `kb://internal-kb/glpi-kategorien/arbeitsplatz-und-endgerate/tastatur-maus-und-zubehor`
