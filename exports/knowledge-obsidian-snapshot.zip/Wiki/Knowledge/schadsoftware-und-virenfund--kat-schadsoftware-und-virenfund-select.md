---
type: "knowledge"
title: "Schadsoftware und Virenfund"
id: "KAT-SCHADSOFTWARE-UND-VIRENFUND-SELECT"
source: "internal-category"
source_uri: "kb://internal-kb/glpi-kategorien/it-sicherheit-und-datensicherung/schadsoftware-und-virenfund"
language: "de-DE"
communication_style: "formal"
created: "2026-08-05"
updated: "2026-08-05"
auto_reply: false
min_score: 0.7
tags:
  - "EDR"
  - "IT-Sicherheit und Datensicherung"
  - "Malware"
  - "Quarantäne"
  - "Ransomware"
  - "Schadsoftware"
  - "Schadsoftware und Virenfund"
  - "Trojaner"
  - "Virenfund"
  - "Virus"
  - "infiziert"
categories:
  - "IT-Sicherheit und Datensicherung \u003e Schadsoftware und Virenfund"
related:
  - "[[Wiki/Categories/it-sicherheit-und-datensicherung-schadsoftware-und-virenfund|IT-Sicherheit und Datensicherung \u003e Schadsoftware und Virenfund]]"
---

# Schadsoftware und Virenfund

## Kontext / Problem

Auswahlziel: IT-Sicherheit und Datensicherung > Schadsoftware und Virenfund. Primär zuständiges Team: Infrastruktur und Backend. Diese Kategorie ist auszuwählen, wenn Virenscanner, EDR oder ein anderes Schutzsystem Malware, Trojaner, Ransomware, unerwünschte Software oder eine verdächtige Datei auf einem Gerät meldet. Typische Ticketformulierungen sind: „Virenscanner meldet Trojaner“; „Datei in Quarantäne“; „Ransomware-Verdacht“; „Malware-Fund auf Notebook“. Nicht auswählen, wenn lediglich ein Virenscanner-Update fehlt, eine allgemeine Schwachstelle bekannt ist oder nur eine verdächtige E-Mail noch nicht geöffnet wurde. Für die Klassifizierung sind der konkret betroffene Dienst oder Gegenstand, die Fehlermeldung, die Anzahl betroffener Personen, der Standort sowie die Unterscheidung zwischen Störung, Berechtigung, Bestellung und Änderungswunsch besonders wichtig. Einzelne unspezifische Wörter wie „geht nicht“, „Problem“ oder „dringend“ reichen ohne Sachbezug nicht für diese Zuordnung aus. Abgrenzungsregel: Betroffene Geräte nicht weiter verwenden und nicht eigenständig bereinigen; bei möglicher Ausbreitung als Sicherheitsvorfall eskalieren.

## Lösung / Antwort

Interne Klassifizierung: Das Ticket ist der Kategorie „IT-Sicherheit und Datensicherung > Schadsoftware und Virenfund“ zuzuordnen. Primär zuständig ist „Infrastruktur und Backend“. Vor der endgültigen Zuweisung sind die genannten Ausschlusskriterien und Schnittstellen zu prüfen.

## Verknüpfungen

- [[Wiki/Categories/it-sicherheit-und-datensicherung-schadsoftware-und-virenfund|IT-Sicherheit und Datensicherung > Schadsoftware und Virenfund]] — Kategorie
- Quelle: `kb://internal-kb/glpi-kategorien/it-sicherheit-und-datensicherung/schadsoftware-und-virenfund`
