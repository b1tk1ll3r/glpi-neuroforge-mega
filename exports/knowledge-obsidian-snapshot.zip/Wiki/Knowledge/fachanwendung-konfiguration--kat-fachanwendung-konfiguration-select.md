---
type: "knowledge"
title: "Fachanwendung – Konfiguration"
id: "KAT-FACHANWENDUNG-KONFIGURATION-SELECT"
source: "internal-category"
source_uri: "kb://internal-kb/glpi-kategorien/fachanwendungen-und-microsoft-office/fachanwendung-konfiguration"
language: "de-DE"
communication_style: "formal"
created: "2026-08-05"
updated: "2026-08-05"
auto_reply: false
min_score: 0.7
tags:
  - "Einstellung Fachanwendung"
  - "Fachanwendung – Konfiguration"
  - "Fachanwendungen und Microsoft Office"
  - "Konfiguration"
  - "Maske anpassen"
  - "Nummernkreis"
  - "Parameter"
  - "Stammdaten"
  - "Vorlage"
  - "Workflow"
categories:
  - "Fachanwendungen und Microsoft Office \u003e Fachanwendung – Konfiguration"
related:
  - "[[Wiki/Categories/fachanwendungen-und-microsoft-office-fachanwendung-konfiguration|Fachanwendungen und Microsoft Office \u003e Fachanwendung – Konfiguration]]"
---

# Fachanwendung – Konfiguration

## Kontext / Problem

Auswahlziel: Fachanwendungen und Microsoft Office > Fachanwendung – Konfiguration. Primär zuständiges Team: Fachanwendungen. Diese Kategorie ist auszuwählen, wenn Parameter, Vorlagen, Masken, Stammdaten, Nummernkreise, Workflows oder organisatorische Einstellungen einer Fachanwendung angepasst werden sollen. Typische Ticketformulierungen sind: „Neue Vorlage hinterlegen“; „Workflow anpassen“; „Stammdaten konfigurieren“; „Nummernkreis ändern“. Nicht auswählen, wenn nur ein einzelner Benutzer eine lokale Einstellung benötigt, eine neue umfangreiche Funktion gefordert wird oder die technische Serverplattform geändert werden muss. Für die Klassifizierung sind der konkret betroffene Dienst oder Gegenstand, die Fehlermeldung, die Anzahl betroffener Personen, der Standort sowie die Unterscheidung zwischen Störung, Berechtigung, Bestellung und Änderungswunsch besonders wichtig. Einzelne unspezifische Wörter wie „geht nicht“, „Problem“ oder „dringend“ reichen ohne Sachbezug nicht für diese Zuordnung aus. Abgrenzungsregel: Größere funktionale Erweiterungen gehören zu Neue Anforderung; technische Plattformparameter zu Infrastruktur und Backend.

## Lösung / Antwort

Interne Klassifizierung: Das Ticket ist der Kategorie „Fachanwendungen und Microsoft Office > Fachanwendung – Konfiguration“ zuzuordnen. Primär zuständig ist „Fachanwendungen“. Vor der endgültigen Zuweisung sind die genannten Ausschlusskriterien und Schnittstellen zu prüfen.

## Verknüpfungen

- [[Wiki/Categories/fachanwendungen-und-microsoft-office-fachanwendung-konfiguration|Fachanwendungen und Microsoft Office > Fachanwendung – Konfiguration]] — Kategorie
- Quelle: `kb://internal-kb/glpi-kategorien/fachanwendungen-und-microsoft-office/fachanwendung-konfiguration`
