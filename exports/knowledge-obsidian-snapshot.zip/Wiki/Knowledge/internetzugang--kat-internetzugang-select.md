---
type: "knowledge"
title: "Internetzugang"
id: "KAT-INTERNETZUGANG-SELECT"
source: "internal-category"
source_uri: "kb://internal-kb/glpi-kategorien/netzwerk-und-verbindungen/internetzugang"
language: "de-DE"
communication_style: "formal"
created: "2026-08-05"
updated: "2026-08-05"
auto_reply: false
min_score: 0.7
tags:
  - "Internet"
  - "Internetausfall"
  - "Internetzugang"
  - "Netzwerk und Verbindungen"
  - "Provider"
  - "WAN"
  - "Webseiten nicht erreichbar"
  - "langsam"
  - "offline"
categories:
  - "Netzwerk und Verbindungen \u003e Internetzugang"
related:
  - "[[Wiki/Categories/netzwerk-und-verbindungen-internetzugang|Netzwerk und Verbindungen \u003e Internetzugang]]"
---

# Internetzugang

## Kontext / Problem

Auswahlziel: Netzwerk und Verbindungen > Internetzugang. Primär zuständiges Team: Infrastruktur und Backend. Diese Kategorie ist auszuwählen, wenn Webseiten oder externe Dienste allgemein nicht erreichbar sind, der Internetzugang eines Standorts oder mehrerer Benutzer ausfällt oder auffällig langsam ist. Typische Ticketformulierungen sind: „Kein Internet im Gebäude“; „Externe Webseiten nicht erreichbar“; „Internetzugang sehr langsam“; „Mehrere Nutzer offline“. Nicht auswählen, wenn nur eine einzelne Anwendung gestört ist, ein VPN-Tunnel nicht verbindet oder eine konkrete Adresse durch die Firewall freigeschaltet werden soll. Für die Klassifizierung sind der konkret betroffene Dienst oder Gegenstand, die Fehlermeldung, die Anzahl betroffener Personen, der Standort sowie die Unterscheidung zwischen Störung, Berechtigung, Bestellung und Änderungswunsch besonders wichtig. Einzelne unspezifische Wörter wie „geht nicht“, „Problem“ oder „dringend“ reichen ohne Sachbezug nicht für diese Zuordnung aus. Abgrenzungsregel: Einzelne blockierte Ziele können eine Firewall-Thematik sein; flächige Ausfälle sind zu priorisieren.

## Lösung / Antwort

Interne Klassifizierung: Das Ticket ist der Kategorie „Netzwerk und Verbindungen > Internetzugang“ zuzuordnen. Primär zuständig ist „Infrastruktur und Backend“. Vor der endgültigen Zuweisung sind die genannten Ausschlusskriterien und Schnittstellen zu prüfen.

## Verknüpfungen

- [[Wiki/Categories/netzwerk-und-verbindungen-internetzugang|Netzwerk und Verbindungen > Internetzugang]] — Kategorie
- Quelle: `kb://internal-kb/glpi-kategorien/netzwerk-und-verbindungen/internetzugang`
