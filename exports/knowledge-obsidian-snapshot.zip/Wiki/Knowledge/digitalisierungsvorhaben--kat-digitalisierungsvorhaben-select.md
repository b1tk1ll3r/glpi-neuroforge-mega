---
type: "knowledge"
title: "Digitalisierungsvorhaben"
id: "KAT-DIGITALISIERUNGSVORHABEN-SELECT"
source: "internal-category"
source_uri: "kb://internal-kb/glpi-kategorien/projekte-anderungen-und-neue-anforderungen/digitalisierungsvorhaben"
language: "de-DE"
communication_style: "formal"
created: "2026-08-05"
updated: "2026-08-05"
auto_reply: false
min_score: 0.7
tags:
  - "Digitalisierungsvorhaben"
  - "E-Government"
  - "Online-Antrag"
  - "Projekte, Änderungen und neue Anforderungen"
  - "Prozessdigitalisierung"
  - "Workflow"
  - "digitaler Prozess"
  - "medienbruchfrei"
categories:
  - "Projekte, Änderungen und neue Anforderungen \u003e Digitalisierungsvorhaben"
related:
  - "[[Wiki/Categories/projekte-aenderungen-und-neue-anforderungen-digitalisierungsvorhaben|Projekte, Änderungen und neue Anforderungen \u003e Digitalisierungsvorhaben]]"
---

# Digitalisierungsvorhaben

## Kontext / Problem

Auswahlziel: Projekte, Änderungen und neue Anforderungen > Digitalisierungsvorhaben. Primär zuständiges Team: Leitung und Finanzen / Beschaffung. Diese Kategorie ist auszuwählen, wenn ein Verwaltungsprozess grundlegend digitalisiert, medienbruchfrei gestaltet oder durch mehrere IT-Komponenten neu unterstützt werden soll. Typische Ticketformulierungen sind: „Papierprozess digitalisieren“; „Digitalen Antrag einführen“; „Medienbruch beseitigen“; „End-to-End-Prozess neu gestalten“. Nicht auswählen, wenn lediglich eine kleine Funktion in einer bestehenden Anwendung ergänzt oder ein einzelnes Gerät beschafft wird. Für die Klassifizierung sind der konkret betroffene Dienst oder Gegenstand, die Fehlermeldung, die Anzahl betroffener Personen, der Standort sowie die Unterscheidung zwischen Störung, Berechtigung, Bestellung und Änderungswunsch besonders wichtig. Einzelne unspezifische Wörter wie „geht nicht“, „Problem“ oder „dringend“ reichen ohne Sachbezug nicht für diese Zuordnung aus. Abgrenzungsregel: Fachanwendungen übernimmt fachnahe Umsetzung; Leitung priorisiert und koordiniert organisationsübergreifend.

## Lösung / Antwort

Interne Klassifizierung: Das Ticket ist der Kategorie „Projekte, Änderungen und neue Anforderungen > Digitalisierungsvorhaben“ zuzuordnen. Primär zuständig ist „Leitung und Finanzen / Beschaffung“. Vor der endgültigen Zuweisung sind die genannten Ausschlusskriterien und Schnittstellen zu prüfen.

## Verknüpfungen

- [[Wiki/Categories/projekte-aenderungen-und-neue-anforderungen-digitalisierungsvorhaben|Projekte, Änderungen und neue Anforderungen > Digitalisierungsvorhaben]] — Kategorie
- Quelle: `kb://internal-kb/glpi-kategorien/projekte-anderungen-und-neue-anforderungen/digitalisierungsvorhaben`
