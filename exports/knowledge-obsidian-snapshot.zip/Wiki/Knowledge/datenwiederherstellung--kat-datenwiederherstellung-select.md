---
type: "knowledge"
title: "Datenwiederherstellung"
id: "KAT-DATENWIEDERHERSTELLUNG-SELECT"
source: "internal-category"
source_uri: "kb://internal-kb/glpi-kategorien/it-sicherheit-und-datensicherung/datenwiederherstellung"
language: "de-DE"
communication_style: "formal"
created: "2026-08-05"
updated: "2026-08-05"
auto_reply: false
min_score: 0.7
tags:
  - "Backup einspielen"
  - "Datei zurückholen"
  - "Daten verloren"
  - "Datenwiederherstellung"
  - "IT-Sicherheit und Datensicherung"
  - "Point-in-Time"
  - "Recovery"
  - "Restore"
  - "Wiederherstellung"
  - "gelöscht"
categories:
  - "IT-Sicherheit und Datensicherung \u003e Datenwiederherstellung"
related:
  - "[[Wiki/Categories/it-sicherheit-und-datensicherung-datenwiederherstellung|IT-Sicherheit und Datensicherung \u003e Datenwiederherstellung]]"
---

# Datenwiederherstellung

## Kontext / Problem

Auswahlziel: IT-Sicherheit und Datensicherung > Datenwiederherstellung. Primär zuständiges Team: Infrastruktur und Backend. Diese Kategorie ist auszuwählen, wenn gelöschte, beschädigte oder verlorene Dateien, Verzeichnisse, Datenbanken, virtuelle Maschinen oder Systeme aus einer vorhandenen Sicherung wiederhergestellt werden sollen. Typische Ticketformulierungen sind: „Gelöschten Ordner wiederherstellen“; „Datei aus Backup zurückholen“; „VM-Restore“; „Datenbank auf Zeitpunkt zurücksetzen“. Nicht auswählen, wenn nur geprüft werden soll, ob Sicherungen laufen, oder wenn die Daten fachlich innerhalb einer Anwendung korrigiert werden müssen. Für die Klassifizierung sind der konkret betroffene Dienst oder Gegenstand, die Fehlermeldung, die Anzahl betroffener Personen, der Standort sowie die Unterscheidung zwischen Störung, Berechtigung, Bestellung und Änderungswunsch besonders wichtig. Einzelne unspezifische Wörter wie „geht nicht“, „Problem“ oder „dringend“ reichen ohne Sachbezug nicht für diese Zuordnung aus. Abgrenzungsregel: Betroffenes Objekt, Pfad, gewünschter Zeitpunkt und Dringlichkeit müssen möglichst genau angegeben werden.

## Lösung / Antwort

Interne Klassifizierung: Das Ticket ist der Kategorie „IT-Sicherheit und Datensicherung > Datenwiederherstellung“ zuzuordnen. Primär zuständig ist „Infrastruktur und Backend“. Vor der endgültigen Zuweisung sind die genannten Ausschlusskriterien und Schnittstellen zu prüfen.

## Verknüpfungen

- [[Wiki/Categories/it-sicherheit-und-datensicherung-datenwiederherstellung|IT-Sicherheit und Datensicherung > Datenwiederherstellung]] — Kategorie
- Quelle: `kb://internal-kb/glpi-kategorien/it-sicherheit-und-datensicherung/datenwiederherstellung`
