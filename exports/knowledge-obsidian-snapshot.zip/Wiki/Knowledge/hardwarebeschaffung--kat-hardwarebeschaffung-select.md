---
type: "knowledge"
title: "Hardwarebeschaffung"
id: "KAT-HARDWAREBESCHAFFUNG-SELECT"
source: "internal-category"
source_uri: "kb://internal-kb/glpi-kategorien/beschaffung-vertrage-und-lizenzen/hardwarebeschaffung"
language: "de-DE"
communication_style: "formal"
created: "2026-08-05"
updated: "2026-08-05"
auto_reply: false
min_score: 0.7
tags:
  - "Angebot"
  - "Beschaffung, Verträge und Lizenzen"
  - "Geräte bestellen"
  - "Hardware bestellen"
  - "Hardwarebeschaffung"
  - "Investition"
  - "Kauf"
  - "Server kaufen"
  - "Switch beschaffen"
categories:
  - "Beschaffung, Verträge und Lizenzen \u003e Hardwarebeschaffung"
related:
  - "[[Wiki/Categories/beschaffung-vertraege-und-lizenzen-hardwarebeschaffung|Beschaffung, Verträge und Lizenzen \u003e Hardwarebeschaffung]]"
---

# Hardwarebeschaffung

## Kontext / Problem

Auswahlziel: Beschaffung, Verträge und Lizenzen > Hardwarebeschaffung. Primär zuständiges Team: Leitung und Finanzen / Beschaffung. Diese Kategorie ist auszuwählen, wenn Hardware außerhalb eines einfachen Support-Ersatzes beschafft werden soll, etwa Server, Netzwerkkomponenten, Arbeitsplatzgeräte, Spezialhardware oder größere Stückzahlen. Typische Ticketformulierungen sind: „Serverhardware bestellen“; „Switches beschaffen“; „Spezialscanner kaufen“; „Rahmenbestellung für Notebooks“. Nicht auswählen, wenn ein vorhandenes Gerät nur repariert, umgesetzt oder zurückgegeben wird; für konkrete Arbeitsplatz-Neubeschaffung kann auch die spezialisierte Kategorie unter Arbeitsplatz genutzt werden. Für die Klassifizierung sind der konkret betroffene Dienst oder Gegenstand, die Fehlermeldung, die Anzahl betroffener Personen, der Standort sowie die Unterscheidung zwischen Störung, Berechtigung, Bestellung und Änderungswunsch besonders wichtig. Einzelne unspezifische Wörter wie „geht nicht“, „Problem“ oder „dringend“ reichen ohne Sachbezug nicht für diese Zuordnung aus. Abgrenzungsregel: Das jeweilige Fachteam liefert Spezifikation und Bedarf; Beschaffung führt kaufmännischen Prozess.

## Lösung / Antwort

Interne Klassifizierung: Das Ticket ist der Kategorie „Beschaffung, Verträge und Lizenzen > Hardwarebeschaffung“ zuzuordnen. Primär zuständig ist „Leitung und Finanzen / Beschaffung“. Vor der endgültigen Zuweisung sind die genannten Ausschlusskriterien und Schnittstellen zu prüfen.

## Verknüpfungen

- [[Wiki/Categories/beschaffung-vertraege-und-lizenzen-hardwarebeschaffung|Beschaffung, Verträge und Lizenzen > Hardwarebeschaffung]] — Kategorie
- Quelle: `kb://internal-kb/glpi-kategorien/beschaffung-vertrage-und-lizenzen/hardwarebeschaffung`
