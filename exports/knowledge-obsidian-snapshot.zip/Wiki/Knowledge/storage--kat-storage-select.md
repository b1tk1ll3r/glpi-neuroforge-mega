---
type: "knowledge"
title: "Storage"
id: "KAT-STORAGE-SELECT"
source: "internal-category"
source_uri: "kb://internal-kb/glpi-kategorien/server-backend-und-plattformen/storage"
language: "de-DE"
communication_style: "formal"
created: "2026-08-05"
updated: "2026-08-05"
auto_reply: false
min_score: 0.7
tags:
  - "IOPS"
  - "Kapazität"
  - "LUN"
  - "NAS"
  - "SAN"
  - "Server, Backend und Plattformen"
  - "Speicherarray"
  - "Speicherplattform"
  - "Storage"
  - "Volume"
categories:
  - "Server, Backend und Plattformen \u003e Storage"
related:
  - "[[Wiki/Categories/server-backend-und-plattformen-storage|Server, Backend und Plattformen \u003e Storage]]"
---

# Storage

## Kontext / Problem

Auswahlziel: Server, Backend und Plattformen > Storage. Primär zuständiges Team: Infrastruktur und Backend. Diese Kategorie ist auszuwählen, wenn zentrale Speicherplattformen, SAN, NAS, Volumes, LUNs, Kapazitäten, Performance oder Storage-Replikation betroffen sind. Typische Ticketformulierungen sind: „Storage-Kapazität erweitern“; „SAN meldet Fehler“; „Volume nicht verfügbar“; „Speicherperformance schlecht“. Nicht auswählen, wenn nur eine Dateifreigabe, eine lokale Festplatte oder der Speicherplatz einer einzelnen Anwendung betroffen ist. Für die Klassifizierung sind der konkret betroffene Dienst oder Gegenstand, die Fehlermeldung, die Anzahl betroffener Personen, der Standort sowie die Unterscheidung zwischen Störung, Berechtigung, Bestellung und Änderungswunsch besonders wichtig. Einzelne unspezifische Wörter wie „geht nicht“, „Problem“ oder „dringend“ reichen ohne Sachbezug nicht für diese Zuordnung aus. Abgrenzungsregel: Dateidienste und virtuelle Maschinen können Folgeprobleme zeigen, die Ursache bleibt jedoch Storage.

## Lösung / Antwort

Interne Klassifizierung: Das Ticket ist der Kategorie „Server, Backend und Plattformen > Storage“ zuzuordnen. Primär zuständig ist „Infrastruktur und Backend“. Vor der endgültigen Zuweisung sind die genannten Ausschlusskriterien und Schnittstellen zu prüfen.

## Verknüpfungen

- [[Wiki/Categories/server-backend-und-plattformen-storage|Server, Backend und Plattformen > Storage]] — Kategorie
- Quelle: `kb://internal-kb/glpi-kategorien/server-backend-und-plattformen/storage`
