---
type: "knowledge"
title: "Virenschutz"
id: "KAT-VIRENSCHUTZ-SELECT"
source: "internal-category"
source_uri: "kb://internal-kb/glpi-kategorien/it-sicherheit-und-datensicherung/virenschutz"
language: "de-DE"
communication_style: "formal"
created: "2026-08-05"
updated: "2026-08-05"
auto_reply: false
min_score: 0.7
tags:
  - "Agent"
  - "Antivirus"
  - "Ausnahme"
  - "Defender"
  - "EDR"
  - "IT-Sicherheit und Datensicherung"
  - "Quarantäne"
  - "Schutzstatus"
  - "Signatur"
  - "Virenscanner"
  - "Virenschutz"
categories:
  - "IT-Sicherheit und Datensicherung \u003e Virenschutz"
related:
  - "[[Wiki/Categories/it-sicherheit-und-datensicherung-virenschutz|IT-Sicherheit und Datensicherung \u003e Virenschutz]]"
---

# Virenschutz

## Kontext / Problem

Auswahlziel: IT-Sicherheit und Datensicherung > Virenschutz. Primär zuständiges Team: Infrastruktur und Backend. Diese Kategorie ist auszuwählen, wenn Virenscanner oder EDR-Agent nicht läuft, Signaturen veraltet sind, Richtlinien nicht greifen, ein Agent fehlt oder Quarantäne- und Ausnahmeregeln administriert werden müssen. Typische Ticketformulierungen sind: „Virenscanner nicht aktiv“; „Signaturen veraltet“; „EDR-Agent offline“; „Ausnahme prüfen“; „Quarantäne verwalten“. Nicht auswählen, wenn bereits Malware gefunden wurde oder ein allgemeines Betriebssystemupdate betroffen ist. Für die Klassifizierung sind der konkret betroffene Dienst oder Gegenstand, die Fehlermeldung, die Anzahl betroffener Personen, der Standort sowie die Unterscheidung zwischen Störung, Berechtigung, Bestellung und Änderungswunsch besonders wichtig. Einzelne unspezifische Wörter wie „geht nicht“, „Problem“ oder „dringend“ reichen ohne Sachbezug nicht für diese Zuordnung aus. Abgrenzungsregel: Ein konkreter Schadsoftwarefund wird unter Schadsoftware und Virenfund klassifiziert.

## Lösung / Antwort

Interne Klassifizierung: Das Ticket ist der Kategorie „IT-Sicherheit und Datensicherung > Virenschutz“ zuzuordnen. Primär zuständig ist „Infrastruktur und Backend“. Vor der endgültigen Zuweisung sind die genannten Ausschlusskriterien und Schnittstellen zu prüfen.

## Verknüpfungen

- [[Wiki/Categories/it-sicherheit-und-datensicherung-virenschutz|IT-Sicherheit und Datensicherung > Virenschutz]] — Kategorie
- Quelle: `kb://internal-kb/glpi-kategorien/it-sicherheit-und-datensicherung/virenschutz`
