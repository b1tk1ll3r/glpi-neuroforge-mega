---
type: "knowledge"
title: "Sicherheitsvorfall"
id: "KAT-SICHERHEITSVORFALL-SELECT"
source: "internal-category"
source_uri: "kb://internal-kb/glpi-kategorien/it-sicherheit-und-datensicherung/sicherheitsvorfall"
language: "de-DE"
communication_style: "formal"
created: "2026-08-05"
updated: "2026-08-05"
auto_reply: false
min_score: 0.7
tags:
  - "Account übernommen"
  - "Cyberangriff"
  - "Datenabfluss"
  - "Datenverlust"
  - "IT-Sicherheit und Datensicherung"
  - "Incident"
  - "Security Breach"
  - "Sicherheitsvorfall"
  - "kompromittiert"
  - "unbefugter Zugriff"
categories:
  - "IT-Sicherheit und Datensicherung \u003e Sicherheitsvorfall"
related:
  - "[[Wiki/Categories/it-sicherheit-und-datensicherung-sicherheitsvorfall|IT-Sicherheit und Datensicherung \u003e Sicherheitsvorfall]]"
---

# Sicherheitsvorfall

## Kontext / Problem

Auswahlziel: IT-Sicherheit und Datensicherung > Sicherheitsvorfall. Primär zuständiges Team: Infrastruktur und Backend. Diese Kategorie ist auszuwählen, wenn ein tatsächlicher oder ernsthaft vermuteter unbefugter Zugriff, Datenabfluss, kompromittiertes Konto, Verlust sensibler Daten, aktive Attacke oder erhebliche Sicherheitsverletzung vorliegt. Typische Ticketformulierungen sind: „Konto möglicherweise übernommen“; „Unbefugter Zugriff festgestellt“; „Daten an falschen Empfänger“; „Aktiver Angriff“; „Dienstgerät mit sensiblen Daten verloren“. Nicht auswählen, wenn nur eine allgemeine Sicherheitsfrage, Schwachstellenmeldung ohne Ausnutzung oder verdächtige E-Mail ohne Interaktion vorliegt. Für die Klassifizierung sind der konkret betroffene Dienst oder Gegenstand, die Fehlermeldung, die Anzahl betroffener Personen, der Standort sowie die Unterscheidung zwischen Störung, Berechtigung, Bestellung und Änderungswunsch besonders wichtig. Einzelne unspezifische Wörter wie „geht nicht“, „Problem“ oder „dringend“ reichen ohne Sachbezug nicht für diese Zuordnung aus. Abgrenzungsregel: Unmittelbar priorisieren und Leitung sowie erforderliche Datenschutz-/Informationssicherheitsstellen nach internen Meldewegen beteiligen.

## Lösung / Antwort

Interne Klassifizierung: Das Ticket ist der Kategorie „IT-Sicherheit und Datensicherung > Sicherheitsvorfall“ zuzuordnen. Primär zuständig ist „Infrastruktur und Backend“. Vor der endgültigen Zuweisung sind die genannten Ausschlusskriterien und Schnittstellen zu prüfen.

## Verknüpfungen

- [[Wiki/Categories/it-sicherheit-und-datensicherung-sicherheitsvorfall|IT-Sicherheit und Datensicherung > Sicherheitsvorfall]] — Kategorie
- Quelle: `kb://internal-kb/glpi-kategorien/it-sicherheit-und-datensicherung/sicherheitsvorfall`
