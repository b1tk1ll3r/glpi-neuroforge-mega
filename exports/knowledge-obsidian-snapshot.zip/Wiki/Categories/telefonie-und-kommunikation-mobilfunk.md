---
type: "entity"
entity_type: "category"
title: "Telefonie und Kommunikation \u003e Mobilfunk"
created: "2026-08-25"
updated: "2026-08-25"
---

# Telefonie und Kommunikation > Mobilfunk

Kategorie der GLPI/NeuroForge-Wissensbasis.
