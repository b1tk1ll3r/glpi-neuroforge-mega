---
type: "entity"
entity_type: "category"
title: "Schulspezifische IT-Systeme \u003e Prüfungs- und Klausursysteme"
created: "2026-08-25"
updated: "2026-08-25"
---

# Schulspezifische IT-Systeme > Prüfungs- und Klausursysteme

Kategorie der GLPI/NeuroForge-Wissensbasis.
