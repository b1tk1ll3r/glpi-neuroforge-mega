---
type: "entity"
entity_type: "category"
title: "Fachanwendungen und Microsoft Office \u003e Office-Add-ins und Makros"
created: "2026-08-25"
updated: "2026-08-25"
---

# Fachanwendungen und Microsoft Office > Office-Add-ins und Makros

Kategorie der GLPI/NeuroForge-Wissensbasis.
