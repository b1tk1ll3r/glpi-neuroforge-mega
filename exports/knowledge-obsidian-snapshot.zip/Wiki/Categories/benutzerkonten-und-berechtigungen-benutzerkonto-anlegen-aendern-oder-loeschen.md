---
type: "entity"
entity_type: "category"
title: "Benutzerkonten und Berechtigungen \u003e Benutzerkonto anlegen, ändern oder löschen"
created: "2026-08-25"
updated: "2026-08-25"
---

# Benutzerkonten und Berechtigungen > Benutzerkonto anlegen, ändern oder löschen

Kategorie der GLPI/NeuroForge-Wissensbasis.
