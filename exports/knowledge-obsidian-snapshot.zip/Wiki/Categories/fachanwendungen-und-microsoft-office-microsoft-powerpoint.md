---
type: "entity"
entity_type: "category"
title: "Fachanwendungen und Microsoft Office \u003e Microsoft PowerPoint"
created: "2026-08-25"
updated: "2026-08-25"
---

# Fachanwendungen und Microsoft Office > Microsoft PowerPoint

Kategorie der GLPI/NeuroForge-Wissensbasis.
