---
type: "entity"
entity_type: "category"
title: "Benutzerkonten und Berechtigungen \u003e AD-Gruppen und Gruppenrichtlinien"
created: "2026-08-25"
updated: "2026-08-25"
---

# Benutzerkonten und Berechtigungen > AD-Gruppen und Gruppenrichtlinien

Kategorie der GLPI/NeuroForge-Wissensbasis.
