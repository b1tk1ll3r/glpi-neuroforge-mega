---
type: "entity"
entity_type: "category"
title: "Arbeitsplatz und Endgeräte \u003e Monitor und Dockingstation"
created: "2026-08-25"
updated: "2026-08-25"
---

# Arbeitsplatz und Endgeräte > Monitor und Dockingstation

Kategorie der GLPI/NeuroForge-Wissensbasis.
