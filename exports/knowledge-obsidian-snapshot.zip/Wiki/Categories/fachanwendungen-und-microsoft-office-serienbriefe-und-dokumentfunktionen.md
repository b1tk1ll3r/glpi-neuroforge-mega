---
type: "entity"
entity_type: "category"
title: "Fachanwendungen und Microsoft Office \u003e Serienbriefe und Dokumentfunktionen"
created: "2026-08-25"
updated: "2026-08-25"
---

# Fachanwendungen und Microsoft Office > Serienbriefe und Dokumentfunktionen

Kategorie der GLPI/NeuroForge-Wissensbasis.
