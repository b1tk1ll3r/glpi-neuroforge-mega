---
type: "entity"
entity_type: "category"
title: "IT-Sicherheit und Datensicherung \u003e Schadsoftware und Virenfund"
created: "2026-08-25"
updated: "2026-08-25"
---

# IT-Sicherheit und Datensicherung > Schadsoftware und Virenfund

Kategorie der GLPI/NeuroForge-Wissensbasis.
