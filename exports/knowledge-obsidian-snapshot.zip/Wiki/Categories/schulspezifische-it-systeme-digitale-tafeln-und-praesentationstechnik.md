---
type: "entity"
entity_type: "category"
title: "Schulspezifische IT-Systeme \u003e Digitale Tafeln und Präsentationstechnik"
created: "2026-08-25"
updated: "2026-08-25"
---

# Schulspezifische IT-Systeme > Digitale Tafeln und Präsentationstechnik

Kategorie der GLPI/NeuroForge-Wissensbasis.
