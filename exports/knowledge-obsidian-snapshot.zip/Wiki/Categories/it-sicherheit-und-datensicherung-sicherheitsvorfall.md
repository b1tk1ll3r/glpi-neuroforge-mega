---
type: "entity"
entity_type: "category"
title: "IT-Sicherheit und Datensicherung \u003e Sicherheitsvorfall"
created: "2026-08-25"
updated: "2026-08-25"
---

# IT-Sicherheit und Datensicherung > Sicherheitsvorfall

Kategorie der GLPI/NeuroForge-Wissensbasis.
