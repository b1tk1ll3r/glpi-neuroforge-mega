---
type: "entity"
entity_type: "category"
title: "Arbeitsplatz und Endgeräte \u003e Rückgabe und Aussonderung"
created: "2026-08-25"
updated: "2026-08-25"
---

# Arbeitsplatz und Endgeräte > Rückgabe und Aussonderung

Kategorie der GLPI/NeuroForge-Wissensbasis.
