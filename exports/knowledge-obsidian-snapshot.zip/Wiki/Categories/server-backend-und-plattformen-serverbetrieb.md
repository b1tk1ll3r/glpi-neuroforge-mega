---
type: "entity"
entity_type: "category"
title: "Server, Backend und Plattformen \u003e Serverbetrieb"
created: "2026-08-25"
updated: "2026-08-25"
---

# Server, Backend und Plattformen > Serverbetrieb

Kategorie der GLPI/NeuroForge-Wissensbasis.
