---
type: "entity"
entity_type: "category"
title: "IT-Sicherheit und Datensicherung \u003e Verdächtige E-Mail und Phishing"
created: "2026-08-25"
updated: "2026-08-25"
---

# IT-Sicherheit und Datensicherung > Verdächtige E-Mail und Phishing

Kategorie der GLPI/NeuroForge-Wissensbasis.
