---
type: "entity"
entity_type: "category"
title: "Fachanwendungen und Microsoft Office \u003e Fachanwendung – Störung"
created: "2026-08-25"
updated: "2026-08-25"
---

# Fachanwendungen und Microsoft Office > Fachanwendung – Störung

Kategorie der GLPI/NeuroForge-Wissensbasis.
