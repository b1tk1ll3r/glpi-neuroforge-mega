---
type: "entity"
entity_type: "category"
title: "Arbeitsplatz und Endgeräte \u003e Gerätewechsel und Umzug"
created: "2026-08-25"
updated: "2026-08-25"
---

# Arbeitsplatz und Endgeräte > Gerätewechsel und Umzug

Kategorie der GLPI/NeuroForge-Wissensbasis.
