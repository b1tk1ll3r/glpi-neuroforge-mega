---
type: "entity"
entity_type: "category"
title: "Fachanwendungen und Microsoft Office \u003e Fachanwendung – Neue Anforderung"
created: "2026-08-25"
updated: "2026-08-25"
---

# Fachanwendungen und Microsoft Office > Fachanwendung – Neue Anforderung

Kategorie der GLPI/NeuroForge-Wissensbasis.
