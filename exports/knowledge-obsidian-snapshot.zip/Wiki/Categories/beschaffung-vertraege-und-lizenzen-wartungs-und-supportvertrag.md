---
type: "entity"
entity_type: "category"
title: "Beschaffung, Verträge und Lizenzen \u003e Wartungs- und Supportvertrag"
created: "2026-08-25"
updated: "2026-08-25"
---

# Beschaffung, Verträge und Lizenzen > Wartungs- und Supportvertrag

Kategorie der GLPI/NeuroForge-Wissensbasis.
