---
type: "entity"
entity_type: "category"
title: "Benutzerkonten und Berechtigungen \u003e Funktions- und Sammelpostfächer"
created: "2026-08-25"
updated: "2026-08-25"
---

# Benutzerkonten und Berechtigungen > Funktions- und Sammelpostfächer

Kategorie der GLPI/NeuroForge-Wissensbasis.
