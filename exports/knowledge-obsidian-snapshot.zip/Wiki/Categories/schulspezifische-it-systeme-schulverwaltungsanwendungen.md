---
type: "entity"
entity_type: "category"
title: "Schulspezifische IT-Systeme \u003e Schulverwaltungsanwendungen"
created: "2026-08-25"
updated: "2026-08-25"
---

# Schulspezifische IT-Systeme > Schulverwaltungsanwendungen

Kategorie der GLPI/NeuroForge-Wissensbasis.
