---
type: "entity"
entity_type: "category"
title: "Schulspezifische IT-Systeme \u003e Computerräume"
created: "2026-08-25"
updated: "2026-08-25"
---

# Schulspezifische IT-Systeme > Computerräume

Kategorie der GLPI/NeuroForge-Wissensbasis.
