---
type: "entity"
entity_type: "category"
title: "Fachanwendungen und Microsoft Office \u003e Fachanwendung – Einführung einer Anwendung"
created: "2026-08-25"
updated: "2026-08-25"
---

# Fachanwendungen und Microsoft Office > Fachanwendung – Einführung einer Anwendung

Kategorie der GLPI/NeuroForge-Wissensbasis.
