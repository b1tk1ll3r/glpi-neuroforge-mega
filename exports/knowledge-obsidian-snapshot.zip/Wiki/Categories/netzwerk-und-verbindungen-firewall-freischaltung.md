---
type: "entity"
entity_type: "category"
title: "Netzwerk und Verbindungen \u003e Firewall-Freischaltung"
created: "2026-08-25"
updated: "2026-08-25"
---

# Netzwerk und Verbindungen > Firewall-Freischaltung

Kategorie der GLPI/NeuroForge-Wissensbasis.
