---
type: "entity"
entity_type: "category"
title: "Projekte, Änderungen und neue Anforderungen \u003e Digitalisierungsvorhaben"
created: "2026-08-25"
updated: "2026-08-25"
---

# Projekte, Änderungen und neue Anforderungen > Digitalisierungsvorhaben

Kategorie der GLPI/NeuroForge-Wissensbasis.
