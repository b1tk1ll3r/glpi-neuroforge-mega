---
type: "entity"
entity_type: "category"
title: "Telefonie und Kommunikation \u003e Telefonkonferenz und Softphone"
created: "2026-08-25"
updated: "2026-08-25"
---

# Telefonie und Kommunikation > Telefonkonferenz und Softphone

Kategorie der GLPI/NeuroForge-Wissensbasis.
