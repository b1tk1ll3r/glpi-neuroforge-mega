---
type: "entity"
entity_type: "category"
title: "Fachanwendungen und Microsoft Office \u003e Fachanwendung – Schnittstelle und Datenaustausch"
created: "2026-08-25"
updated: "2026-08-25"
---

# Fachanwendungen und Microsoft Office > Fachanwendung – Schnittstelle und Datenaustausch

Kategorie der GLPI/NeuroForge-Wissensbasis.
