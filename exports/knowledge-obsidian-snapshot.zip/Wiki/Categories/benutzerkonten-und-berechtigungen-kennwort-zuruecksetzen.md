---
type: "entity"
entity_type: "category"
title: "Benutzerkonten und Berechtigungen \u003e Kennwort zurücksetzen"
created: "2026-08-25"
updated: "2026-08-25"
---

# Benutzerkonten und Berechtigungen > Kennwort zurücksetzen

Kategorie der GLPI/NeuroForge-Wissensbasis.
