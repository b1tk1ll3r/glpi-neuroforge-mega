---
type: "entity"
entity_type: "category"
title: "Drucken, Scannen und Kopieren \u003e Scan-to-Mail und Scan-to-Folder"
created: "2026-08-25"
updated: "2026-08-25"
---

# Drucken, Scannen und Kopieren > Scan-to-Mail und Scan-to-Folder

Kategorie der GLPI/NeuroForge-Wissensbasis.
