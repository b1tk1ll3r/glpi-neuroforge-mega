---
type: "entity"
entity_type: "category"
title: "Projekte, Änderungen und neue Anforderungen \u003e Standorteröffnung und Umzug"
created: "2026-08-25"
updated: "2026-08-25"
---

# Projekte, Änderungen und neue Anforderungen > Standorteröffnung und Umzug

Kategorie der GLPI/NeuroForge-Wissensbasis.
