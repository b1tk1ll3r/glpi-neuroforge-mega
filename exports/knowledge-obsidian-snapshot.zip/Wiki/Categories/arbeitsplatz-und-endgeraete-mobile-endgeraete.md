---
type: "entity"
entity_type: "category"
title: "Arbeitsplatz und Endgeräte \u003e Mobile Endgeräte"
created: "2026-08-25"
updated: "2026-08-25"
---

# Arbeitsplatz und Endgeräte > Mobile Endgeräte

Kategorie der GLPI/NeuroForge-Wissensbasis.
