---
type: "entity"
entity_type: "category"
title: "Telefonie und Kommunikation \u003e Rufnummer und Nebenstelle"
created: "2026-08-25"
updated: "2026-08-25"
---

# Telefonie und Kommunikation > Rufnummer und Nebenstelle

Kategorie der GLPI/NeuroForge-Wissensbasis.
