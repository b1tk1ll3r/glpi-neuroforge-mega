---
type: "entity"
entity_type: "category"
title: "IT-Sicherheit und Datensicherung \u003e Datenwiederherstellung"
created: "2026-08-25"
updated: "2026-08-25"
---

# IT-Sicherheit und Datensicherung > Datenwiederherstellung

Kategorie der GLPI/NeuroForge-Wissensbasis.
