---
type: "entity"
entity_type: "category"
title: "Fachanwendungen und Microsoft Office \u003e Microsoft Excel"
created: "2026-08-25"
updated: "2026-08-25"
---

# Fachanwendungen und Microsoft Office > Microsoft Excel

Kategorie der GLPI/NeuroForge-Wissensbasis.
