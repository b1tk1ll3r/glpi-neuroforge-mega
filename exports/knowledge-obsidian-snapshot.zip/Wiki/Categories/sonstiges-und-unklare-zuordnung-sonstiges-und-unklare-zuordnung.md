---
type: "entity"
entity_type: "category"
title: "Sonstiges und unklare Zuordnung \u003e Sonstiges und unklare Zuordnung"
created: "2026-08-25"
updated: "2026-08-25"
---

# Sonstiges und unklare Zuordnung > Sonstiges und unklare Zuordnung

Kategorie der GLPI/NeuroForge-Wissensbasis.
