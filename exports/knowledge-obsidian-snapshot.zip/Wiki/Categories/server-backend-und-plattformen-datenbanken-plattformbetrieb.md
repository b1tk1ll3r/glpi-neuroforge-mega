---
type: "entity"
entity_type: "category"
title: "Server, Backend und Plattformen \u003e Datenbanken – Plattformbetrieb"
created: "2026-08-25"
updated: "2026-08-25"
---

# Server, Backend und Plattformen > Datenbanken – Plattformbetrieb

Kategorie der GLPI/NeuroForge-Wissensbasis.
