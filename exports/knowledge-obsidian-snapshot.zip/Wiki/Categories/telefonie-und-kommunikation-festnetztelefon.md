---
type: "entity"
entity_type: "category"
title: "Telefonie und Kommunikation \u003e Festnetztelefon"
created: "2026-08-25"
updated: "2026-08-25"
---

# Telefonie und Kommunikation > Festnetztelefon

Kategorie der GLPI/NeuroForge-Wissensbasis.
