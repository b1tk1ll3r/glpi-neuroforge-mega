---
type: "entity"
entity_type: "category"
title: "Schulspezifische IT-Systeme \u003e Schüler- und Lehrkräftekonten"
created: "2026-08-25"
updated: "2026-08-25"
---

# Schulspezifische IT-Systeme > Schüler- und Lehrkräftekonten

Kategorie der GLPI/NeuroForge-Wissensbasis.
