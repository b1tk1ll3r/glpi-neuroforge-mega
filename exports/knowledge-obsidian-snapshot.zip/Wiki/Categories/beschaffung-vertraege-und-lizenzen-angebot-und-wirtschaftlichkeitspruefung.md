---
type: "entity"
entity_type: "category"
title: "Beschaffung, Verträge und Lizenzen \u003e Angebot und Wirtschaftlichkeitsprüfung"
created: "2026-08-25"
updated: "2026-08-25"
---

# Beschaffung, Verträge und Lizenzen > Angebot und Wirtschaftlichkeitsprüfung

Kategorie der GLPI/NeuroForge-Wissensbasis.
