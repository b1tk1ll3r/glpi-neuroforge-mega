---
type: "entity"
entity_type: "category"
title: "Schulspezifische IT-Systeme \u003e Pädagogische Lernplattformen"
created: "2026-08-25"
updated: "2026-08-25"
---

# Schulspezifische IT-Systeme > Pädagogische Lernplattformen

Kategorie der GLPI/NeuroForge-Wissensbasis.
