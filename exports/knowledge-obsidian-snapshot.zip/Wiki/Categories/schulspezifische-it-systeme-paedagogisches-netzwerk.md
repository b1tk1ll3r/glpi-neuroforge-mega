---
type: "entity"
entity_type: "category"
title: "Schulspezifische IT-Systeme \u003e Pädagogisches Netzwerk"
created: "2026-08-25"
updated: "2026-08-25"
---

# Schulspezifische IT-Systeme > Pädagogisches Netzwerk

Kategorie der GLPI/NeuroForge-Wissensbasis.
