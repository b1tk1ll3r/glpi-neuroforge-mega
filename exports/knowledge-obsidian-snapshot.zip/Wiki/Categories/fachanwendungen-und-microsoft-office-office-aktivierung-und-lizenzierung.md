---
type: "entity"
entity_type: "category"
title: "Fachanwendungen und Microsoft Office \u003e Office-Aktivierung und Lizenzierung"
created: "2026-08-25"
updated: "2026-08-25"
---

# Fachanwendungen und Microsoft Office > Office-Aktivierung und Lizenzierung

Kategorie der GLPI/NeuroForge-Wissensbasis.
