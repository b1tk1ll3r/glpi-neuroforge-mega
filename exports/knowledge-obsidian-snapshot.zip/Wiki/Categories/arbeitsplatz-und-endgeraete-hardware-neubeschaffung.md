---
type: "entity"
entity_type: "category"
title: "Arbeitsplatz und Endgeräte \u003e Hardware-Neubeschaffung"
created: "2026-08-25"
updated: "2026-08-25"
---

# Arbeitsplatz und Endgeräte > Hardware-Neubeschaffung

Kategorie der GLPI/NeuroForge-Wissensbasis.
