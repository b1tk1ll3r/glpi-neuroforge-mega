---
type: "entity"
entity_type: "category"
title: "Fachanwendungen und Microsoft Office \u003e Fachanwendung – Bedienung und Beratung"
created: "2026-08-25"
updated: "2026-08-25"
---

# Fachanwendungen und Microsoft Office > Fachanwendung – Bedienung und Beratung

Kategorie der GLPI/NeuroForge-Wissensbasis.
