---
type: "entity"
entity_type: "category"
title: "Arbeitsplatz und Endgeräte \u003e Tastatur, Maus und Zubehör"
created: "2026-08-25"
updated: "2026-08-25"
---

# Arbeitsplatz und Endgeräte > Tastatur, Maus und Zubehör

Kategorie der GLPI/NeuroForge-Wissensbasis.
