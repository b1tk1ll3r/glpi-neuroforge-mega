---
type: "entity"
entity_type: "category"
title: "Arbeitsplatz und Endgeräte \u003e PC und Notebook"
created: "2026-08-25"
updated: "2026-08-25"
---

# Arbeitsplatz und Endgeräte > PC und Notebook

Kategorie der GLPI/NeuroForge-Wissensbasis.
