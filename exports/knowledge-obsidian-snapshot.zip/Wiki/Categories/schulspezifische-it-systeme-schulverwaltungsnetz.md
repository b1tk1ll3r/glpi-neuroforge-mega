---
type: "entity"
entity_type: "category"
title: "Schulspezifische IT-Systeme \u003e Schulverwaltungsnetz"
created: "2026-08-25"
updated: "2026-08-25"
---

# Schulspezifische IT-Systeme > Schulverwaltungsnetz

Kategorie der GLPI/NeuroForge-Wissensbasis.
