---
type: meta
title: GLPI NeuroForge Wiki Schema
status: active
---

# Wiki Schema

Obsidian-kompatibler Export nach llm-wiki-artigen Konventionen.

- Metadaten: YAML-Frontmatter
- Beziehungen: [[Wiki/Namespace/Page]]
- Datumswerte: ISO-8601 (YYYY-MM-DD)
- Knowledge-Seiten: type=knowledge
- Kategorien/GLPI-Objekte: type=entity
- Index: type=overview
- graph.json: maschinenlesbare Knoten und Kanten

Der Export ist read-only und enthält keine Zugangsdaten.
